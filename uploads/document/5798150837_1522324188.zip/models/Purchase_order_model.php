<?php
	defined('BASEPATH') OR exit('No direct script access allowed');
	class purchase_order_model extends CI_Model
	{
 
    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }
  
	
	public function get_new_invoice_number(){
	    $root_id = $_SESSION['root_id'];
	    $condition = "root_id='".$root_id."' order by id desc";
		$this->db->select('*');
		$this->db->from('pricing_purchase_orders');
		$this->db->where($condition);
		$this->db->limit(1);
		$query = $this->db->get();
		$result= $query->result();
		
		if(isset($result[0]->invoice_number)){
		    $last_id = $result[0]->invoice_number;
		    $last_id = filter_var($last_id, FILTER_SANITIZE_NUMBER_INT);
		    $last_id = abs($last_id)+1;
		}
		else
		{
		    $last_id = 1;
		}
		
		return $num_padded = sprintf("%06d", $last_id);
	}
	
	
	public function get_all_invoices($id){
	    $root_id = $_SESSION['root_id'];
	    $condition = "added_by =" . "'" . $id . "' and root_id='".$root_id."' order by id desc";
		$this->db->select('*');
		$this->db->from('pricing_purchase_orders');
		$this->db->where($condition);
		return $query = $this->db->get();
	}
	
	// Function to add record in table
	public function add_invoice($data){
	    $root_id   = $_SESSION['root_id'];
	    $data['root_id'] = $root_id;
		$this->db->insert('pricing_purchase_orders', $data);
		if ($this->db->affected_rows() > 0) {
			return true;
		} else {
			return false;
		}
	}
	
	public function update_invoice($data, $id){
	    $root_id   = $_SESSION['root_id'];
		$condition = "id =" . "'" . $id . "' and root_id = '".$root_id."'";
		$this->db->where($condition);
		if( $this->db->update('pricing_purchase_orders',$data)) {
			return true;
		} else {
			return false;
		}		
	}
	
	public function delete_invoice_data($id){
	    $root_id   = $_SESSION['root_id'];
		$condition = "id =" . "'" . $id . "' and root_id = '".$root_id."'";
		$this->db->where($condition);
		if($this->db->delete('pricing_purchase_orders')) {
			return true;
		} else {
			return false;
		}
	}
	
	public function delete_invoice_items($id){
	    $root_id   = $_SESSION['root_id'];
		$condition = "purchase_order_id =" . "'" . $id . "' and root_id = '".$root_id."'";
		$this->db->where($condition);
		if($this->db->delete('pricing_purchase_order_items')) {
			return true;
		} else {
			return false;
		}
	}
	
	public function add_invoice_items($data){
	    $root_id   = $_SESSION['root_id'];
	    $data['root_id'] = $root_id;
		$this->db->insert('pricing_purchase_order_items', $data);
		if ($this->db->affected_rows() > 0) {
			return true;
		} else {
			return false;
		}
	}
	
	
	// get single record > db table
	public function read_invoice_information($id) {
	    $root_id = $_SESSION['root_id'];
		$condition = "id =" . "'" . $id . "' and root_id='".$root_id."' ";
		$this->db->select('*');
		$this->db->from('pricing_purchase_orders');
		$this->db->where($condition);
		$this->db->limit(1);
		$query = $this->db->get();
		
		return $query->result();
	}
	
	// get single record > db table
	public function get_invoice_items($id) {
	    $root_id   = $_SESSION['root_id'];
	    $condition = "purchase_order_id =" . "'" . $id . "' and root_id =" . "'" . $root_id . "' order by id asc";
        $this->db->select('*');
		$this->db->from('pricing_purchase_order_items');
		$this->db->where($condition);
		$query = $this->db->get();
		return $query->result();
	}
	
	
	
}
?>