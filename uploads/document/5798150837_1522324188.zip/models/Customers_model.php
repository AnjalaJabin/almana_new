<?php
	defined('BASEPATH') OR exit('No direct script access allowed');
	class customers_model extends CI_Model
	{
 
    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }
  
	public function get_customers($user_id) {
	    $root_id   = $_SESSION['root_id'];
	    $condition = "root_id =" . "'" . $root_id . "' and added_by='".$user_id."'";
        $this->db->select('*');
		$this->db->from('customers');
		$this->db->where($condition);
		return $this->db->get();
	}
	
	public function get_customers_contacts($customer_id) {
	    $root_id   = $_SESSION['root_id'];
	    $condition = "root_id =" . "'" . $root_id . "' and customer_id='".$customer_id."'";
        $this->db->select('*');
		$this->db->from('customers_contacts');
		$this->db->where($condition);
		return $this->db->get();
	}
	
	public function get_all_customers() {
	    $root_id   = $_SESSION['root_id'];
	    $condition = "root_id =" . "'" . $root_id . "'";
        $this->db->select('*');
		$this->db->from('customers');
		$this->db->where($condition);
		return $this->db->get();
	}
	 
	public function read_customer_information($id) {
	    $root_id   = $_SESSION['root_id'];
		$condition = "customer_id =" . "'" . $id . "' and root_id =" . "'" . $root_id . "'";
		$this->db->select('*');
		$this->db->from('customers');
		$this->db->where($condition);
		$this->db->limit(1);
		$query = $this->db->get();
		
		if ($query->num_rows() == 1) {
			return $query->result();
		} else {
			return false;
		}
	}
	
	public function read_customer_contact_information($id) {
	    $root_id   = $_SESSION['root_id'];
		$condition = "id =" . "'" . $id . "' and root_id =" . "'" . $root_id . "'";
		$this->db->select('*');
		$this->db->from('customers_contacts');
		$this->db->where($condition);
		$this->db->limit(1);
		$query = $this->db->get();
		
		if ($query->num_rows() == 1) {
			return $query->result();
		} else {
			return false;
		}
	}
	
	// Function to add record in table
	public function add($data){
	    $root_id   = $_SESSION['root_id'];
	    $data['root_id'] = $root_id;
		$this->db->insert('customers', $data);
		if ($this->db->affected_rows() > 0) {
			return true;
		} else {
			return false;
		}
	}
	
	// Function to add record in table
	public function add_contact($data){
	    $root_id   = $_SESSION['root_id'];
	    $data['root_id'] = $root_id;
		$this->db->insert('customers_contacts', $data);
		if ($this->db->affected_rows() > 0) {
			return true;
		} else {
			return false;
		}
	}
	
	// Function to Delete selected record from table
	public function delete_record($id){
	    $root_id   = $_SESSION['root_id'];
		$condition = "customer_id =" . "'" . $id . "' and root_id =" . "'" . $root_id . "'";
		$this->db->where($condition);
		$this->db->delete('customers');
		
		$condition = "customer_id =" . "'" . $id . "' and root_id =" . "'" . $root_id . "'";
		$this->db->where($condition);
		$this->db->delete('customers_contacts');
		
	}
	
	// Function to Delete selected record from table
	public function delete_contact_record($id){
	    $root_id   = $_SESSION['root_id'];
		$condition = "id =" . "'" . $id . "' and root_id =" . "'" . $root_id . "'";
		$this->db->where($condition);
		$this->db->delete('customers_contacts');
		
	}
	
	// Function to update record in table
	public function update_record($data, $id){
	    $root_id   = $_SESSION['root_id'];
		$condition = "customer_id =" . "'" . $id . "' and root_id =" . "'" . $root_id . "'";
		$this->db->where($condition);
		if( $this->db->update('customers',$data)) {
			return true;
		} else {
			return false;
		}		
	}
	
	// Function to update record in table
	public function update_contact_record($data, $id){
	    $root_id   = $_SESSION['root_id'];
		$condition = "id =" . "'" . $id . "' and root_id =" . "'" . $root_id . "'";
		$this->db->where($condition);
		if( $this->db->update('customers_contacts',$data)) {
			return true;
		} else {
			return false;
		}		
	}
}
?>