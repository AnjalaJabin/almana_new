<?php
	defined('BASEPATH') OR exit('No direct script access allowed');
class dashboard_model extends CI_Model {
 
    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }


    public function get_all_quotes_count(){
	    $session = $this->session->userdata('username');
	    $user_id = $session['user_id'];
	    $root_id   = $_SESSION['root_id'];
	    $condition = "root_id ='" . $root_id . "' and added_by='".$user_id."'";
        $this->db->select('*');
		$this->db->from('pricing_quotes');
		$this->db->where($condition);
		$query = $this->db->get();
		echo $query->num_rows();
	}
	
	public function get_all_invoices_count(){
	    $session = $this->session->userdata('username');
	    $user_id = $session['user_id'];
	    $root_id   = $_SESSION['root_id'];
	    $condition = "root_id ='" . $root_id . "' and added_by='".$user_id."'";
        $this->db->select('*');
		$this->db->from('pricing_invoices');
		$this->db->where($condition);
		$query = $this->db->get();
		echo $query->num_rows();
	}
	
	public function get_all_products_count(){
	    $root_id   = $_SESSION['root_id'];
	    $condition = "root_id ='" . $root_id . "'";
        $this->db->select('*');
		$this->db->from('products');
		$this->db->where($condition);
		$query = $this->db->get();
		echo $query->num_rows();
	}
	
	public function get_all_customers_count(){
	    $session = $this->session->userdata('username');
	    $user_id = $session['user_id'];
	    $root_id   = $_SESSION['root_id'];
	    $condition = "root_id ='" . $root_id . "' and added_by='".$user_id."'";
        $this->db->select('*');
		$this->db->from('customers');
		$this->db->where($condition);
		$query = $this->db->get();
		echo $query->num_rows();
	}
	
	public function get_all_suppliers_count(){
	    $root_id   = $_SESSION['root_id'];
	    $condition = "root_id ='" . $root_id . "'";
        $this->db->select('*');
		$this->db->from('suppliers');
		$this->db->where($condition);
		$query = $this->db->get();
		echo $query->num_rows();
	}
    
    public function get_my_price_requests_count(){
	    $session = $this->session->userdata('username');
	    $user_id = $session['user_id'];
	    $root_id   = $_SESSION['root_id'];
	    $condition = "root_id ='" . $root_id . "' and added_by='".$user_id."'";
        $this->db->select('*');
		$this->db->from('pricing_price_request');
		$this->db->where($condition);
		$query = $this->db->get();
		echo $query->num_rows();
	}
	
	public function get_my_given_price_count(){
	    $session = $this->session->userdata('username');
	    $user_id = $session['user_id'];
	    $root_id   = $_SESSION['root_id'];
	    $condition = "root_id ='" . $root_id . "' and added_by='".$user_id."'";
        $this->db->select('*');
		$this->db->from('customer_price');
		$this->db->where($condition);
		$query = $this->db->get();
		echo $query->num_rows();
	}
	
	public function get_converted_invoices_count(){
	    $session = $this->session->userdata('username');
	    $user_id = $session['user_id'];
	    $root_id   = $_SESSION['root_id'];
	    $condition = "root_id ='" . $root_id . "' and added_by='".$user_id."' and quote_id>0";
        $this->db->select('*');
		$this->db->from('pricing_invoices');
		$this->db->where($condition);
		$query = $this->db->get();
		echo $query->num_rows();
	}
	
}
?>