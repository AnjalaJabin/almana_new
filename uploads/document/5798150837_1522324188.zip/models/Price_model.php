<?php
	defined('BASEPATH') OR exit('No direct script access allowed');
	class price_model extends CI_Model
	{
 
    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }
  
	public function get_products() {
	    $root_id   = $_SESSION['root_id'];
	    $condition = "root_id =" . "'" . $root_id . "'";
        $this->db->select('*');
		$this->db->from('products');
		$this->db->where($condition);
		return $this->db->get();
	}
	 
	public function read_product_information($id) {
	    $root_id   = $_SESSION['root_id'];
		$condition = "id =" . "'" . $id . "' and root_id =" . "'" . $root_id . "'";
		$this->db->select('*');
		$this->db->from('products');
		$this->db->where($condition);
		$this->db->limit(1);
		$query = $this->db->get();
		
		if ($query->num_rows() == 1) {
			return $query->result();
		} else {
			return false;
		}
	}
	
	// Function to add record in table
	public function add($data){
	    $root_id   = $_SESSION['root_id'];
	    $data['root_id'] = $root_id;
		$this->db->insert('product_price', $data);
		if ($this->db->affected_rows() > 0) {
		    
		    $data2 = array(
		        'status' => 1,
		        'updated_by' => $data['added_by'],
		        'supplier_id' => $data['supplier_id'],
        		'price' => $data['price'],
        		'updated_date' => $data['date']
		    );
    		$condition = "product_id =" . "'" . $data['product_id'] . "' and root_id =" . "'" . $root_id . "' and status = 0";
    		$this->db->where($condition);
    		$this->db->update('pricing_price_request',$data2);
    		
			return true;
		} else {
			return false;
		}
	}
	
	// Function to add record in table
	public function add_customer_price($data){
	    $root_id   = $_SESSION['root_id'];
	    $data['root_id'] = $root_id;
		$this->db->insert('customer_price', $data);
		if ($this->db->affected_rows() > 0) {
			return true;
		} else {
			return false;
		}
	}
	
	// Function to Delete selected record from table
	public function delete_record($id){
	    $root_id   = $_SESSION['root_id'];
		$condition = "id =" . "'" . $id . "' and root_id =" . "'" . $root_id . "'";
		$this->db->where($condition);
		$this->db->delete('product_price');
		
	}
	
	public function delete_my_price_request_record($id){
	    $root_id   = $_SESSION['root_id'];
		$condition = "id =" . "'" . $id . "' and root_id =" . "'" . $root_id . "'";
		$this->db->where($condition);
		$this->db->delete('pricing_price_request');
	}
	
	// Function to Delete selected record from table
	public function delete_customer_price($id){
	    $root_id   = $_SESSION['root_id'];
		$condition = "id =" . "'" . $id . "' and root_id =" . "'" . $root_id . "'";
		$this->db->where($condition);
		$this->db->delete('customer_price');
	}
	
	// Function to update record in table
	public function update_record($data, $id){
	    $root_id   = $_SESSION['root_id'];
		$condition = "id =" . "'" . $id . "' and root_id =" . "'" . $root_id . "'";
		$this->db->where($condition);
		if( $this->db->update('products',$data)) {
			return true;
		} else {
			return false;
		}		
	}
}
?>