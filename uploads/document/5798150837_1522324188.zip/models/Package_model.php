<?php
	defined('BASEPATH') OR exit('No direct script access allowed');
class package_model extends CI_Model {
 
    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }
 
	public function get_packages()
	{
	    $condition = "active =" . "'1'";
        $this->db->select('*');
		$this->db->from('packages');
		$this->db->where($condition);
		$query = $this->db->get();
		return $query->result();
	}
	
	public function read_package_information($id) {
		$condition = "id =" . "'" . $id . "'";
		$this->db->select('*');
		$this->db->from('packages');
		$this->db->where($condition);
		$this->db->limit(1);
		$query = $this->db->get();
		
		if ($query->num_rows() == 1) {
			return $query->result();
		} else {
			return false;
		}
	}

	
	// Function to update record in table
	public function update_record($data){
		$root_id   = $_SESSION['root_id'];
		$condition = "id =" . "'" . $root_id."'";
		$this->db->where($condition);
		if( $this->db->update('root_accounts',$data)) {
			return true;
		} else {
			return false;
		}		
	}

}
?>