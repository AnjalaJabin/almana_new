<?php
$session = $this->session->userdata('username');
?>

<div class="box box-block bg-white" align="center">
    <div class="row">
        <div class="col-sm-2">
            <a href="<?php echo site_url('quote/create_quote') ?>" class="m-b-0-0 waves-effect waves-light btn btn-lg btn-info"><i class="fa fa-plus icon"></i> Create Quote</a>
        </div>
        <div class="col-sm-2">
            <a href="<?php echo site_url('invoices/create_invoice') ?>" class="m-b-0-0 waves-effect waves-light btn btn-lg btn-warning"><i class="fa fa-plus icon"></i> Create Invoice</a>
        </div>
        <div class="col-sm-2">
            <a href="<?php echo site_url('price') ?>" class="m-b-0-0 waves-effect waves-light btn btn-lg btn-success"><i class="fa fa-search icon"></i> Search Price</a>
        </div>
        <div class="col-sm-2">
            <a href="<?php echo site_url('customers') ?>" class="m-b-0-0 waves-effect waves-light btn btn-lg btn-primary"><i class="fa fa-users icon"></i> Customers</a>
        </div>
        <div class="col-sm-2">
            <a href="<?php echo site_url('products') ?>" class="m-b-0-0 waves-effect waves-light btn btn-lg btn-info"><i class="fa fa-cube"></i> Products</a>
        </div>
        <div class="col-sm-2">
            <a href="<?php echo site_url('suppliers') ?>" class="m-b-0-0 waves-effect waves-light btn btn-lg btn-warning"><i class="fa fa-users"></i> Suppliers</a>
        </div>
    </div>
</div>
<br>

<div class="row row-md mb-1">
  <a href="<?php echo site_url('quote');?>">
  <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12">
    <div class="box box-block tile tile-2 bg-danger mb-2">
      <div class="t-icon right"><i class="fa fa-file"></i></div>
      <div class="t-content">
        <h1 class="mb-1"><?php echo $this->Dashboard_model->get_all_quotes_count();?></h1>
        <h6 class="text-uppercase">Total Quotations</h6>
      </div>
    </div>
  </div>
  </a>
  
  <a href="<?php echo site_url('invoices');?>">
  <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12">
    <div class="box box-block tile tile-2 bg-success mb-2">
      <div class="t-icon right"><i class="ti-receipt"></i></div>
      <div class="t-content">
        <h1 class="mb-1"><?php echo $this->Dashboard_model->get_all_invoices_count();?></h1>
        <h6 class="text-uppercase">Total Invoices</h6>
      </div>
    </div>
  </div>
  </a>
  
  <a href="<?php echo site_url('products');?>/">
  <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12">
    <div class="box box-block tile tile-2 bg-primary mb-2">
      <div class="t-icon right"><i class="ti-package"></i></div>
      <div class="t-content">
        <h1 class="mb-1"><?php echo $this->Dashboard_model->get_all_products_count();?></h1>
        <h6 class="text-uppercase">Total Products</h6>
      </div>
    </div>
  </div>
  </a>
  
  <a href="<?php echo site_url('customers');?>">
  <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12">
    <div class="box box-block tile tile-2 bg-warning mb-2">
      <div class="t-icon right"><i class="fa fa-users"></i></div>
      <div class="t-content">
        <h1 class="mb-1"><?php echo $this->Dashboard_model->get_all_customers_count();?></h1>
        <h6 class="text-uppercase">Total Customers</h6>
      </div>
    </div>
  </div>
</div>
</a>


<div class="row row-md mb-1">
    
  <a href="<?php echo site_url('suppliers');?>">
  <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12">
    <div class="box box-block bg-white tile tile-3 sdl-tile mb-2">
      <div class="t-icon right"><i class="fa fa-users"></i></div>
      <div class="t-content"> <span class="text-uppercase text-danger">Total Suppliers</span>
        <h1 class="mb-0"><?php echo $this->Dashboard_model->get_all_suppliers_count();?></h1>
      </div>
    </div>
  </div>
  </a>
  
  <a href="<?php echo site_url('price/my_price_requests');?>">
  <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12">
    <div class="box box-block bg-white tile tile-3 payroll-tile mb-2">
      <div class="t-icon right"><i class="fa fa-folder-open-o"></i></div>
      <div class="t-content"> <span class="text-uppercase text-success">My Price Requests</span>
        <h1 class="mb-0"><?php echo $this->Dashboard_model->get_my_price_requests_count();?></h1>
      </div>
    </div>
  </div>
  </a>
  
  <a href="<?php echo site_url('price/given_price_history');?>">
  <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12">
    <div class="box box-block bg-white tile tile-3 payroll-tile mb-2">
      <div class="t-icon right"><i class="ti-receipt"></i></div>
      <div class="t-content"> <span class="text-uppercase text-warning">My Given Prices</span>
        <h1 class="mb-0"><?php echo $this->Dashboard_model->get_my_given_price_count();?></h1>
      </div>
    </div>
  </div>
  </a>
  
  <a href="<?php echo site_url('invoices');?>">
  <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12">
    <div class="box box-block bg-white tile tile-3 payroll-tile mb-2">
      <div class="t-icon right"><i class="fa fa-refresh"></i></div>
      <div class="t-content"> <span class="text-uppercase text-success">Total Converted Invoices</span>
        <h1 class="mb-0"><?php echo $this->Dashboard_model->get_converted_invoices_count();?></h1>
      </div>
    </div>
  </div>
  </a>
  
</div>


<div class="box box-block bg-white">
    <div class="row">
        <div class="col-md-6">
            <h2><strong>Recent</strong> Quotations</h2>
            <table class="table table-striped table-bordered dataTable" style="width:100%;">
              <thead>
                <tr>
                  <td>Quote #</td>
                  <th>Amount</th>
                  <th>Customer</th>
                  <th>Date</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                <?php
                  
        		  $quotation = $this->Xin_model->get_last_5_quotations($session['user_id']);
        
                  foreach($quotation->result() as $r) {
                       $customer_data = $this->Customers_model->read_customer_information($r->customer_id);
                       
                       if(!empty($customer_data))
                       {
                           $customer_name = $customer_data[0]->company_name;
                       }
                       else
                       {
                           $customer_name = '--';
                       }
                            
                            $edit_url = site_url('quote/view/'.$r->id);
                            
                            $status = '<a href="'.$edit_url.'" class="btn btn-sm btn-primary">Draft</a>';
                            
                            if($r->status=='sent')
                            {
                                $status = '<a href="'.$edit_url.'" class="btn btn-sm btn-success">Sent</a>';
                            }
                            
                            echo '<tr>';
                            echo '<td><a href="'.$edit_url.'">QUOTE-'.$r->quotation_number.'</a></td>';
        			   		echo '<td>'.$r->currency.' '.number_format($r->g_total,2).'</td>';
        			   		echo '<td><a href="'.$edit_url.'">'.$customer_name.'</a></td>';
        			   		echo '<td>'.date('d-m-Y',strtotime($r->quotation_date)).'</td>';
                            echo '<td>'.$status.'</td>';
                            echo '</tr>';
                  }
                ?>
              </tbody>
            </table>
            <a class="pull-right" href="<?php echo site_url('quote') ?>">View All</a>
        </div>
        
        <div class="col-md-6">
            <h2><strong>Recent</strong> Invoices</h2>
            <table class="table table-striped table-bordered dataTable" style="width:100%;">
              <thead>
                <tr>
                  <td>Invoice #</td>
                  <th>Amount</th>
                  <th>Customer</th>
                  <th>Date</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                <?php
                  
        		  $quotation = $this->Xin_model->get_last_5_invoices($session['user_id']);
        
                  foreach($quotation->result() as $r) {
                       $customer_data = $this->Customers_model->read_customer_information($r->customer_id);
                       
                       if(!empty($customer_data))
                       {
                           $customer_name = $customer_data[0]->company_name;
                       }
                       else
                       {
                           $customer_name = '--';
                       }
                       
                            $edit_url = site_url('invoices/view/'.$r->id);
                            
                            $status = '<a href="'.$edit_url.'" class="btn btn-sm btn-primary">Draft</a>';
                            
                            if($r->status=='sent')
                            {
                                $status = '<a href="'.$edit_url.'" class="btn btn-sm btn-success">Sent</a>';
                            }
                            
                            echo '<tr>';
                            echo '<td><a href="'.$edit_url.'">INV-'.$r->invoice_number.'</a></td>';
        			   		echo '<td>'.$r->currency.' '.number_format($r->g_total,2).'</td>';
        			   		echo '<td><a href="'.$edit_url.'">'.$customer_name.'</a></td>';
        			   		echo '<td>'.date('d-m-Y',strtotime($r->invoice_date)).'</td>';
                            echo '<td>'.$status.'</td>';
                            echo '</tr>';
                  }
                ?>
              </tbody>
            </table>
            <a class="pull-right" href="<?php echo site_url('invoices') ?>">View All</a>
        </div>
    </div>
    
</div>
