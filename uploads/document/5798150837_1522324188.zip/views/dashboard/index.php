<?php
$session = $this->session->userdata('username');
?>

<!--
<div class="box box-block bg-white" align="center">
    <div class="row">
        
        <a href="<?php echo site_url('quote/create_quote') ?>" class="m-b-0-0 waves-effect waves-light btn btn-lg btn-info"><i class="fa fa-plus icon"></i> Create Quote</a>
        <a href="<?php echo site_url('invoices/create_invoice') ?>" class="m-b-0-0 waves-effect waves-light btn btn-lg btn-warning"><i class="fa fa-plus icon"></i> Create Invoice</a>
        <a href="<?php echo site_url('price') ?>" class="m-b-0-0 waves-effect waves-light btn btn-lg btn-success"><i class="fa fa-search icon"></i> Search Price</a>
        <a href="<?php echo site_url('purchase_order/create_purchase_order') ?>" class="m-b-0-0 waves-effect waves-light btn btn-lg btn-primary"><i class="fa fa-plus icon"></i> Create Purchase Order</a>
        <a href="<?php echo site_url('delivery_note/create_delivery_note') ?>" class="m-b-0-0 waves-effect waves-light btn btn-lg btn-danger"><i class="fa fa-plus"></i>  Create Delivery Note</a>
        
    </div>
</div>
-->

<!--
<div class="box box-block bg-white" align="center">
    <div class="row">
        
        <div class="col-sm-2">
            <a href="<?php echo site_url('quote/create_quote') ?>" class="m-b-0-0 waves-effect waves-light btn btn-lg btn-info"><i class="fa fa-plus icon"></i> Create Quote</a>
        </div>
        <div class="col-sm-2">
            <a href="<?php echo site_url('invoices/create_invoice') ?>" class="m-b-0-0 waves-effect waves-light btn btn-lg btn-warning"><i class="fa fa-plus icon"></i> Create Invoice</a>
        </div>
        <div class="col-sm-2">
            <a href="<?php echo site_url('price') ?>" class="m-b-0-0 waves-effect waves-light btn btn-lg btn-success"><i class="fa fa-search icon"></i> Search Price</a>
        </div>
        <div class="col-sm-2">
            <a href="<?php echo site_url('purchase_order/create_purchase_order') ?>" class="m-b-0-0 waves-effect waves-light btn btn-lg btn-primary"><i class="fa fa-plus icon"></i> Create LPO</a>
        </div>
        <div class="col-sm-2">
            <a href="<?php echo site_url('delivery_note/create_delivery_note') ?>" class="m-b-0-0 waves-effect waves-light btn btn-lg btn-info"><i class="fa fa-plus"></i>  Create Delivery Note</a>
        </div>
        <div class="col-sm-2">
            <a href="<?php echo site_url('suppliers') ?>" class="m-b-0-0 waves-effect waves-light btn btn-lg btn-warning"><i class="fa fa-users"></i> Suppliers</a>
        </div>
        
    </div>
</div>
-->
<br>

<div class="row row-md mb-1" >
    
    <a href="<?php echo site_url('quote');?>">
       <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12">
           <div class="box1 first" style="border-radius: 4px;background: linear-gradient(45deg, #fda582, #f7cf68);    width: 100%;">
               <span class="icon-cont"><i class="fa fa-navicon" style="color: #ffffff !important;"></i></span>
               <h3>Total Quotations</h3>
               <a class="expand" href="<?php echo site_url('quote');?>"><?php echo $this->Dashboard_model->get_all_quotes_count();?></a>
           </div>
       </div>
    </a>
  
    <a href="<?php echo site_url('invoices');?>">
      <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12">
         <div class="box1 second" style="border-radius: 4px;background: linear-gradient(45deg, #a52dd8, #e29bf1);    width: 100%;">
           <span class="icon-cont"><i class="ti-receipt" style="color: #ffffff !important;"></i></span>
           <h3>Total Invoices</h3>
           <a class="expand" href="<?php echo site_url('invoices');?>"><?php echo $this->Dashboard_model->get_all_invoices_count();?></a>
         </div>
      </div>
    </a>
  
    <a href="<?php echo site_url('products');?>">
       <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12">
          <div class="box1 third" style="border-radius: 4px;    background: linear-gradient(45deg,#40ffed,#29b5af);    width: 100%;">
            <span class="icon-cont"><i class="ti-package" style="color: #ffffff !important;"></i></span>
            <h3>Total Products</h3>
            <a class="expand" href="<?php echo site_url('products');?>"><?php echo $this->Dashboard_model->get_all_products_count();?></a>
          </div>
       </div>
    </a>
  
  
    <a href="<?php echo site_url('customers');?>">
      <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12">
        <div class="box1 fourth" style="border-radius: 4px;background: linear-gradient(to bottom, #ccffcc 0%, #669999 100%);    width: 100%;">
            <span class="icon-cont"><i class="fa fa-users" style="color: #ffffff !important;"></i></span>
            <h3>Total Customers</h3>
            <a class="expand" href="<?php echo site_url('customers');?>"><?php echo $this->Dashboard_model->get_all_customers_count();?></a>
        </div>
      </div>
    </a>
    
</div>


<div class="row row-md mb-1" >
    
    <a href="<?php echo site_url('suppliers');?>">
      <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12">
        <div class="box box-block bg-white tile tile-3 sdl-tile mb-2 card card-1" >
          <div class="t-icon right" >
            <i class="fa fa-users" style="color:cadetblue;font-size:2.5rem;"></i>
          </div>
          <div class="t-content"> 
            <span class="text-uppercase" style="color:#868e96;">Total Suppliers</span>
            <h1 class="mb-0" style="color:darkgray"><?php echo $this->Dashboard_model->get_all_suppliers_count();?></h1>
          </div>
        </div>
      </div>
    </a>
  
    <a href="<?php echo site_url('price/my_price_requests');?>">
      <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12">
         <div class="box box-block bg-white tile tile-3 payroll-tile mb-2 card card-1" >
            <div class="t-icon right">
               <i class="fa fa-folder-open-o" style="color:cadetblue;font-size:2.5rem;"></i>
            </div>
            <div class="t-content"> 
              <span class="text-uppercase" style="color:#868e96;">My Price Requests</span>
              <h1 class="mb-0" style="color:darkgray"><?php echo $this->Dashboard_model->get_my_price_requests_count();?></h1>
            </div>
          </div>
       </div>
    </a>
  
    <a href="<?php echo site_url('price/given_price_history');?>">
       <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12">
          <div class="box box-block bg-white tile tile-3 payroll-tile mb-2 card card-1" >
             <div class="t-icon right">
                <i class="ti-receipt" style="color: cadetblue;font-size:2.5rem;"></i>
             </div>
             <div class="t-content"> 
                <span class="text-uppercase" style="color:#868e96;">My Given Prices</span>
                <h1 class="mb-0" style="color:darkgray"><?php  echo $this->Dashboard_model->get_my_given_price_count();?></h1>
             </div>
          </div>
       </div>
    </a>
  
    <a href="<?php echo site_url('invoices');?>">
       <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12">
          <div class="box box-block bg-white tile tile-3 payroll-tile mb-2 card card-1" >
             <div class="t-icon right">
                <i class="fa fa-refresh" style="color: cadetblue;font-size:2.5rem;"></i>
             </div>
             <div class="t-content"> 
                <span class="text-uppercase" style="color:#868e96;">Total Converted Invoices</span>
                <h1 class="mb-0" style="color:darkgray"><?php echo $this->Dashboard_model->get_converted_invoices_count();?></h1>
             </div>
          </div>
       </div>
    </a>
  
</div>

<div class="box box-block bg-white" align="center">
    <div class="row">
        
        <a href="<?php echo site_url('quote/create_quote') ?>" class="m-b-0-0 waves-effect waves-light btn btn-lg btn-info"><i class="fa fa-plus icon"></i> Create Quote</a>
        <a href="<?php echo site_url('invoices/create_invoice') ?>" class="m-b-0-0 waves-effect waves-light btn btn-lg btn-warning"><i class="fa fa-plus icon"></i> Create Invoice</a>
        <a href="<?php echo site_url('price') ?>" class="m-b-0-0 waves-effect waves-light btn btn-lg btn-success"><i class="fa fa-search icon"></i> Search Price</a>
        <a href="<?php echo site_url('purchase_order/create_purchase_order') ?>" class="m-b-0-0 waves-effect waves-light btn btn-lg btn-primary"><i class="fa fa-plus icon"></i> Create Purchase Order</a>
        <a href="<?php echo site_url('delivery_note/create_delivery_note') ?>" class="m-b-0-0 waves-effect waves-light btn btn-lg btn-danger"><i class="fa fa-plus"></i>  Create Delivery Note</a>
        
    </div>
</div>

<div class="box box-block bg-white">
    
    
    <div class="row">
        <div class="col-md-6">
            <h2><strong>Recent</strong> Quotations</h2>
            <table class="table table-striped table-bordered dataTable" style="width:100%;">
              <thead>
                <tr>
                  <td>Quote #</td>
                  <th>Amount</th>
                  <th>Customer</th>
                  <th>Date</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                <?php
                  
        		  $quotation = $this->Xin_model->get_last_5_quotations($session['user_id']);
                  $crm_settings = $this->Xin_model->read_setting_info(1);
                  
                  foreach($quotation->result() as $r) {
                       $customer_data = $this->Customers_model->read_customer_information($r->customer_id);
                       $quote_items   = $this->Xin_model->get_quote_items($r->id);
                       
                       if(!empty($customer_data))
                       {
                           $customer_name = $customer_data[0]->company_name;
                       }
                       else
                       {
                           $customer_name = '--';
                       }
                       
                            $subtotal = 0;
                    		foreach($quote_items as $item){
                                $subtotal=$subtotal+$item->amount;
                    		}
        		    
                		    $gtotal = $subtotal;
                		    $discount_am = 0;
                		    $tax_am = 0;
                		    
                            if(!empty($r->discount_percentage) && $r->discount_type=='before_tax')
                            {
                                $discount_am = ( $gtotal * $r->discount_percentage / 100 );
                                $gtotal = $gtotal-$discount_am;
                            }
                            
                            if(!empty($r->tax_included))
                            {
                                $tax_am = ( $gtotal * $r->tax_percentage / 100 );
                                $gtotal = $gtotal+$tax_am;
                            }
                            
                            if(!empty($r->discount_percentage) && $r->discount_type=='after_tax')
                            {
                                $discount_am = ( $gtotal * $r->discount_percentage / 100 );
                                $gtotal = $gtotal-$discount_am;
                            }
                            
                            if($r->adjustment>0)
                            {
                                $gtotal = $gtotal-$r->adjustment;
                            }
                            
                            $edit_url = site_url('quote/view/'.$r->id);
                            
                            $status = '<a href="'.$edit_url.'" class="btn btn-sm btn-primary">Draft</a>';
                            
                            if($r->status=='sent')
                            {
                                $status = '<a href="'.$edit_url.'" class="btn btn-sm btn-success">Sent</a>';
                            }
                            
                            echo '<tr>';
                            echo '<td><a href="'.$edit_url.'">'.$r->quotation_number.'</a></td>';
        			   		echo '<td>'.$r->currency.' '.number_format($gtotal,2).'</td>';
        			   		echo '<td><a href="'.$edit_url.'">'.$customer_name.'</a></td>';
        			   		echo '<td>'.date('d-m-Y',strtotime($r->quotation_date)).'</td>';
                            echo '<td>'.$status.'</td>';
                            echo '</tr>';
                  }
                ?>
              </tbody>
            </table>
            <a class="pull-right" href="<?php echo site_url('quote') ?>">View All</a>
        </div>
        
        <div class="col-md-6">
            <h2><strong>Recent</strong> Invoices</h2>
            <table class="table table-striped table-bordered dataTable" style="width:100%;">
              <thead>
                <tr>
                  <td>Invoice #</td>
                  <th>Amount</th>
                  <th>Customer</th>
                  <th>Date</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                <?php
                  
        		  $quotation = $this->Xin_model->get_last_5_invoices($session['user_id']);
                  
                  foreach($quotation->result() as $r) {
                       $customer_data = $this->Customers_model->read_customer_information($r->customer_id);
                       
                       if(!empty($customer_data))
                       {
                           $customer_name = $customer_data[0]->company_name;
                       }
                       else
                       {
                           $customer_name = '--';
                       }
                       
                            $edit_url = site_url('invoices/view/'.$r->id);
                            
                            $status = '<a href="'.$edit_url.'" class="btn btn-sm btn-primary">Draft</a>';
                            
                            if($r->status=='sent')
                            {
                                $status = '<a href="'.$edit_url.'" class="btn btn-sm btn-success">Sent</a>';
                            }
                            
                            echo '<tr>';
                            echo '<td><a href="'.$edit_url.'">'.$r->invoice_number.'</a></td>';
        			   		echo '<td>'.$r->currency.' '.number_format($r->g_total,2).'</td>';
        			   		echo '<td><a href="'.$edit_url.'">'.$customer_name.'</a></td>';
        			   		echo '<td>'.date('d-m-Y',strtotime($r->invoice_date)).'</td>';
                            echo '<td>'.$status.'</td>';
                            echo '</tr>';
                  }
                ?>
              </tbody>
            </table>
            <a class="pull-right" href="<?php echo site_url('invoices') ?>">View All</a>
        </div>
    </div>
    
</div>






<style type="text/css">


.box1 {
  width: 24%;
  height: 140px;
  margin: 0.2%;
  padding: 15px;
  box-sizing: border-box;
  display: inline-block;
  background: linear-gradient(to bottom, #00cc99 0%, #336699 100%);
  position: relative;
  overflow: hidden;
  box-shadow: 0 0 5px rgba(0,0,0,0.4);
  cursor: pointer;
}
.box1 .icon-cont {
  border: 6px solid rgba(255,255,255,0.3);
  border-radius: 50%;
  width: 60px;
  height: 60px;
  margin: 17px auto;
  display: block; 
  text-align: center;
  position: absolute;
  top: -5px;
  left: 0;
  right: 0;
  z-index: 5;
  
  box-shadow: 0 0 0 0px rgba(255,255,255,0.5), 0 0 0 0px rgba(3, 108, 129, 0.5);
}
.box1 .icon-cont i {
  color: #fff;
  opacity: 0.6;
  font-size: 2.1em;
  line-height: 50px;
}
.box1:hover .icon-cont {
  animation: shady 4s linear infinite;
}

@keyframes shady {
  0% {box-shadow: 0 0 0 0px rgba(255,255,255,0.5), 0 0 0 0px rgba(3, 108, 129, 0.5);}
  20% {box-shadow: 0 0 0 100px rgba(255,255,255,0), 0 0 0 0px rgba(3, 108, 129, 0);}
  20.1% {box-shadow: 0 0 0 0px rgba(255,255,255,0.5), 0 0 0 0px rgba(3, 108, 129, 0.5);}
  50% {box-shadow: 0 0 0 0px rgba(255,255,255,0.5), 0 0 0 0px rgba(3, 108, 129, 0.5);}
  70% {box-shadow: 0 0 0 100px rgba(255,255,255,0), 0 0 0 0px rgba(3, 108, 129, 0);}
  70.1% {box-shadow: 0 0 0 0px rgba(255,255,255,0.5), 0 0 0 0px rgba(3, 108, 129, 0.5);}
  100% {box-shadow: 0 0 0 0px rgba(255,255,255,0.5), 0 0 0 0px rgba(3, 108, 129, 0.5);}
}

.box1 h3 {
  color: white;
  font-family: 'Open Sans', Arial, sans-serif;
  font-weight: 300;
  font-size: 12px;
  text-align: center;
  text-transform: uppercase;
  letter-spacing: 2px;
  padding: 0px;
  border-bottom: 1px solid rgba(255,255,255,0);
  
  position: absolute;
  top: 76px;
  width: 80%;
  left: 10%;
  z-index: 4;
}

.box1 {
   
   background:#e3e3e3;
}

.box1 a.expand {
  width: 90px;
  height: 25px;
  background: #fff;
  font-weight: 600;
  color: #036C81;
  display: block;
  margin: 0px auto 25px;
  text-align: center;
  line-height: 25px;
  cursor: pointer;
  font-size: 18px;
  position: absolute;
  border-radius: 20px;
  left: 0;
  right: 0;
  bottom: 10px; 
  top: 102px
  
}

.box2 {
  box-shadow: 0 19px 38px rgba(0,0,0,0.30), 0 15px 12px rgba(0,0,0,0.22);
}

.basicBox, .swiggleBox, .checkBox {
  width: 130px;
  height: 65px;
  margin: 15px auto;
  color: #4274D3;
  font-family: 'Open Sans', sans-serif;
  font-size: 1.15rem;
  line-height: 65px;
  text-transform: uppercase;
  text-align: center;
  position: relative;
  cursor: pointer;
}

*, *::before, *::after {
  box-sizing: border-box;
}

body {
  background: #FDFDFD;
  margin: 25px 0;
}

span.title {
  margin: 0 auto;
  color: #BBB;
  font-family: 'Open Sans', sans-serif;
  font-size: 0.85rem;
  text-align: center;
  display: block;
}

.basicBox, .swiggleBox, .checkBox {
  width: 130px;
  height: 65px;
  margin: 15px auto;
  color: #4274D3;
  font-family: 'Open Sans', sans-serif;
  font-size: 1.15rem;
  line-height: 65px;
  text-transform: uppercase;
  text-align: center;
  position: relative;
  cursor: pointer;
}

svg {
  position: absolute;
  top: 0;
  left: 0;
}
svg rect, svg path, svg polyline {
  fill: none;
  stroke: black;
  stroke-width: 1;
}

.basicBox:hover svg rect, .swiggleBox:hover svg path, .checkBox:hover svg polyline {
  stroke: black;
}

/* Basic Box */
svg rect {
  stroke-dasharray: 400, 0;
  -webkit-transition: all 0.8s ease-in-out;
  -moz-transition: all 0.8s ease-in-out;
  -ms-transition: all 0.8s ease-in-out;
  -o-transition: all 0.8s ease-in-out;
}
.basicBox:hover svg rect {
  stroke-width: 3;
  stroke-dasharray: 35, 245;
  stroke-dashoffset: 38;
  -webkit-transition: all 0.8s ease-in-out;
  -moz-transition: all 0.8s ease-in-out;
  -ms-transition: all 0.8s ease-in-out;
  -o-transition: all 0.8s ease-in-out;
}

/* Swiggle Box */
svg path {
  stroke-dasharray: 265, 0;
  -webkit-transition: all 1s ease-in-out;
  -moz-transition: all 1s ease-in-out;
  -ms-transition: all 1s ease-in-out;
  -o-transition: all 1s ease-in-out;
}
.swiggleBox:hover svg path {
  stroke-width: 3;
  stroke-dasharray: 0, 350;
  stroke-dashoffset: 20;
  -webkit-transition: all 1s ease-in-out;
  -moz-transition: all 1s ease-in-out;
  -ms-transition: all 1s ease-in-out;
  -o-transition: all 1s ease-in-out;
}
.card-1 {
  box-shadow: 0 1px 3px rgba(0,0,0,0.12), 0 1px 2px rgba(0,0,0,0.24);
  transition: all 0.3s cubic-bezier(.25,.8,.25,1);
}
.card-1:hover {
  box-shadow: 0 14px 28px rgba(0,0,0,0.25), 0 10px 10px rgba(0,0,0,0.22);
}

</style>
