<?php
/*
* Package View
*/
$session = $this->session->userdata('username');
?>

<div class="row m-b-1 animated fadeInRight">
  <div class="col-md-5">
    <div class="box box-block bg-white">
      <h2> Packages </h2>
      <form class="m-b-1" action="<?php echo site_url("package/update") ?>" method="post" name="update" id="xin-form">
        <input type="hidden" name="edit_type" value="package"/>
        
        <table class="table table-striped table-bordered dataTable" id="xin_table">
          <thead>
            <tr>
              <th>Package</th>
              <th>Employees</th>
              <th>Price</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach($all_packages as $package) {?>
            <tr>
              <td>
                <div class="radio">
                  <label><input type="radio" name="plan" value="<?php echo $package->id?>" <?php if($package->id==$root_account[0]->package_id){ echo 'checked="checked"'; } ?> > &nbsp; <?php echo $package->package_name?></label>
                </div> 
              </td>
              <td><?php echo $package->employees?></td>
              <td>$<?php echo $package->price?> /month</td>
            </tr>
            <?php } ?>
          </tbody>
        </table>
        
        <button type="submit" class="btn btn-success update"><?php echo $this->lang->line('xin_update');?></button>
      </form>
    </div>
  </div>
</div>
