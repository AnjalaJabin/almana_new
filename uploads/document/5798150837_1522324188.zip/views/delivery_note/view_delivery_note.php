<?php
$session = $this->session->userdata('username');
$role_resources_ids = $this->Xin_model->user_role_resource();
if($quote_data[0]->added_by==$session['user_id'] || in_array('103',$role_resources_ids) || in_array('102',$role_resources_ids)){
}
else{
    header('location:'.site_url('dashboard'));
    exit();
}

$crm_settings = $this->Xin_model->read_setting_info(1);
?>

<div class="box box-block bg-white">
    <div class="row">
        <div class="col-md-12" align="right">
            
            <?php
            $status = '<button class="btn btn-md btn-primary pull-left">Draft</button>';
                    
            if($quote_data[0]->status=='sent')
            {
                $status = '<button class="btn btn-md btn-success pull-left">Sent</button>';
            }
            
            echo $status;
            ?>
            
            <button class="m-b-0-0 waves-effect waves-light btn btn-md btn-success" data-toggle="modal" data-target="#edit-modal-data" data-quote_id="<?php echo $quote_data[0]->id; ?>"><i class="fa fa-envelope icon"></i> Send Email</button>
            <?php
            if($quote_data[0]->added_by==$session['user_id'] || in_array('104',$role_resources_ids)){
            ?>
            <a href="<?php echo site_url('delivery_note/edit/'.$quote_data[0]->id); ?>" class="m-b-0-0 waves-effect waves-light btn btn-md btn-info"><i class="fa fa-edit icon"></i> Edit</a>
            <?php
            }
            ?>
            <a target="blank" href="<?php echo site_url('delivery_note/print_delivery_note/'.$quote_data[0]->id); ?>" class="m-b-0-0 waves-effect waves-light btn btn-md btn-warning"><i class="fa fa-print icon"></i> Print</a>
            <a href="<?php echo site_url('delivery_note/print_delivery_note/'.$quote_data[0]->id.'?download=true'); ?>" class="m-b-0-0 waves-effect waves-light btn btn-md btn-primary"><i class="fa fa-download icon"></i> Download</a>
            <a href="<?php echo site_url('delivery_note/copy/'.$quote_data[0]->id); ?>" class="m-b-0-0 waves-effect waves-light btn btn-md btn-info"><i class="fa fa-copy icon"></i> Copy</a>
            <?php
            if($quote_data[0]->added_by==$session['user_id'] || in_array('105',$role_resources_ids)){
            ?>
            <button class="m-b-0-0 waves-effect waves-light btn btn-md btn-danger delete" data-toggle="modal" data-target=".delete-modal" data-record-id="<?php echo $quote_data[0]->id; ?>"><i class="fa fa-trash icon"></i> Delete</button>
            <?php
            }
            ?>
            <!-- <button class="m-b-0-0 waves-effect waves-light btn btn-md btn-success"><i class="fa fa-refresh icon"></i> Convert to Invoice</button> -->
        </div>
    </div>
    
    <div class="row">
        <div class="col-md-12">
          
<?php

$customer_data = $this->Customers_model->read_customer_information($quote_data[0]->customer_id);
		
$session = $this->session->userdata('username');
$user = $this->Xin_model->read_user_info($session['user_id']);

$company = $this->Xin_model->read_company_info($user[0]->pricing_company);

//$pdf = new Pdf('P', 'mm', 'A4', true, 'UTF-8', false);
$company_name = $company[0]->name;
// set default header data
$c_info_email = $company[0]->email;
$c_info_phone = $company[0]->contact_number;
$country = $this->Xin_model->read_country_info($company[0]->country);

    $c_info_address = '';
		
	if(!empty($company[0]->address_1)){
	    $c_info_address.= $company[0]->address_1.'<br>';
	}
	if(!empty($company[0]->address_2)){
	    $c_info_address.= $company[0]->address_2.'<br>';
	}
	if(!empty($company[0]->city)){
	    $c_info_address.= $company[0]->city.',';
	}
	if(!empty($company[0]->zipcode)){
	    $c_info_address.= $company[0]->zipcode.',';
	}
	if(!empty($country[0]->country_name)){
	    $c_info_address.= $country[0]->country_name;
	}

//$c_info_address = $company[0]->address_1.' '.$company[0]->address_2.', '.$company[0]->city.' - '.$company[0]->zipcode.', '.$country[0]->country_name;
$email_phone_address = "<b>".$company_name."</b><br>".$this->lang->line('dashboard_email')." : $c_info_email <br>".$this->lang->line('xin_phone')." : $c_info_phone <br>".$this->lang->line('xin_address').": $c_info_address".'<br>TRN : '.$company[0]->government_tax;
$header_string = $email_phone_address;

$company_logo = '<img src="https://accounts.corbuz.com/accounts/uploads/company/'.$company[0]->logo.'" width="200"/>';
if(empty($company[0]->logo) || $company[0]->logo=='no file'){
    $company_logo = '<img src="https://accounts.corbuz.com/accounts/uploads/company/default-logo.png" width="200"/>';
}

$shipping_address = '';
if(!empty($quote_data[0]->shipping_address)){
    $shipping_address = '<br><br><h4>Ship To</h4>'.nl2br($quote_data[0]->shipping_address);
}

$refernce_no = '';
if(!empty($quote_data[0]->reference)){
    $refernce_no = 'Reference # : '.$quote_data[0]->reference.'<br>';
}

$tbl = '<br>
        <table cellpadding="1" cellspacing="1" border="0" width="100%">
			<tr>
				<td align="left">
				'.$company_logo.'
				<br><br>'.$header_string.'
				<b><br><br><h4>To:</h4></b>
				<b>'.$customer_data[0]->company_name.'</b>
				<br>Address : '.$customer_data[0]->address.'
				<br>Phone : '.$customer_data[0]->phone.'
				<br>Email : '.$customer_data[0]->email.'
				</td>
				
				<td align="right" valign="top">
				<h1 style="font-size:35px;">'.$crm_settings[0]->delivery_note_title.'</h1>
				<b>'.$crm_settings[0]->delivery_note_prefix.'-'.$quote_data[0]->delivery_note_number.'</b><br>
				'.$refernce_no.'
				Date : '.date("d-m-Y", strtotime($quote_data[0]->delivery_date)).'<br>
				'.$shipping_address.'
				</td>
			</tr>
		</table>
		';
		
		
		// -----------------------------------------------------------------------------
		
		$fname = $user[0]->first_name.' '.$user[0]->last_name;
		$tbl.= '<br><br>
		<table cellpadding="10" cellspacing="0" border="0" width="100%">
			<tr style="background-color:#444; color:#fff;">
                <td width="50%"><b>Item</b></td>
                <td align="center" width="10%"><b>Qty</b></td>
            </tr>
		';
		
		foreach($quote_items as $item){
		    $item_name = '';
		    if(!empty($item->item_name)){
		        $item_name = '<b>'.$item->item_name.'</b><br>';
		    }
		    $tbl.= '
		    <tr>
                <td>'.$item_name.$item->description.'</td>
                <td align="center">'.$item->qty.' '.$item->unit.'</td>
            </tr>';
		}
		
		$tbl.= '</table>';
		
		if(!empty($quote_data[0]->after_item_contents)){
    		
    		$tbl .= '<br><br><table cellpadding="1" cellspacing="1" border="0">
    			<tr>
    				<td align="left">'.$quote_data[0]->after_item_contents.'</td>
    			</tr>
    		</table>';
    		
		}
		
		$my_sign = '';
		$company_seal = '';
		
		if($quote_data[0]->add_personal_sign==1){
		    
		    $quote_user = $this->Xin_model->read_user_info($quote_data[0]->added_by);
		    if(!empty($quote_user[0]->sign_photo) && $quote_data[0]->add_personal_sign==1){
		        $my_sign = '<img src="https://accounts.corbuz.com/accounts/uploads/profile/sign/'.$quote_user[0]->sign_photo.'" width="180"/><br>'.$this->lang->line('xin_payslip_authorised_signatory');
		    }
		}
		
		if($quote_data[0]->add_company_seal==1){
		    
		    if(!empty($company[0]->company_seal)){
		        $company_seal = '<img src="https://accounts.corbuz.com/accounts/uploads/company/seal/'.$company[0]->company_seal.'" width="150"/><br>';
		    }
		}
		    
    		$tbl.= '<br><br>
    		<table cellpadding="4" cellspacing="0" border="0" width="100%">
    			<tr>
    			    <td align="right" colspan="2">'.$company_seal.'</td>
    				<td align="right">'.$my_sign.'</td>
    			</tr>
    		</table>
    		';
		
		echo $tbl;
?>

        </div>
    </div>
</div>