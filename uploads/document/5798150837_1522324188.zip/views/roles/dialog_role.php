<?php
defined('BASEPATH') OR exit('No direct script access allowed');
if(isset($_GET['jd']) && isset($_GET['role_id']) && $_GET['data']=='role'){
$role_resources_ids = explode(',',$role_resources);
?>

<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">×</span> </button>
  <h4 class="modal-title" id="edit-modal-data">Edit User Role</h4>
</div>
<form class="m-b-1" action="<?php echo site_url("roles/update").'/'.$role_id; ?>" method="post" name="edit_role" id="edit_role">
  <input type="hidden" name="_method" value="EDIT">
  <input type="hidden" name="_token" value="<?php echo $role_id;?>">
  <input type="hidden" name="ext_name" value="<?php echo $role_name;?>">
  <div class="modal-body">
    <div class="row">
      <div class="col-md-4">
        <div class="row">
          <div class="col-md-12">
            <div class="form-group">
              <label for="role_name">Role Name</label>
              <input class="form-control" placeholder="Role Name" name="role_name" type="text" value="<?php echo $role_name;?>">
            </div>
          </div>
        </div>
        <div class="row">
        	<input type="checkbox" name="role_resources[]" value="0" checked style="display:none;"/>
          <div class="col-md-12">
            <div class="form-group">
              <label for="role_access">Select Access</label>
              <select class="form-control custom-select" id="role_access_modal" name="role_access" data-plugin="select_hrm" data-placeholder="Select Access">
                <option value="">&nbsp;</option>
                <option value="1" <?php if($role_access==1):?> selected="selected" <?php endif;?>>All Menu Access</option>
                <option value="2" <?php if($role_access==2):?> selected="selected" <?php endif;?>>Custom Menu Access</option>
              </select>
            </div>
          </div>
        </div>
      </div>
      <div class="col-md-8">
        <div class="row">
          <div class="col-md-12">
            <div class="form-group">
              <label for="resources">Resources</label>
              <div id="all_resources">
                <div class="demo-section k-content">
                  <div>
                    <div id="treeview_m1"></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="row">
          <div class="col-md-12">
            <div class="form-group">
              <div id="all_resources">
                <div class="demo-section k-content">
                  <div>
                    <div id="treeview_m2"></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="modal-footer">
    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
    <button type="submit" class="btn btn-primary">Update</button>
  </div>
</form>
<link rel="stylesheet" href="<?php echo base_url();?>skin/vendor/select2/dist/css/select2.min.css">
<script type="text/javascript" src="<?php echo base_url();?>skin/vendor/select2/dist/js/select2.min.js"></script>
<script type="text/javascript">
 $(document).ready(function(){
					
		// On page load: datatable
		var xin_table = $('#xin_table').dataTable({
			"bDestroy": true,
			"ajax": {
				url : "<?php echo site_url("roles/role_list") ?>",
				type : 'GET'
			},
			"fnDrawCallback": function(settings){
			$('[data-toggle="tooltip"]').tooltip();          
			}
    	});
		
		$('[data-plugin="select_hrm"]').select2($(this).attr('data-options'));
		$('[data-plugin="select_hrm"]').select2({ width:'100%' });	 

		/* Edit data */
		$("#edit_role").submit(function(e){
		e.preventDefault();
			var obj = $(this), action = obj.attr('name');
			$('.save').prop('disabled', true);
			
			$.ajax({
				type: "POST",
				url: e.target.action,
				data: obj.serialize()+"&is_ajax=1&edit_type=role&form="+action,
				cache: false,
				success: function (JSON) {
					if (JSON.error != '') {
						toastr.error(JSON.error);
						$('.save').prop('disabled', false);
					} else {
						xin_table.api().ajax.reload(function(){ 
							toastr.success(JSON.result);
						}, true);
						$('.edit-modal-data').modal('toggle');
						$('.save').prop('disabled', false);
					}
				}
			});
		});
	});	
  </script>
  <script>

jQuery("#treeview_m1").kendoTreeView({
checkboxes: {
checkChildren: true,
template: "<label class='custom-control custom-checkbox'><input type='checkbox' #= item.check# class='#= item.class #' name='role_resources[]' value='#= item.value #'  /><span class='custom-control-indicator'></span><span class='custom-control-description'>#= item.text #</span><span class='custom-control-info'>#= item.add_info #</span></label>"
},
check: onCheck,
dataSource: [

{ id: "", class: "role-checkbox-modal custom-control-input", text: "Organization", check: "<?php if(isset($_GET['role_id'])) { if(in_array('1',$role_resources_ids)): echo 'checked'; else: echo ''; endif; }?>", add_info: "", value: "1", items: [
// sub 1
{ id: "", class: "role-checkbox-modal custom-control-input", text: "Company", check: "<?php if(isset($_GET['role_id'])) { if(in_array('3',$role_resources_ids)): echo 'checked'; else: echo ''; endif; }?>", add_info: "Add/Edit/Delete", value: "3",},
{ id: "", class: "role-checkbox-modal custom-control-input", text: "Designation", check: "<?php if(isset($_GET['role_id'])) { if(in_array('6',$role_resources_ids)): echo 'checked'; else: echo ''; endif; }?>", add_info: "Add/Edit/Delete", value: "6",},
{ id: "", class: "role-checkbox-modal custom-control-input", text: "Settings", check: "<?php if(isset($_GET['role_id'])) { if(in_array('53',$role_resources_ids)): echo 'checked'; else: echo ''; endif; }?>", add_info: "Add/Edit/Delete", value: "53",},
]}, // sub 1 end
{ id: "", class: "role-checkbox-modal custom-control-input", text: "Employees",  add_info: "", value: "11", check: "<?php if(isset($_GET['role_id'])) { 
if(in_array('11',$role_resources_ids)): echo 'checked'; else: echo ''; endif; }?>", items: [
{ id: "", class: "role-checkbox-modal custom-control-input", text: "Employees List", check: "<?php if(isset($_GET['role_id'])) { if(in_array('13',$role_resources_ids)): echo 'checked'; else: echo ''; endif; }?>", add_info: "Add/Edit/View/Delete", value: "13",},
{ id: "", class: "role-checkbox-modal custom-control-input", text: "Set Roles", check: "<?php if(isset($_GET['role_id'])) { if(in_array('14',$role_resources_ids)): echo 'checked'; else: echo ''; endif; }?>", add_info: "Add/Edit/Delete", value: "14",},
]},

{ id: "", class: "role-checkbox-modal custom-control-input", text: "Suppliers",  add_info: "", value: "58", check: "<?php if(isset($_GET['role_id'])) { 
if(in_array('58',$role_resources_ids)): echo 'checked'; else: echo ''; endif; }?>", items: [
{ id: "", class: "role-checkbox-modal custom-control-input", text: "Add Suppliers", check: "<?php if(isset($_GET['role_id'])) { if(in_array('59',$role_resources_ids)): echo 'checked'; else: echo ''; endif; }?>", add_info: "Add/View", value: "59",},
{ id: "", class: "role-checkbox-modal custom-control-input", text: "Edit Suppliers", check: "<?php if(isset($_GET['role_id'])) { if(in_array('60',$role_resources_ids)): echo 'checked'; else: echo ''; endif; }?>", add_info: "Edit/View", value: "60",},
{ id: "", class: "role-checkbox-modal custom-control-input", text: "Delete Suppliers", check: "<?php if(isset($_GET['role_id'])) { if(in_array('61',$role_resources_ids)): echo 'checked'; else: echo ''; endif; }?>", add_info: "Delete/View", value: "61",},
]},

{ id: "", class: "role-checkbox-modal custom-control-input", text: "Products",  add_info: "", value: "62", check: "<?php if(isset($_GET['role_id'])) { 
if(in_array('62',$role_resources_ids)): echo 'checked'; else: echo ''; endif; }?>", items: [
{ id: "", class: "role-checkbox-modal custom-control-input", text: "Add Products", check: "<?php if(isset($_GET['role_id'])) { if(in_array('63',$role_resources_ids)): echo 'checked'; else: echo ''; endif; }?>", add_info: "Add/View", value: "63",},
{ id: "", class: "role-checkbox-modal custom-control-input", text: "Edit Products", check: "<?php if(isset($_GET['role_id'])) { if(in_array('64',$role_resources_ids)): echo 'checked'; else: echo ''; endif; }?>", add_info: "Edit/View", value: "64",},
{ id: "", class: "role-checkbox-modal custom-control-input", text: "Delete Products", check: "<?php if(isset($_GET['role_id'])) { if(in_array('65',$role_resources_ids)): echo 'checked'; else: echo ''; endif; }?>", add_info: "Delete/View", value: "65",},
]},

{ id: "", class: "role-checkbox-modal custom-control-input", text: "Pricing",  add_info: "", value: "66", check: "<?php if(isset($_GET['role_id'])) { 
if(in_array('66',$role_resources_ids)): echo 'checked'; else: echo ''; endif; }?>", items: [
{ id: "", class: "role-checkbox-modal custom-control-input", text: "Update Pricing", check: "<?php if(isset($_GET['role_id'])) { if(in_array('67',$role_resources_ids)): echo 'checked'; else: echo ''; endif; }?>", add_info: "Add/View", value: "67",},
{ id: "", class: "role-checkbox-modal custom-control-input", text: "Delete Pricing", check: "<?php if(isset($_GET['role_id'])) { if(in_array('68',$role_resources_ids)): echo 'checked'; else: echo ''; endif; }?>", add_info: "Delete/View", value: "68",},
]},

]
});

		
// show checked node IDs on datasource change
function onCheck() {
var checkedNodes = [],
treeView = jQuery("#treeview").data("kendoTreeView"),
message;
//checkedNodeIds(treeView.dataSource.view(), checkedNodes);
jQuery("#result").html(message);
}
$(document).ready(function(){
	$("#role_access_modal").change(function(){
		var sel_val = $(this).val();
		if(sel_val=='1') {
			$('.role-checkbox-modal').prop('checked', true);
		} else {
			$('.role-checkbox-modal').attr("checked", false);
		}
	});
});
</script>
<?php }
?>
