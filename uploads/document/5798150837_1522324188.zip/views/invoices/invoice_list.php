<div class="box box-block bg-white">
  <h2><strong><?php echo $this->lang->line('xin_list_all');?></strong> Quotations
  </h2>
  
    <div class="add-record-btn"> <?php if($show_all_list==1){ ?><label><input <?php if($show_all_check==1){ echo 'checked'; } ?> type="checkbox" value="1" class="view_all_list_check"> View All </label> <?php } ?>
      <a href="<?php echo site_url('invoices/create_invoice'); ?>" class="m-b-0-0 waves-effect waves-light btn btn-md btn-info"><i class="fa fa-plus icon"></i> New Invoice</a>
    </div>
  
  <div class="table-responsive" data-pattern="priority-columns">
    <table class="table table-striped table-bordered dataTable" id="xin_table" style="width:100%;">
      <thead>
        <tr>
          <th> #</th>
          <th>Amount</th>
          <th>Total Tax</th>
          <th>Customer</th>
          <th>Date</th>
          <th>Reference #</th>
          <th>Added By</th>
          <th>Status</th>
        </tr>
      </thead>
    </table>
  </div>
</div>