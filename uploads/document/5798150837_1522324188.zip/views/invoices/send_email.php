<?php
defined('BASEPATH') OR exit('No direct script access allowed');
if(isset($error_view)){
    ?>
    <div class="modal-header">
      <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">×</span> </button>
    </div>
    <?php
    echo $error_view;
    ?>
      <div class="modal-footer">
        <button type="button" class="btn btn-lg btn-link" data-dismiss="modal"><?php echo $this->lang->line('xin_close');?></button>
      </div>
    <?php
}
else if(isset($_GET['jd']) && isset($_GET['quote_id']) && $_GET['data']=='quote'){
?>

<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">×</span> </button>
  <h4 class="modal-title"> Send invoice to client</h4>
</div>
<form class="m-b-1" action="<?php echo site_url("invoices/submit_email"); ?>" method="post" name="send_quote_email" id="send_quote_email" enctype="multipart/form-data">
  <input type="hidden" name="_method" value="EDIT">
  <input type="hidden" name="_token" value="<?php echo $quote_id;?>">
  <input type="hidden" name="ext_name" value="<?php echo $quote_id;?>">
  <input type="hidden" name="quote_id" value="<?php echo $quote_id;?>">
  <div class="modal-body">
      <div class="row">
        <div class="col-sm-12">
          <div class="form-group">
            <label for="name">Email to</label>
            <input class="form-control" placeholder="Email" name="to_email" value="<?php echo $email; ?>" type="text">
          </div>
          
          <div class="form-group">
            <label for="name">CC</label>
            <input class="form-control" placeholder="CC" name="cc_email" value="" type="text">
          </div>
          
          <div class="form-group">
            <label for="name">Subject</label>
            <input class="form-control" placeholder="Subject" name="email_subject" value="<?php echo 'Invoice #'.$quote_number.' Generated for you' ?>" type="text">
          </div>
          
          <div class="form-group">
            <label for="phone">Invoice Attachment</label> <br> 
           	<a href="<?php echo site_url('invoices/print_invoice/'.$quote_id.'?download=true'); ?>"><i class="fa fa-file-pdf-o icon"></i> File</a>
           	<input class="form-control" name="mail_files[]" type="file" multiple>
          </div>
          
          <?php
          $cust_name = $customer_name;
          if(empty($customer_name))
          {
              $cust_name = $company_name;
          }
          //$email_body = '<p><span style="color: rgb(34, 34, 34); font-family: sans-serif; font-size: 12pt;">Dear '.$cust_name.'</span><br style="color: rgb(34, 34, 34); font-family: sans-serif; font-size: 14px;"><br style="color: rgb(34, 34, 34); font-family: sans-serif; font-size: 14px;"><span style="color: rgb(34, 34, 34); font-family: sans-serif; font-size: 12pt;">Please find the attached quotation&nbsp;<strong># QUOTE-'.$quote_number.'&nbsp;</strong>as per the requirements.</span><br style="color: rgb(34, 34, 34); font-family: sans-serif; font-size: 14px;"><br style="color: rgb(34, 34, 34); font-family: sans-serif; font-size: 14px;"><span style="color: rgb(34, 34, 34); font-family: sans-serif; font-size: 12pt;">We look forward to your communication.</span><br style="color: rgb(34, 34, 34); font-family: sans-serif; font-size: 14px;"><br style="color: rgb(34, 34, 34); font-family: sans-serif; font-size: 14px;"><span style="color: rgb(34, 34, 34); font-family: sans-serif; font-size: 12pt;">Kind Regards,</span><br><span style="font-size: 12pt;">'.$signature.'</span><br></p>';
          $email_body = '<p></p><div style="box-sizing: inherit; outline: none !important; font-size: 13px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); text-decoration-style: initial; text-decoration-color: initial; color: rgb(34, 34, 34); font-family: arial, sans-serif;"></div><p></p><p style="box-sizing: inherit; margin-top: 0px; margin-bottom: 1rem; font-family: &quot;Open Sans&quot;, sans-serif; font-size: 13px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); text-decoration-style: initial; text-decoration-color: initial; outline: none !important;"><span style="color: rgb(34, 34, 34); font-family: Arial, sans-serif; font-size: 14px;">Dear '.$cust_name.'</span><br style="color: rgb(34, 34, 34); font-family: Arial, sans-serif; font-size: 14px;"><br style="color: rgb(34, 34, 34); font-family: Arial, sans-serif; font-size: 14px;"><span style="color: rgb(34, 34, 34); font-family: Arial, sans-serif; font-size: 14px;">Please find our attached <b>#'.$quote_number.'</b>.</span><span class="im" style="font-family: Arial, sans-serif; font-size: 14px;"><br><br><span style="color: rgb(0, 0, 0);">Please dont hesitate to contact us if you have any questions.<br></span></span><span class="im" style="font-family: Arial, sans-serif; font-size: 14px;"><span style="color: rgb(0, 0, 0);">We look forward to your communication.</span><br><br></span></p>'.$signature;
          ?>
            
          <div class="form-group">
            <label for="phone">Preview Email Template</label>
           	 <textarea class="form-control" placeholder="Email Body" name="email_body" id="signature"><?php echo $email_body; ?></textarea>
          </div>
          
        </div>
      </div>
  </div>
  <div class="modal-footer">
    <button type="button" class="btn btn-lg btn-link" data-dismiss="modal"><?php echo $this->lang->line('xin_close');?></button>
    <button type="submit" class="btn btn-lg btn-success save"><i class="fa fa-arrow-circle-right icon"></i> Send</button>
  </div>
</form>

<script type="text/javascript">
 $(document).ready(function(){
		
		$('[data-plugin="select_hrm"]').select2($(this).attr('data-options'));
		$('[data-plugin="select_hrm"]').select2({ width:'100%' });	 
		
		$('#signature').summernote({
          height: 206,
          minHeight: null,
          maxHeight: null,
          focus: false
        });

		/* Edit data */
		$("#xxxsend_quote_email").submit(function(e){
		e.preventDefault();
			var obj = $(this), action = obj.attr('name');
			$('.save').prop('disabled', true);
			
			$.ajax({
				type: "POST",
				url: e.target.action,
				data: obj.serialize()+"&is_ajax=1&edit_type=customer&form="+action,
				cache: false,
				success: function (JSON) {
					if (JSON.error != '') {
						toastr.error(JSON.error);
						$('.save').prop('disabled', false);
					} else {
						toastr.success(JSON.result);
						$('.edit-modal-data').modal('toggle');
						$('.save').prop('disabled', false);
					}
				}
			});
		});
	});	
	
	
	$(document).on("submit", "#send_quote_email", function (e) {
	e.preventDefault();
		$('.save').prop('disabled', true);
		$('.edit-modal-data').modal('toggle');
		
		var fd = new FormData(this);
		var obj = $(this), action = obj.attr('name');
		fd.append("is_ajax", 1);
		fd.append("edit_type", 'customer');
		fd.append("form", action);
		
		$.ajax({
			url: e.target.action,
			type: "POST",
			data:  fd,
			contentType: false,
			cache: false,
			processData:false,
			success: function (JSON) {
				if (JSON.error != '') {
					toastr.error(JSON.error);
					$('.save').prop('disabled', false);
				} else {
					toastr.success(JSON.result);
					$('.save').prop('disabled', false);
				}
			}
		});
	});
	
		
  </script>
<?php } 
?>