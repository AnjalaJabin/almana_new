<?php
/* Settings view
*/

$crm_setting = $this->Xin_model->read_setting_info(1);
?>
<?php $session = $this->session->userdata('username');?>

<div class="row m-b-1">
  <div class="col-md-3">
    <div class="box bg-white">
      <ul class="nav nav-4">
        <li class="nav-item nav-item-link"> <span class="nav-link" href="#setting" data-config="0" data-toggle="tab" aria-expanded="true"> <strong>SYSTEM SETTINGS</strong> </span> </li>
        <li class="nav-item nav-item-link active-link" id="config_13"> <a class="nav-link nav-tabs-link" href="#crm_settings13" data-config="13" data-config-block="crm_settings13" data-toggle="tab" aria-expanded="true"> <i class="fa fa-list"></i> Quotation Settings </a> </li>
        <li class="nav-item nav-item-link" id="config_14"> <a class="nav-link nav-tabs-link" href="#crm_settings14" data-config="14" data-config-block="crm_settings14" data-toggle="tab" aria-expanded="true"> <i class="fa fa-file-text"></i> Invoice Settings </a> </li>
        <li class="nav-item nav-item-link" id="config_15"> <a class="nav-link nav-tabs-link" href="#crm_settings15" data-config="15" data-config-block="crm_settings15" data-toggle="tab" aria-expanded="true"> <i class="fa fa-file-o"></i> Proforma Invoice Settings </a> </li>
        <li class="nav-item nav-item-link" id="config_16"> <a class="nav-link nav-tabs-link" href="#crm_settings16" data-config="16" data-config-block="crm_settings16" data-toggle="tab" aria-expanded="true"> <i class="fa fa-book"></i> Purchase Order Settings </a> </li>
        <li class="nav-item nav-item-link" id="config_17"> <a class="nav-link nav-tabs-link" href="#crm_settings17" data-config="17" data-config-block="crm_settings17" data-toggle="tab" aria-expanded="true"> <i class="fa fa-truck"></i> Delivery Note Settings </a> </li>
        
        <?php
        $role_resources_ids = $this->Xin_model->user_role_resource();
        if(in_array('75',$role_resources_ids)) {
        ?>
        <li class="nav-item nav-item-link" id="config_10"> <a class="nav-link nav-tabs-link" href="#product_cat" data-config="10" data-config-block="product_cat" data-toggle="tab" aria-expanded="true"> <i class="fa fa-list"></i> Product Categories </a> </li>
        <li class="nav-item nav-item-link" id="config_12"> <a class="nav-link nav-tabs-link" href="#product_brand" data-config="12" data-config-block="product_brand" data-toggle="tab" aria-expanded="true"> <i class="fa fa-tag"></i> Product Brand </a> </li>
        <li class="nav-item nav-item-link" id="config_3"> <a class="nav-link nav-tabs-link" href="#system" data-config="3" data-config-block="system" data-toggle="tab" aria-expanded="true"> <i class="fa fa-cogs"></i> CRM Configuration </a> </li>
        <!--
        <li class="nav-item nav-item-link" id="config_19"> <a class="nav-link nav-tabs-link" href="#currency_type" data-config="19" data-config-block="currency_type" data-toggle="tab" aria-expanded="true"> <i class="fa fa-dollar"></i> Currency Type </a> </li>
        <li class="nav-item nav-item-link" id="config_4"> <a class="nav-link nav-tabs-link" href="#role" data-config="4" data-config-block="role" data-toggle="tab" aria-expanded="true"> <i class="fa fa-key"></i> Role </a> </li>
        <li class="nav-item nav-item-link" id="config_7"> <a class="nav-link nav-tabs-link" href="#email" data-config="7" data-config-block="email" data-toggle="tab" aria-expanded="true"> <i class="ti-email"></i> Email Notifications </a> </li>
        <li class="nav-item nav-item-link" id="config_8"> <a class="nav-link nav-tabs-link" href="#animation" data-config="8" data-config-block="animation" data-toggle="tab" aria-expanded="true"> <i class="fa fa-diamond"></i> Animation Effects </a> </li>
        <li class="nav-item nav-item-link" id="config_9"> <a class="nav-link nav-tabs-link" href="#notification" data-config="9" data-config-block="notification" data-toggle="tab" aria-expanded="true"> <i class="ti-check"></i> Notification Position </a> </li> -->
        <li class="nav-item nav-item-link" id="config_11"> <a class="nav-link nav-tabs-link" href="#import_products" data-config="11" data-config-block="import_products" data-toggle="tab" aria-expanded="true"> <i class="fa fa-cloud-download"></i> Import Products </a> </li>
        <?php
        }
        ?>
      </ul>
    </div>
  </div>
  
  <!----------------fggsgsgsgs------->
  
  <div class="col-md-9 current-tab animated fadeInRight" id="crm_settings13">
      <div class="box box-block bg-white">
          <h2><strong>Quotation</strong> Configuration</h2>
          <form class="update_crm_data" action="<?php echo site_url("settings/update_crm_data");?>" name="e_change_password" method="post">
            <div class="row">    
              <div class="col-md-12">
                <div class="form-group">
                    <label for="smtp_host">Quotation item before data</label>
                    <textarea class="form-control textarea texteditor" id="quotation_before" name="quotation_before"><?php echo $pricing_item_before;?></textarea>
                </div>
              </div>
              
              <div class="col-md-12">
                <div class="form-group">
                    <label for="smtp_host">Quotation item after data</label>
                    <textarea class="form-control textarea texteditor" id="quotation_after" name="quotation_after"><?php echo $pricing_item_after;?></textarea>
                </div>
              </div>
            </div>
            
            <div class="row">
              <div class="col-md-12">
                <div class="form-group">
                  <button type="submit" class="btn btn-primary save col-right">Update</button>
                </div>
              </div>
            </div>
          </form>
      </div>
  </div>
  
  
  
  <div class="col-md-9 current-tab animated fadeInRight" id="crm_settings14" style="display:none;">
      <div class="box box-block bg-white">
          <h2><strong>Invoice</strong> Configuration</h2>
          <form class="update_crm_data" action="<?php echo site_url("settings/update_crm_data");?>" name="e_change_password" method="post">
            <div class="row">    
              <div class="col-md-12">
                <div class="form-group">
                    <label for="smtp_host">Invoice item after data</label>
                    <textarea class="form-control textarea texteditor" id="quotation_after" name="invoice_after"><?php echo $invoice_after;?></textarea>
                </div>
              </div>
            </div>
            
            <div class="row">
              <div class="col-md-12">
                <div class="form-group">
                  <button type="submit" class="btn btn-primary save col-right">Update</button>
                </div>
              </div>
            </div>
          </form>
      </div>
  </div>
  
  <div class="col-md-9 current-tab animated fadeInRight" id="crm_settings15" style="display:none;">
      <div class="box box-block bg-white">
          <h2><strong>Proforma Invoice</strong> Configuration</h2>
          <form class="update_crm_data" action="<?php echo site_url("settings/update_crm_data");?>" name="e_change_password" method="post">
            <div class="row">    
              <div class="col-md-12">
                <div class="form-group">
                    <label for="smtp_host">Proforma Invoice item after data</label>
                    <textarea class="form-control textarea texteditor" id="quotation_after" name="proforma_invoice_after"><?php echo $proforma_invoice_after;?></textarea>
                </div>
              </div>
            </div>
            
            <div class="row">
              <div class="col-md-12">
                <div class="form-group">
                  <button type="submit" class="btn btn-primary save col-right">Update</button>
                </div>
              </div>
            </div>
          </form>
      </div>
  </div>
  
  <div class="col-md-9 current-tab animated fadeInRight" id="crm_settings16" style="display:none;">
      <div class="box box-block bg-white">
          <h2><strong>Purchase Order</strong> Configuration</h2>
          <form class="update_crm_data" action="<?php echo site_url("settings/update_crm_data");?>" name="e_change_password" method="post">
            <div class="row">    
              <div class="col-md-12">
                <div class="form-group">
                    <label for="smtp_host">Purchase Order item before data</label>
                    <textarea class="form-control textarea texteditor" id="quotation_after" name="purchase_order_before"><?php echo $purchase_order_before;?></textarea>
                </div>
              </div>
              <div class="col-md-12">
                <div class="form-group">
                    <label for="smtp_host">Purchase Order item after data</label>
                    <textarea class="form-control textarea texteditor" id="quotation_after" name="purchase_order_after"><?php echo $purchase_order_after;?></textarea>
                </div>
              </div>
            </div>
            
            <div class="row">
              <div class="col-md-12">
                <div class="form-group">
                  <button type="submit" class="btn btn-primary save col-right">Update</button>
                </div>
              </div>
            </div>
          </form>
      </div>
  </div>
  
  <div class="col-md-9 current-tab animated fadeInRight" id="crm_settings17" style="display:none;">
      <div class="box box-block bg-white">
          <h2><strong>Delivery Note</strong> Configuration</h2>
          <form class="update_crm_data" action="<?php echo site_url("settings/update_crm_data");?>" name="e_change_password" method="post">
            <div class="row">
              <div class="col-md-12">
                <div class="form-group">
                    <label for="smtp_host">Delivery note item after data</label>
                    <textarea class="form-control textarea texteditor" id="quotation_after" name="delivery_note_after"><?php echo $delivery_note_after;?></textarea>
                </div>
              </div>
            </div>
            
            <div class="row">
              <div class="col-md-12">
                <div class="form-group">
                  <button type="submit" class="btn btn-primary save col-right">Update</button>
                </div>
              </div>
            </div>
          </form>
      </div>
  </div>
  
  
  
  <?php
  if(in_array('75',$role_resources_ids)) {
  ?>
  <div class="col-md-9 current-tab animated fadeInRight" id="system" style="display:none;">
    <form id="system_info" action="<?php echo site_url("settings/system_info").'/'.$company_info_id ?>/" name="system_info" method="post">
      <input type="hidden" name="u_basic_info" value="UPDATE">
      <div class="box box-block bg-white">
        <h2><strong>CRM</strong> Configuration</h2>
        <div class="col-sm-6">
            
          <div class="form-group">
            <label for="phone">Quotation Title</label>
            <input type="text" class="form-control" name="quotation_title" placeholder="Enter Quotation Title" value="<?php echo $quotation_title; ?>">
          </div>
          <div class="form-group">
            <label for="phone">Invoice Title</label>
            <input type="text" class="form-control" name="invoice_title" placeholder="Enter Invoice Title" value="<?php echo $invoice_title; ?>">
          </div>
          <div class="form-group">
            <label for="phone">Proforma Invoice Title</label>
            <input type="text" class="form-control" name="proforma_invoice_title" placeholder="Enter Proforma Invoice Title" value="<?php echo $proforma_invoice_title; ?>">
          </div>
          <div class="form-group">
            <label for="phone">Purchase Order Title</label>
            <input type="text" class="form-control" name="purchase_order_title" placeholder="Purchase Order Title" value="<?php echo $purchase_order_title; ?>">
          </div>
          <div class="form-group">
            <label for="phone">Delivery Note Title</label>
            <input type="text" class="form-control" name="delivery_note_title" placeholder="Enter Delivery Note Title" value="<?php echo $delivery_note_title; ?>">
          </div>
          
        </div>
        <div class="col-sm-6">
            
          <div class="form-group">
            <label for="phone">Quotation Prefix</label>
            <input type="text" class="form-control" name="quotation_prefix" placeholder="Enter Quotation Prefix" value="<?php echo $quotation_prefix; ?>">
          </div>
          <div class="form-group">
            <label for="phone">Invoice Prefix</label>
            <input type="text" class="form-control" name="invoice_prefix" placeholder="Enter Invoice Prefix" value="<?php echo $invoice_prefix; ?>">
          </div>
          <div class="form-group">
            <label for="phone">Proforma Invoice Prefix</label>
            <input type="text" class="form-control" name="proforma_invoice_prefix" placeholder="Enter Proforma Invoice Prefix" value="<?php echo $proforma_invoice_prefix; ?>">
          </div>
          <div class="form-group">
            <label for="phone">Purchase Order Prefix</label>
            <input type="text" class="form-control" name="purchase_order_prefix" placeholder="Purchase Order Prefix" value="<?php echo $purchase_order_prefix; ?>">
          </div>
          <div class="form-group">
            <label for="phone">Delivery Note Prefix</label>
            <input type="text" class="form-control" name="delivery_note_prefix" placeholder="Enter Delivery Note Prefix" value="<?php echo $delivery_note_prefix; ?>">
          </div>
          
          
        </div>
        <div class="row">
          <div class="col-md-12">
            <div class="form-group">
              <div class="text-right">
                <button type="submit" class="btn btn-primary save"><?php echo $this->lang->line('xin_update');?> <i class="icon-circle-right2 position-right"></i> <i class="icon-spinner3 spinner position-left"></i></button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </form>
  </div>
  <div class="col-md-9 current-tab animated fadeInRight" id="role" style="display:none;">
    <form id="role_info" action="<?php echo site_url("settings/role_info").'/'.$company_info_id ?>/" name="role_info" method="post">
      <input type="hidden" name="u_basic_info" value="UPDATE">
      <div class="box box-block bg-white">
        <h2><strong>Role</strong> Configuration</h2>
        <div class="col-sm-6">
          <div class="form-group">
            <label for="contact_role">Employee can manage own contact information</label>
            <br>
            <div class="pull-xs-left m-r-1">
              <input type="checkbox" class="js-switch" data-size="small" data-color="#3e70c9" data-secondary-color="#ddd" id="contact_role" <?php if($employee_manage_own_contact=='yes'):?> checked="checked" <?php endif;?> value="yes" />
            </div>
          </div>
          <div class="form-group">
            <label for="bank_account_role">Employee can manage own bank account</label>
            <br>
            <div class="pull-xs-left m-r-1">
              <input type="checkbox" class="js-switch" data-size="small" data-color="#3e70c9" data-secondary-color="#ddd" id="bank_account_role" <?php if($employee_manage_own_bank_account=='yes'):?> checked="checked" <?php endif;?> value="yes">
            </div>
          </div>
          <div class="form-group">
            <label for="edu_role">Employee can manage own qualification</label>
            <br>
            <div class="pull-xs-left m-r-1">
              <input type="checkbox" class="js-switch" data-size="small" data-color="#3e70c9" data-secondary-color="#ddd" id="edu_role" <?php if($employee_manage_own_qualification=='yes'):?> checked="checked" <?php endif;?> value="yes">
            </div>
          </div>
          <div class="form-group">
            <label for="work_role">Employee can manage own work experience</label>
            <br>
            <div class="pull-xs-left m-r-1">
              <input type="checkbox" class="js-switch" data-size="small" data-color="#3e70c9" data-secondary-color="#ddd" id="work_role" <?php if($employee_manage_own_work_experience=='yes'):?> checked="checked" <?php endif;?> value="yes">
            </div>
          </div>
        </div>
        <div class="col-sm-6">
          <div class="form-group">
            <label for="doc_role">Employee can manage own documents</label>
            <br>
            <div class="pull-xs-left m-r-1">
              <input type="checkbox" class="js-switch" data-size="small" data-color="#3e70c9" data-secondary-color="#ddd" id="doc_role" <?php if($employee_manage_own_document=='yes'):?> checked="checked" <?php endif;?> value="yes">
            </div>
          </div>
          <div class="form-group">
            <label for="pic_role">Employee can manage own profile picture</label>
            <br>
            <div class="pull-xs-left m-r-1">
              <input type="checkbox" class="js-switch" data-size="small" data-color="#3e70c9" data-secondary-color="#ddd" id="pic_role" <?php if($employee_manage_own_picture=='yes'):?> checked="checked" <?php endif;?> value="yes">
            </div>
          </div>
          <div class="form-group">
            <label for="profile_role">Employee can manage own profile information</label>
            <br>
            <div class="pull-xs-left m-r-1">
              <input type="checkbox" class="js-switch" data-size="small" data-color="#3e70c9" data-secondary-color="#ddd" id="profile_role" <?php if($employee_manage_own_profile=='yes'):?> checked="checked" <?php endif;?> value="yes">
            </div>
          </div>
          <div class="form-group">
            <label for="social_role">Employee can manage own social information</label>
            <br>
            <div class="pull-xs-left m-r-1">
              <input type="checkbox" class="js-switch" data-size="small" data-color="#3e70c9" data-secondary-color="#ddd" id="social_role" <?php if($employee_manage_own_social=='yes'):?> checked="checked" <?php endif;?> value="yes">
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12">
            <div class="form-group">
              <div class="text-right">
                <button type="submit" class="btn btn-primary save"><?php echo $this->lang->line('xin_save');?> <i class="icon-circle-right2 position-right"></i> <i class="icon-spinner3 spinner position-left"></i></button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </form>
  </div>
  
  
  <div class="col-md-9 current-tab animated fadeInRight" id="email" style="display:none;">
    <form id="email_info" action="<?php echo site_url("settings/email_info").'/'.$company_info_id ?>/" name="email_info" method="post">
      <input type="hidden" name="u_basic_info" value="UPDATE">
      <div class="box box-block bg-white">
        <h2>Email Notifications Configuration</h2>
        <div class="col-sm-6">
          <div class="form-group">
            <label for="company_name">Enable email notifications</label>
            <br>
            <div class="pull-xs-left m-r-1">
              <input type="checkbox" class="js-switch" data-size="small" data-color="#3e70c9" data-secondary-color="#ddd" id="srole_email_notification" <?php if($enable_email_notification=='yes'):?> checked="checked" <?php endif;?> value="yes">
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12">
            <div class="form-group">
              <div class="text-right">
                <button type="submit" class="btn btn-primary save"><?php echo $this->lang->line('xin_save');?> <i class="icon-circle-right2 position-right"></i> <i class="icon-spinner3 spinner position-left"></i></button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </form>
  </div>
  <div class="col-md-9 current-tab animated fadeInRight" id="animation"  aria-expanded="false" style="display:none;">
    <div class="box box-block bg-white">
      <h2><strong>Animation Effects</strong> Configuration</h2>
      <form id="animation_effect_info" action="<?php echo site_url("settings/animation_effect_info");?>" name="animation_effect_info" method="post">
        <input type="hidden" name="u_basic_info" value="UPDATE">
        <div class="row">
          <div class="col-md-12">
            <div class="col-sm-6">
              <input name="employee_manage_own_bank_account" type="hidden" value="yes">
              <div class="form-group">
                <label for="animation_effect_topmenu">Animation Effect</label>
                <br>
                <select class="form-control" name="animation_effect_topmenu" data-plugin="select_hrm" data-placeholder="Animation Effect">
                  <option value="">Select One</option>
                  <option value="fadeInDown" <?php if($animation_effect_topmenu=='fadeInDown'){?> selected <?php }?>>fadeInDown</option>
                  <option value="fadeInUp" <?php if($animation_effect_topmenu=='fadeInUp'){?> selected <?php }?>>fadeInUp</option>
                  <option value="fadeInLeft" <?php if($animation_effect_topmenu=='fadeInLeft'){?> selected <?php }?>>fadeInLeft</option>
                  <option value="fadeInRight" <?php if($animation_effect_topmenu=='fadeInRight'){?> selected <?php }?>>fadeInRight</option>
                  <option value="fadeIn" <?php if($animation_effect_topmenu=='fadeIn'){?> selected <?php }?>>fadeIn</option>
                  <option value="growIn" <?php if($animation_effect_topmenu=='growIn'){?> selected <?php }?>>growIn</option>
                  <option value="rotateIn" <?php if($animation_effect_topmenu=='rotateIn'){?> selected <?php }?>>rotateIn</option>
                  <option value="rotateInUpLeft" <?php if($animation_effect_topmenu=='rotateInUpLeft'){?> selected <?php }?>>rotateInUpLeft</option>
                  <option value="rotateInDownLeft" <?php if($animation_effect_topmenu=='rotateInDownLeft'){?> selected <?php }?>>rotateInDownLeft</option>
                  <option value="rotateInUpRight" <?php if($animation_effect_topmenu=='rotateInUpRight'){?> selected <?php }?>>rotateInUpRight</option>
                  <option value="rotateInDownRight" <?php if($animation_effect_topmenu=='rotateInDownRight'){?> selected <?php }?>>rotateInDownRight</option>
                  <option value="rollIn" <?php if($animation_effect_topmenu=='rollIn'){?> selected <?php }?>>rollIn</option>
                  <option value="swing" <?php if($animation_effect_topmenu=='swing'){?> selected <?php }?>>swing</option>
                  <option value="tada" <?php if($animation_effect_topmenu=='tada'){?> selected <?php }?>>tada</option>
                  <option value="pulse" <?php if($animation_effect_topmenu=='pulse'){?> selected <?php }?>>pulse</option>
                  <option value="flipInX" <?php if($animation_effect_topmenu=='flipInX'){?> selected <?php }?>>flipInX</option>
                  <option value="flipInY" <?php if($animation_effect_topmenu=='flipInY'){?> selected <?php }?>>flipInY</option>
                </select>
                <br />
                <p class="text-muted"><i class="fa fa-arrow-up"></i> Set animation effect for top menu.</p>
                <input type="hidden" name="animation_effect" id="animation_effect" value="fadeInDown" />
              </div>
            </div>
            <div class="col-sm-6">
              <input name="employee_manage_own_bank_account" type="hidden" value="yes">
              <div class="form-group">
                <label for="animation_effect_modal">Animation Effect</label>
                <br>
                <select class="form-control" name="animation_effect_modal" data-plugin="select_hrm" data-placeholder="Animation Effect">
                  <option value="">Select One</option>
                  <option value="fadeInDown" <?php if($animation_effect_modal=='fadeInDown'){?> selected <?php }?>>fadeInDown</option>
                  <option value="fadeInUp" <?php if($animation_effect_modal=='fadeInUp'){?> selected <?php }?>>fadeInUp</option>
                  <option value="fadeInLeft" <?php if($animation_effect_modal=='fadeInLeft'){?> selected <?php }?>>fadeInLeft</option>
                  <option value="fadeInRight" <?php if($animation_effect_modal=='fadeInRight'){?> selected <?php }?>>fadeInRight</option>
                  <option value="fadeIn" <?php if($animation_effect_modal=='fadeIn'){?> selected <?php }?>>fadeIn</option>
                  <option value="growIn" <?php if($animation_effect_modal=='growIn'){?> selected <?php }?>>growIn</option>
                  <option value="rotateIn" <?php if($animation_effect_modal=='rotateIn'){?> selected <?php }?>>rotateIn</option>
                  <option value="rotateInUpLeft" <?php if($animation_effect_modal=='rotateInUpLeft'){?> selected <?php }?>>rotateInUpLeft</option>
                  <option value="rotateInDownLeft" <?php if($animation_effect_modal=='rotateInDownLeft'){?> selected <?php }?>>rotateInDownLeft</option>
                  <option value="rotateInUpRight" <?php if($animation_effect_modal=='rotateInUpRight'){?> selected <?php }?>>rotateInUpRight</option>
                  <option value="rotateInDownRight" <?php if($animation_effect_modal=='rotateInDownRight'){?> selected <?php }?>>rotateInDownRight</option>
                  <option value="rollIn" <?php if($animation_effect_modal=='rollIn'){?> selected <?php }?>>rollIn</option>
                  <option value="swing" <?php if($animation_effect_modal=='swing'){?> selected <?php }?>>swing</option>
                  <option value="tada" <?php if($animation_effect_modal=='tada'){?> selected <?php }?>>tada</option>
                  <option value="pulse" <?php if($animation_effect_modal=='pulse'){?> selected <?php }?>>pulse</option>
                  <option value="flipInX" <?php if($animation_effect_modal=='flipInX'){?> selected <?php }?>>flipInX</option>
                  <option value="flipInY" <?php if($animation_effect_modal=='flipInY'){?> selected <?php }?>>flipInY</option>
                </select>
                <br />
                <p class="text-muted"><i class="fa fa-arrow-up"></i> Set animation effect for modal dialogs.</p>
              </div>
            </div>
            <div class="row">
              <div class="col-md-12">
                <div class="form-group">
                  <div class="text-right">
                    <button type="submit" class="btn btn-primary save col-right"><?php echo $this->lang->line('xin_save');?> <i class="icon-circle-right2 position-right"></i> <i class="icon-spinner3 spinner position-left"></i></button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </form>
    </div>
  </div>
  <div class="col-md-9 current-tab animated fadeInRight" id="notification" style="display:none;">
    <form id="notification_position_info" action="<?php echo site_url("settings/notification_position_info");?>" name="notification_position_info" method="post">
      <input type="hidden" name="u_basic_info" value="UPDATE">
      <div class="box box-block bg-white">
        <h2><strong>Notification Position</strong> Configuration</h2>
        <div class="row">
          <div class="col-md-4">
            <div class="form-group">
              <label for="notification_position">Position</label>
              <select class="form-control" name="notification_position" data-plugin="select_hrm" data-placeholder="Position">
                <option value="">Select One</option>
                <option value="toast-top-right" <?php if($notification_position=='toast-top-right'){?> selected <?php }?>>Top Right</option>
                <option value="toast-bottom-right" <?php if($notification_position=='toast-bottom-right'){?> selected <?php }?>>Bottom Right</option>
                <option value="toast-bottom-left" <?php if($notification_position=='toast-bottom-left'){?> selected <?php }?>>Bottom Left</option>
                <option value="toast-top-left" <?php if($notification_position=='toast-top-left'){?> selected <?php }?>>Top Left</option>
                <option value="toast-top-center" <?php if($notification_position=='toast-top-center'){?> selected <?php }?>>Top Center</option>
              </select>
              <br />
              <small class="text-muted"><i class="icon-arrow-up8"></i> Set position for notifications .</small> </div>
          </div>
          <div class="col-md-3">
            <div class="form-group">
              <label for="company_name">Enable Close Button</label>
              <br>
              <div class="pull-xs-left m-r-1">
                <input type="checkbox" class="js-switch" data-size="small" data-color="#3e70c9" data-secondary-color="#ddd" id="sclose_btn" <?php if($notification_close_btn=='true'):?> checked="checked" <?php endif;?> value="true" />
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="form-group">
              <label for="company_name">Progress Bar</label>
              <br>
              <div class="pull-xs-left m-r-1">
                <input type="checkbox" class="js-switch" data-size="small" data-color="#3e70c9" data-secondary-color="#ddd" id="snotification_bar" <?php if($notification_bar=='true'):?> checked="checked" <?php endif;?> value="true" />
              </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12">
            <div class="form-group">
              <div class="text-right">
                <button type="submit" class="btn btn-primary save"><?php echo $this->lang->line('xin_save');?> <i class="icon-circle-right2 position-right"></i> <i class="icon-spinner3 spinner position-left"></i></button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </form>
  </div>
  
  
  <div class="col-md-9 current-tab animated fadeInRight" id="currency_type" style="display:none;">
    <div  class="box box-block bg-white">
      <div class="row">
        <div class="col-md-5">
          <div class="box box-block bg-white">
            <h2><strong>Add New</strong> Currency Type</h2>
            <form class="m-b-1 add" id="currency_type_info" action="<?php echo site_url("settings/currency_type_info") ?>" name="currency_type_info" method="post">
              <div class="form-group">
                <label for="name">Currency Name</label>
                <input type="text" class="form-control" name="name" placeholder="Enter Currency Name">
              </div>
              <div class="form-group">
                <label for="name">Currency Code</label>
                <input type="text" class="form-control" name="code" placeholder="Enter Currency Code">
              </div>
              <div class="form-group">
                <label for="name">Currency Symbol</label>
                <input type="text" class="form-control" name="symbol" placeholder="Enter Currency Symbol">
              </div>
              <button type="submit" class="btn btn-primary save">Save</button>
            </form>
          </div>
        </div>
        <div class="col-md-7">
          <div class="box box-block bg-white">
            <h2><strong>List All</strong> Currencies</h2>
            <div class="table-responsive" data-pattern="priority-columns">
              <table class="table table-striped table-bordered dataTable" id="xin_table_currency_type" style="width:100%;">
                <thead>
                  <tr>
                    <th>Action</th>
                    <th>Name</th>
                    <th>Code</th>
                    <th>Symbol</th>
                  </tr>
                </thead>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  
  
  <div class="col-md-9 current-tab animated fadeInRight" id="system" style="display:none;">
    <form id="system_info" action="<?php echo site_url("settings/system_info").'/'.$company_info_id ?>/" name="system_info" method="post">
      <input type="hidden" name="u_basic_info" value="UPDATE">
      <div class="box box-block bg-white">
        <h2><strong>System</strong> Configuration</h2>
        <div class="col-sm-6">
          <div class="form-group">
            <input class="form-control" placeholder="Application Name" name="application_name" type="hidden" value="<?php echo $application_name;?>" id="application_name">
          </div>
          <div class="form-group">
            <label for="email">Default Currency</label>
            <select class="form-control select2-hidden-accessible" name="default_currency_symbol" data-plugin="select_hrm" data-placeholder="Default Currency Symbol" tabindex="-1" aria-hidden="true">
              <option value="">Select One</option>
              <?php foreach($this->Xin_model->get_currencies() as $currency){?>
              <?php $_currency = $currency->code.' - '.$currency->symbol;?>
              <option value="<?php echo $_currency;?>" <?php if($default_currency_symbol==$_currency):?> selected <?php endif;?>> <?php echo $_currency;?></option>
              <?php } ?>
            </select>
          </div>
          <div class="form-group">
            <label for="phone">Default Currency (Symbol/Code)</label>
            <select class="form-control" name="show_currency" data-plugin="select_hrm" data-placeholder="Show Currency">
              <option value="">Select One</option>
              <option value="code" <?php if($show_currency=='code'){?> selected <?php }?>>Currency Code</option>
              <option value="symbol" <?php if($show_currency=='symbol'){?> selected <?php }?>>Currency Symbol</option>
            </select>
          </div>
          <div class="form-group">
            <label for="phone">Currency Position</label>
            <input type="hidden" name="notification_position" value="Bottom Left">
            <input type="hidden" name="enable_registration" value="no">
            <input type="hidden" name="login_with" value="username">
            <select class="form-control" name="currency_position" data-plugin="select_hrm" data-placeholder="Currency Position">
              <option value="">Select One</option>
              <option value="Prefix" <?php if($currency_position=='Prefix'){?> selected <?php }?>>Prefix</option>
              <option value="Suffix" <?php if($currency_position=='Suffix'){?> selected <?php }?>>Suffix</option>
            </select>
          </div>
          
        </div>
        <div class="col-sm-6">
          <div class="form-group">
            <label for="company_name">Date Format</label>
            <br>
            <label class="custom-control custom-radio">
              <input id="date_format" name="date_format" type="radio" class="custom-control-input" value="d-m-Y" <?php if($date_format_xi=='d-m-Y'){?> checked <?php }?>>
              <span class="custom-control-indicator"></span> <span class="custom-control-description">dd-mm-YYYY (<?php echo date('d-m-Y');?>)</span> </label>
            <br>
            <label class="custom-control custom-radio">
              <input id="date_format" name="date_format" type="radio" class="custom-control-input" value="m-d-Y" <?php if($date_format_xi=='m-d-Y'){?> checked <?php }?>>
              <span class="custom-control-indicator"></span> <span class="custom-control-description">mm-dd-YYYY (<?php echo date('m-d-Y');?>)</span> </label>
            <br>
            <label class="custom-control custom-radio">
              <input id="date_format" name="date_format" type="radio" class="custom-control-input" value="d-M-Y" <?php if($date_format_xi=='d-M-Y'){?> checked <?php }?>>
              <span class="custom-control-indicator"></span> <span class="custom-control-description">dd-MM-YYYY (<?php echo date('d-M-Y');?>)</span> </label>
            <br>
            <label class="custom-control custom-radio">
              <input id="date_format" name="date_format" type="radio" class="custom-control-input" value="M-d-Y" <?php if($date_format_xi=='M-d-Y'){?> checked <?php }?>>
              <span class="custom-control-indicator"></span> <span class="custom-control-description">MM-dd-YYYY (<?php echo date('M-d-Y');?>)</span> </label>
          </div>
          
          
        </div>
        <div class="row">
          <div class="col-md-12">
            <div class="form-group">
              <div class="text-right">
                <button type="submit" class="btn btn-primary save"><?php echo $this->lang->line('xin_save');?> <i class="icon-circle-right2 position-right"></i> <i class="icon-spinner3 spinner position-left"></i></button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </form>
  </div>
  
  
  <div class="col-md-9 current-tab animated fadeInRight" id="product_cat" style="display:none;">
    <div  class="box box-block bg-white">
      <div class="row">
        <div class="col-md-5">
          <div class="box box-block bg-white">
            <h2><strong>Add New</strong> Product Category</h2>
            <form class="m-b-1 add" id="add_product_cat" action="<?php echo site_url("settings/add_product_cat") ?>" name="add_product_cat" method="post">
              <div class="form-group">
                <label for="name">Category Name</label>
                <input type="text" class="form-control" name="name" placeholder="Category Name">
              </div>
              <button type="submit" class="btn btn-primary save">Save</button>
            </form>
          </div>
        </div>
        <div class="col-md-7">
          <div class="box box-block bg-white">
            <h2><strong>List All</strong> Categories</h2>
            <div class="table-responsive" data-pattern="priority-columns">
              <table class="table table-striped table-bordered dataTable" id="xin_table_product_cat" style="width:100%;">
                <thead>
                  <tr>
                    <th>Action</th>
                    <th>Name</th>
                    <th>Added By</th>
                  </tr>
                </thead>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  
  
  
  <div class="col-md-9 current-tab animated fadeInRight" id="product_brand" style="display:none;">
    <div  class="box box-block bg-white">
      <div class="row">
        <div class="col-md-5">
          <div class="box box-block bg-white">
            <h2><strong>Add New</strong> Brand</h2>
            <form class="m-b-1 add" id="add_product_brand" action="<?php echo site_url("settings/add_product_brand") ?>" name="add_product_brand" method="post">
              <div class="form-group">
                <label for="name">Brand Name</label>
                <input type="text" class="form-control" name="name" placeholder="Brand Name">
              </div>
              <button type="submit" class="btn btn-primary save">Save</button>
            </form>
          </div>
        </div>
        <div class="col-md-7">
          <div class="box box-block bg-white">
            <h2><strong>List All</strong> Brands</h2>
            <div class="table-responsive" data-pattern="priority-columns">
              <table class="table table-striped table-bordered dataTable" id="xin_table_product_brand" style="width:100%;">
                <thead>
                  <tr>
                    <th>Action</th>
                    <th>Name</th>
                    <th>Added By</th>
                  </tr>
                </thead>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  
  
  
  <div class="col-md-9 current-tab animated fadeInRight" id="import_products" style="display:none;">
    <div  class="box box-block bg-white">
      <div class="row">
        <div class="col-md-12">
          <div class="box box-block bg-white">
            <h2><strong>Import</strong> Products</h2>
            
            <p class="font-100 text-muted mb-1">The correct column order is (Sl No, Product Name, Brand, Model Number, Category) and <strong>you must follow</strong> the csv file, otherwise you will get an error while importing the csv file.</p>
            <h6>
                <a href="<?php echo site_url("uploads/csv/products_sample.csv"); ?>" class="btn btn-info"> <i class="fa fa-download"></i> Download sample File</a>
            </h6>
            <br>
             
                <form class="m-b-1 add" id="import_product_csv" action="<?php echo site_url("settings/import_product_csv"); ?>" name="import_product_csv" method="post" enctype="multipart/form-data">
                  <div class="form-group">
                    <label for="name">CSV File</label>
                    <input type="file" class="form-control" name="file" accept=".csv">
                  </div>
                  <button type="submit" class="btn btn-primary save">Update</button>
                </form>
                <div align="center" class="icon-spinner3" style="display:none;"><img style="width:300px;" src="<?php echo site_url("skin/img/loading_bar.gif"); ?>"/></div>
                <br>
                <div align="center">
                   <span class="product_result_status alert alert-success" style="display:none;"></span>
                </div>
                <br><br>
          </div>
        </div>
      </div>
    </div>
  </div>
  
  <?php
  }
  ?>
  
</div>

<div class="modal fade edit_setting_datail" id="edit_setting_datail" tabindex="-1" role="dialog" aria-labelledby="edit-modal-data" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content" id="ajax_setting_info"></div>
  </div>
</div>
