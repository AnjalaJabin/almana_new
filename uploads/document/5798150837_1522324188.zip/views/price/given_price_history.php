<?php $session = $this->session->userdata('username');?>
<div class="box box-block bg-white">
  <h2><strong><?php echo $this->lang->line('xin_list_all');?></strong> Price</h2>
  <div class="table-responsive" data-pattern="priority-columns">
    <table class="table table-striped table-bordered dataTable" style="width:100%;" id="xin_table">
      <thead>
        <tr>
          <td>Sl No</td>
          <th>Product Name</th>
          <th>Price</th>
          <th>Brand</th>
          <th>Model Number</th>
          <th>Customer</th>
          <th>Date</th>
        </tr>
      </thead>
      <tbody>
        <?php
        $slno=1;
        foreach($my_price_history_data as $p_vals)
        {
            $customer_name = $this->Xin_model->get_customer_name_by_id($p_vals->customer_id);
            $product_name = $this->Xin_model->get_product_name_by_id($p_vals->product_id);
    		$product_brand = $this->Xin_model->get_product_brand_by_id($product_name[0]->brand);
            ?>
            <tr>
              <td><?php echo $slno; ?></td>
              <td style="max-width:350px;"><?php echo $product_name[0]->name; ?></td>
              <td style="color:#f44336"><b><?php echo $this->Xin_model->currency_sign($p_vals->price); ?></b></td>
              <td><?php echo $product_brand; ?></td>
              <td><?php echo $product_name[0]->model_number; ?></td>
              <td><?php if(isset($customer_name[0]->company_name)){ echo $customer_name[0]->company_name; } ?></td>
              <td><?php echo date('d M Y D h:i A' , strtotime($p_vals->date)); ?></td>
            </tr>
            <?php
            $slno++;
        }
        ?>
      </tbody>
    </table>
  </div>
</div>