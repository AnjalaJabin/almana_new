<?php
$session = $this->session->userdata('username');
$system = $this->Xin_model->read_setting_info(1);
$user_info = $this->Xin_model->read_user_info($session['user_id']);
$role = $this->Xin_model->read_user_role_info($user_info[0]->user_role_id);

$root_id = $this->Xin_model->get_root_id(1);
$product_cats = $this->Xin_model->get_all_product_cats();
?>

<div class="box box-block bg-white">
  <h2><strong>Search</strong> Products</h2>
  
    <div class="add-record-btn">
      <button class="m-b-0-0 waves-effect waves-light btn btn-md btn-info" data-toggle="modal" data-target=".add-modal-data"><i class="fa fa-plus icon"></i> Add New Product</button>
    </div>
  
    <form method="get" action="<?php echo site_url('price'); ?>" id="main_search_form" name="main_search_form">
      <div class="row">
        <div class="col-sm-6">
          <div class="input-group">
            <input type="text" class="form-control" placeholder="Search here..." name="q" autocomplete="off">
            <div class="input-group-btn">
              <button type="submit" class="btn btn-success">Go</button>
            </div>
          </div>
        </div>
      </div>
    </form>
    
    <br><br>
    
    <div class="table-responsive" data-pattern="priority-columns" id="search_results">
    </div>
    
</div>

<style>
    .delete-modal{z-index: 1111111;}
</style>