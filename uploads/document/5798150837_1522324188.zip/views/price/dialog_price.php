<?php
defined('BASEPATH') OR exit('No direct script access allowed');
if(isset($_GET['jd']) && isset($_GET['product_id']) && $_GET['data']=='products'){
    $role_resources_ids = $this->Xin_model->user_role_resource();
?>

<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">×</span> </button>
  <h4 class="modal-title" id="edit-modal-data">Update Price</h4>
</div>
  <input type="hidden" name="_method" value="EDIT">
  <input type="hidden" id="p_p_id" name="_token" value="<?php echo $product_id;?>">
  <input type="hidden" name="ext_name" value="<?php echo $name;?>">
  <div class="modal-body">
    <div class="row">
      <div class="col-sm-12">
        <div class="form-group">
          <label for="name">Product Name</label>
          <h5><?php echo $name;?></h5>
        </div>
      </div>
    </div>
    
    <?php if(in_array('67',$role_resources_ids)) { ?>
    <div class="row" style="border-top:solid 2px #efefef;">
      <form class="m-b-1" action="<?php echo site_url("price/add_price").'/'.$product_id; ?>" method="post" name="add_price" id="add_price">
        <input type="hidden" name="product_id" value="<?php echo $product_id;?>">
        <input type="hidden" name="add_type" value="price">
        <div class="col-sm-5">
           <div class="form-group" id="group_ajax2">
            <label for="name">Supplier</label>
              <select class="form-control" name="supplier" data-plugin="select_hrm" data-placeholder="Select Supplier">
                <option value=""><?php echo $this->lang->line('xin_select_one');?></option>
                <?php foreach($suppliers as $supplier) {?>
                <option value="<?php echo $supplier->id;?>"> <?php echo $supplier->name;?></option>
                <?php } ?>
              </select>
          </div>
          
            <a class="btn btn-sm btn-primary pull-right text-white" id="group_add_btn2"><i class="fa fa-plus icon"></i> New Supplier</a>
            <div style="background:#ddd; padding:7px; display:none;" id="group_add_div2">
                <div class="input-group">
                   <input type="text" class="form-control" placeholder="Supplier Name" id="group_add_val2">
                   <span class="input-group-btn">
                        <button class="btn btn-success" type="button" id="group_sub_btn2">Add</button>
                   </span>
                   <span class="input-group-btn">
                        <button class="btn" type="button" id="group_close_btn2">X</button>
                   </span>
                </div>
            </div>
            
        </div>
        
        <div class="col-sm-5">
           <div class="form-group">
            <label for="name">Price</label>
            <input class="form-control" placeholder="Price" name="price" type="text">
          </div>
        </div>
        
        <div class="col-sm-2">
           <div class="form-group">
            <label for="name">&nbsp;</label>
            <button type="submit" class="form-control btn btn-primary save"><?php echo $this->lang->line('xin_update');?></button>
          </div>
        </div>
      </form>
    </div>
    <?php } ?>
    
    <div class="row">
        <div class="table-responsive" data-pattern="priority-columns" id="pricing_table">
            <table class="table table-striped table-bordered dataTable" style="width:100%;">
              <thead>
                <tr>
                  <th></th>
                  <th>Supplier</th>
                  <th>Price</th>
                  <th>Date</th>
                  <th>Added By</th>
                  <?php if(in_array('68',$role_resources_ids)) { ?><th></th> <?php } ?>
                </tr>
              </thead>
              <tbody>
                <?php
                $slno=1;
                $product_price = $this->Xin_model->get_all_product_price($_GET['product_id']);
                foreach($product_price as $p_vals)
                {
                $supplier_name = $this->Xin_model->get_supplier_name_by_id($p_vals->supplier_id);
                $user = $this->Xin_model->read_user_info($p_vals->added_by);
    			// user full name
    			$full_name = $user[0]->first_name.' '.$user[0]->last_name;
                ?>
                <tr>
                  <td><?php echo $slno; ?></td>
                  <td><?php if(isset($supplier_name[0]->name)){ echo $supplier_name[0]->name; } ?></td>
                  <td><?php echo $this->Xin_model->currency_sign($p_vals->price); ?></td>
                  <td><?php echo date('d M Y D h:i A' , strtotime($p_vals->date)); ?></td>
                  <td><?php echo $full_name; ?></th>
                  <?php if(in_array('68',$role_resources_ids)) { ?><td><button type="button" class="btn btn-danger btn-sm m-b-0-0 waves-effect waves-light delete" data-toggle="modal" data-target=".delete-modal" data-record-id="<?php echo $p_vals->id; ?>"><i class="fa fa-trash-o"></i></button></td> <?php } ?>
                </tr>
                <?php
                $slno++;
                }
                ?>
              </tbody>
            </table>
        </div>
    </div>
    
    
    <div class="row" style="border-top:solid 2px #efefef;">
      <form class="m-b-1" action="<?php echo site_url("price/add_customer_price").'/'.$product_id; ?>" method="post" name="add_customer_price" id="add_customer_price">
        <input type="hidden" name="product_id" value="<?php echo $product_id;?>">
        <input type="hidden" name="add_type" value="price">
        <div class="col-sm-5">
           <div class="form-group" id="group_ajax3">
            <label for="name">Customer</label>
              <select class="form-control" name="customer" data-plugin="select_hrm" data-placeholder="Select Customer">
                <option value=""><?php echo $this->lang->line('xin_select_one');?></option>
                <?php foreach($customers as $customer) {?>
                <option value="<?php echo $customer->customer_id;?>"> <?php echo $customer->company_name;?></option>
                <?php } ?>
              </select>
          </div>
          
            <a class="btn btn-sm btn-primary pull-right text-white" id="group_add_btn3"><i class="fa fa-plus icon"></i> New Customer</a>
            <div style="background:#ddd; padding:7px; display:none;" id="group_add_div3">
                <div class="input-group">
                   <input type="text" class="form-control" placeholder="Customer Name" id="group_add_val3">
                   <span class="input-group-btn">
                        <button class="btn btn-success" type="button" id="group_sub_btn3">Add</button>
                   </span>
                   <span class="input-group-btn">
                        <button class="btn" type="button" id="group_close_btn3">X</button>
                   </span>
                </div>
            </div>
            
        </div>
        
        <div class="col-sm-5">
           <div class="form-group">
            <label for="name">Price</label>
            <input class="form-control" placeholder="Price" name="price" type="text">
          </div>
        </div>
        
        <div class="col-sm-2">
           <div class="form-group">
            <label for="name">&nbsp;</label>
            <button type="submit" class="form-control btn btn-primary save"><?php echo $this->lang->line('xin_update');?></button>
          </div>
        </div>
      </form>
    </div>
    
    
    <div class="row">
        <div class="table-responsive" data-pattern="priority-columns" id="pricing_table2">
            <table class="table table-striped table-bordered dataTable" style="width:100%;">
              <thead>
                <tr>
                  <th></th>
                  <th>Customer</th>
                  <th>Price</th>
                  <th>Date</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                <?php
                $slno=1;
                $session = $this->session->userdata('username');
                $product_price = $this->Xin_model->get_all_customer_price($_GET['product_id'],$session['user_id']);
                foreach($product_price as $p_vals)
                {
                $customer_name = $this->Xin_model->get_customer_name_by_id($p_vals->customer_id);
                ?>
                <tr>
                  <td><?php echo $slno; ?></td>
                  <td><?php if(isset($customer_name[0]->company_name)){ echo $customer_name[0]->company_name; } ?></td>
                  <td><?php echo $this->Xin_model->currency_sign($p_vals->price); ?></td>
                  <td><?php echo date('d M Y D h:i A' , strtotime($p_vals->date)); ?></td>
                  <td><button type="button" class="btn btn-danger btn-sm m-b-0-0 waves-effect waves-light delete_customer_price" data-toggle="modal" data-target=".delete-modal" data-record-id="<?php echo $p_vals->id; ?>"><i class="fa fa-trash-o"></i></button></td>
                </tr>
                <?php
                $slno++;
                }
                ?>
              </tbody>
            </table>
        </div>
    </div>
    
  </div>
  <div class="modal-footer">
    <button type="button" class="btn btn-link" data-dismiss="modal"><?php echo $this->lang->line('xin_close');?></button>
  </div>

<script type="text/javascript">
    $('#description2').summernote({
      height: 206,
      minHeight: null,
      maxHeight: null,
      focus: false
    });
 $(document).ready(function(){
					
		// On page load: datatable
		var xin_table = $('#xin_table').dataTable({
			"bDestroy": true,
			"ajax": {
				url : "<?php echo site_url("price/price_list") ?>",
				type : 'GET'
			},
			"fnDrawCallback": function(settings){
			$('[data-toggle="tooltip"]').tooltip();          
			}
    	});
		
		$('[data-plugin="select_hrm"]').select2($(this).attr('data-options'));
		$('[data-plugin="select_hrm"]').select2({ width:'100%' });	 

		/* Edit data */
		$("#edit_product").submit(function(e){
		e.preventDefault();
			var obj = $(this), action = obj.attr('name');
			$('.save').prop('disabled', true);
			
			$.ajax({
				type: "POST",
				url: e.target.action,
				data: obj.serialize()+"&is_ajax=1&edit_type=products&form="+action,
				cache: false,
				success: function (JSON) {
					if (JSON.error != '') {
						toastr.error(JSON.error);
						$('.save').prop('disabled', false);
					} else {
						xin_table.api().ajax.reload(function(){ 
							toastr.success(JSON.result);
						}, true);
						$('.edit-modal-data').modal('toggle');
						$('.save').prop('disabled', false);
					}
				}
			});
		});
		
		
		$("#add_price").submit(function(e){
		e.preventDefault();
			var obj = $(this), action = obj.attr('name');
			$('.save').prop('disabled', true);
			
			$.ajax({
				type: "POST",
				url: e.target.action,
				data: obj.serialize()+"&is_ajax=1&add_type=price&form="+action,
				cache: false,
				success: function (JSON) {
					if (JSON.error != '') {
						toastr.error(JSON.error);
						$('.save').prop('disabled', false);
					} else {
						xin_table.api().ajax.reload(function(){ 
							toastr.success(JSON.result);
						}, true);
						$('.save').prop('disabled', false);
						var product_id = $('#p_p_id').val();
						$('#pricing_table').load('<?php echo site_url("price/price_list") ?>/'+product_id);
						$('#pricing_table2').load('<?php echo site_url("price/customer_price_list") ?>/'+product_id);
						$("#main_search_form").submit();
						$("#add_price")[0].reset();
						$('[data-plugin="select_hrm"]').select2({ width:'100%' });
					}
				}
			});
		});
		
		$("#add_customer_price").submit(function(e){
		e.preventDefault();
			var obj = $(this), action = obj.attr('name');
			$('.save').prop('disabled', true);
			
			$.ajax({
				type: "POST",
				url: e.target.action,
				data: obj.serialize()+"&is_ajax=1&add_type=customer_price&form="+action,
				cache: false,
				success: function (JSON) {
					if (JSON.error != '') {
						toastr.error(JSON.error);
						$('.save').prop('disabled', false);
					} else {
						xin_table.api().ajax.reload(function(){ 
							toastr.success(JSON.result);
						}, true);
						$('.save').prop('disabled', false);
						var product_id = $('#p_p_id').val();
						$('#pricing_table').load('<?php echo site_url("price/price_list") ?>/'+product_id);
						$('#pricing_table2').load('<?php echo site_url("price/customer_price_list") ?>/'+product_id);
						$("#main_search_form").submit();
						$("#add_customer_price")[0].reset();
						$('[data-plugin="select_hrm"]').select2({ width:'100%' });	 
					}
				}
			});
		});
		
		
	});	
	
	
	$(document).on( "click", "#group_add_btn2", function() {
        $('#group_add_div2').show();
        $('#group_add_btn2').hide();
    });
    
    $(document).on( "click", "#group_close_btn2", function() {
        $('#group_add_div2').hide();
        $('#group_add_btn2').show();
    });
	
	$(document).on( "click", "#group_sub_btn2", function() {
        var group_val = $('#group_add_val2').val();
        if(group_val==='')
        {
            toastr.error('Type Category Name');
        }
        else
        {
            
            var group_name = $('#group_add_val2').val();
            $.ajax({
    			type: "POST",
    			url: site_url+'/suppliers/add_supplier_name/',
    			data: { supplier_name:group_name, is_ajax:'1', add_type:'suppliers'},
    			cache: false,
    			success: function (JSON) {
    				if (JSON.error != '') {
    					toastr.error(JSON.error);
    				} else {
    					toastr.success(JSON.result);
    					$('#group_add_div2').hide();
                        $('#group_add_btn2').show();
                        $('#group_add_val2').val('');
    				}
    			}
    		});
    		
    		jQuery.get(site_url+"/suppliers/suppliers_select_list", function(data, status){
        		jQuery('#group_ajax2').html(data);
        	});
               
        }
    });
    
    
    
    $(document).on( "click", "#group_add_btn3", function() {
        $('#group_add_div3').show();
        $('#group_add_btn3').hide();
    });
    
    $(document).on( "click", "#group_close_btn3", function() {
        $('#group_add_div3').hide();
        $('#group_add_btn3').show();
    });
	
	$(document).on( "click", "#group_sub_btn3", function() {
        var group_val = $('#group_add_val3').val();
        if(group_val==='')
        {
            toastr.error('Type Category Name');
        }
        else
        {
            
            var group_name = $('#group_add_val3').val();
            $.ajax({
    			type: "POST",
    			url: site_url+'customers/add_customer_name/',
    			data: { company_name:group_name, is_ajax:'1', add_type:'customers'},
    			cache: false,
    			success: function (JSON) {
    				if (JSON.error != '') {
    					toastr.error(JSON.error);
    				} else {
    					toastr.success(JSON.result);
    					$('#group_add_div3').hide();
                        $('#group_add_btn3').show();
                        $('#group_add_val3').val('');
    				}
    			}
    		});
    		
    		jQuery.get(site_url+"customers/customers_select_list", function(data, status){
        		jQuery('#group_ajax3').html(data);
        	});
               
        }
    });
  </script>
<?php } else if(isset($_GET['jd']) && isset($_GET['product_id']) && $_GET['data']=='view_product'){
?>
<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">×</span> </button>
  <h4 class="modal-title" id="edit-modal-data">View Price</h4>
</div>
<form class="m-b-1">
  <div class="modal-body">
    <div class="row">
      <div class="col-sm-6">
        <div class="form-group">
          <label for="name">Product Name</label>
          <h5><?php echo $name;?></h5>
        </div>
          <div class="form-group">
            <label for="name">Model Number</label>
            <h5><?php echo $model_number;?></h5>
          </div>
          
          <div class="form-group" id="group_ajax">
            <label for="name">Product Category</label>
            <h5><?php echo $this->Xin_model->get_product_cat_by_id($category_id);;?></h5>
          </div>
      </div>
      <div class="col-sm-6">
        <div class="form-group">
          <label for="email"><b>Description</b></label>
          <?php echo $des;?>
        </div>
      </div>
    </div>
    
    <div class="row">
        <div class="table-responsive" data-pattern="priority-columns">
            <table class="table table-striped table-bordered dataTable" style="width:100%;">
              <thead>
                <tr>
                  <th></th>
                  <th>Supplier</th>
                  <th>Price</th>
                  <th>Date</th>
                  <th>Added By</th>
                </tr>
              </thead>
              <tbody>
                <?php
                $slno=1;
                $product_price = $this->Xin_model->get_all_product_price($_GET['product_id']);
                foreach($product_price as $p_vals)
                {
                $supplier_name = $this->Xin_model->get_supplier_name_by_id($p_vals->supplier_id);
                $user = $this->Xin_model->read_user_info($p_vals->added_by);
    			// user full name
    			$full_name = $user[0]->first_name.' '.$user[0]->last_name;
                ?>
                <tr>
                  <th><?php echo $slno; ?></th>
                  <th><?php echo $supplier_name[0]->name; ?></th>
                  <th><?php echo $this->Xin_model->currency_sign($p_vals->price); ?></th>
                  <th><?php echo date('d M Y D h:i A' , strtotime($p_vals->date)); ?></th>
                  <th><?php echo $full_name; ?></th>
                </tr>
                <?php
                $slno++;
                }
                ?>
              </tbody>
            </table>
        </div>
    </div>
    
  </div>
  <div class="modal-footer">
    <button type="button" class="btn btn-link" data-dismiss="modal"><?php echo $this->lang->line('xin_close');?></button>
  </div>
</form>
<?php }
?>
