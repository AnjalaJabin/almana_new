<?php $session = $this->session->userdata('username');?>
<div class="box box-block bg-white">
  <h2><strong><?php echo $this->lang->line('xin_list_all');?></strong> Price</h2>
  <div class="table-responsive" data-pattern="priority-columns">
    <table class="table table-striped table-bordered dataTable" style="width:100%;" id="xin_table">
      <thead>
        <tr>
          <td>Sl No</td>
          <th>Product Name</th>
          <th>Price</th>
          <th>Brand</th>
          <th>Model Number</th>
          <th>Supplier</th>
          <th>Updated By</th>
          <th>Date</th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        <?php
        $slno=1;
        foreach($my_all_price_requests_data as $p_vals)
        {
            $product_brand = '';
            $supplier_name = $this->Xin_model->get_supplier_name_by_id($p_vals->supplier_id);
            $product_name = $this->Xin_model->get_product_name_by_id($p_vals->product_id);
            
            $user = $this->Xin_model->read_user_info($p_vals->updated_by);
            if(isset($user)){ $full_name = $user[0]->first_name.' '.$user[0]->last_name; }
            else{ $full_name = '--'; }
            
    		if(isset($product_name[0]->brand)){
    		   $product_brand = $this->Xin_model->get_product_brand_by_id($product_name[0]->brand);
    		}
    		
    		if(isset($p_vals->ignore_status)){
    		    if($p_vals->ignore_status>0){
    		        $ignore_reason = $p_vals->ignore_reason;
    		    }
    		}
            ?>
            <tr>
              <td><?php echo $slno; ?></td>
              <td style="max-width:350px;"><?php if(isset($product_name[0]->name)){ echo $product_name[0]->name; }else{ echo '--'; } ?></td>
              <td style="color:#f44336"><b><?php if($p_vals->price>0){ echo $this->Xin_model->currency_sign($p_vals->price); }else if(isset($ignore_reason)){ echo $ignore_reason; }else{ echo '--'; } ?></b></td>
              <td><?php echo $product_brand; ?></td>
              <td><?php if(isset($product_name[0]->model_number)) { echo $product_name[0]->model_number; }else{ echo '--';} ?></td>
              <td><?php if(isset($supplier_name[0]->name)) { echo $supplier_name[0]->name; }else { echo '--'; } ?></td>
              <th><?php echo $full_name; ?></th>
              <td><?php echo date('d M Y D h:i A' , strtotime($p_vals->date)); ?></td>
              <td><span data-toggle="tooltip" data-placement="top" title="Delete"><button type="button" class="btn btn-danger btn-sm m-b-0-0 waves-effect waves-light delete" data-toggle="modal" data-target=".delete-modal" data-record-id="<?php echo $p_vals->id; ?>"><i class="fa fa-trash-o"></i></button></span></td>
            </tr>
            <?php
            $slno++;
        }
        ?>
      </tbody>
    </table>
  </div>
</div>