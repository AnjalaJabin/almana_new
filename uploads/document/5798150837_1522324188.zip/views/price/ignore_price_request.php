<?php
defined('BASEPATH') OR exit('No direct script access allowed');
if(isset($_GET['jd']) && isset($_GET['product_id']) && isset($_GET['request_id']) && $_GET['data']=='request'){
    $role_resources_ids = $this->Xin_model->user_role_resource();
?>

<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">×</span> </button>
  <h4 class="modal-title" id="edit-modal-data">Ignore Price Request</h4>
  <h6>(<?php echo $name; ?>)</h6>
</div>
<form class="m-b-1" action="<?php echo site_url("price/update_ignore_request"); ?>" method="post" name="edit_customer" id="ignore_submit">
  <input type="hidden" name="_method" value="EDIT">
  <input type="hidden" name="_token" value="<?php echo $_REQUEST['product_id'];?>">
  <input type="hidden" name="ext_name" value="<?php echo $_REQUEST['request_id'];?>">
  
  <input type="hidden" name="product_id" value="<?php echo $_REQUEST['product_id'];?>">
  <input type="hidden" name="request_id" value="<?php echo $_REQUEST['request_id'];?>">
  
  <div class="modal-body">
      <div class="row">
          
        <div class="col-sm-12">
          <div class="form-group">
            <label for="name">Reason</label>
            <textarea class="form-control" placeholder="Ignore Reason" name="ignore_reason"></textarea>
          </div>
        </div>
      </div>
  </div>
  <div class="modal-footer">
    <button type="button" class="btn btn-link" data-dismiss="modal"><?php echo $this->lang->line('xin_close');?></button>
    <button type="submit" class="btn btn-primary save">Submit</button>
  </div>
</form>

<script type="text/javascript">
 $(document).ready(function(){
					
	$("#ignore_submit").submit(function(e){
	e.preventDefault();
		var obj = $(this), action = obj.attr('name');
		$('.save').prop('disabled', true);
		
		$.ajax({
			type: "POST",
			url: e.target.action,
			data: obj.serialize()+"&is_ajax=1&add_type=ignore_request&form="+action,
			cache: false,
			success: function (JSON) {
				if (JSON.error != '') {
					toastr.error(JSON.error);
					$('.save').prop('disabled', false);
				} else {
					toastr.success(JSON.result);
					$('.view-modal-data').modal('toggle');
					$('.save').prop('disabled', false);
					window.location.replace('<?php echo site_url('price/all_price_requests'); ?>');
    				window.location.href = '<?php echo site_url('price/all_price_requests'); ?>';
				}
			}
		});
	});
});	
</script>

<?php
}
?>