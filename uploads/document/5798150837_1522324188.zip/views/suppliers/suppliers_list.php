
<?php $session = $this->session->userdata('username');?>

<div class="add-form" style="display:none;" >
  <div class="box box-block bg-white">
    <h2><strong><?php echo $this->lang->line('xin_add_new');?></strong> Supplier
      <div class="add-record-btn">
        <button class="btn btn-sm btn-primary add-new-form"><i class="fa fa-minus icon"></i> <?php echo $this->lang->line('xin_hide');?></button>
      </div>
    </h2>
    <div class="row m-b-1">
      <div class="col-md-12">
        <form class="m-b-1 add" method="post" name="add_supplier" id="xin-form">
          <input type="hidden" name="user_id" value="<?php echo $session['user_id'];?>">
          <div class="bg-white">
            <div class="box-block">
              <div class="row">
                <div class="col-sm-6">
                  <div class="form-group">
                    <label for="name">Supplier Name</label>
                    <input class="form-control" placeholder="Supplier Name" name="supplier_name" type="text">
                  </div>
                  <div class="form-group">
                    <label for="email">Email</label>
                    <input class="form-control" placeholder="Email" name="email" type="text">
                  </div>
                  
                  <div class="form-group">
                    <label for="phone">Phone</label>
                   	 <input class="form-control" placeholder="Phone" name="phone" type="text">
                  </div>
                  
                </div>
                <div class="col-sm-6">
                    
                  <div class="form-group">
                    <label for="phone">TRN</label>
                   	 <input class="form-control" placeholder="TRN" name="trn" type="text">
                  </div>
                    
                  <div class="form-group">
                    <label for="phone">Address</label>
                   	 <textarea class="form-control" placeholder="Address" name="address"></textarea>
                  </div>
                  
                    <div class="form-group">
                    <label for="phone">Note</label>
                   	 <textarea class="form-control" placeholder="Notes" name="des"></textarea>
                  </div>
                  
                  <div class="text-right">
                    <button type="submit" class="btn btn-primary save"><?php echo $this->lang->line('xin_save');?> <i class="icon-circle-right2 position-right"></i> <i class="icon-spinner3 spinner position-left"></i></button>
                  </div>
                  
                </div>
              </div>
              
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<div class="box box-block bg-white">
  <h2><strong><?php echo $this->lang->line('xin_list_all');?></strong> Suppliers
    <div class="add-record-btn">
      <button class="btn btn-sm btn-primary add-new-form"><i class="fa fa-plus icon"></i> <?php echo $this->lang->line('xin_add_new');?></button>
    </div>
  </h2>
  <div class="table-responsive" data-pattern="priority-columns">
    <table class="table table-striped table-bordered dataTable" id="xin_table" style="width:100%;">
      <thead>
        <tr>
        <tr>
          <th><?php echo $this->lang->line('xin_action');?></th>
          <th>Supplier Name</th>
          <th>Email</th>
          <th>Phone</th>
          <th>Address</th>
          <th>TRN</th>
          <th>Added By</th>
        </tr>
          </tr>
        
      </thead>
    </table>
  </div>
</div>
