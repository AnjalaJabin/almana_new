<?php 
$result  = $this->Xin_model->get_all_product_cats();
?>
    <label for="name">Supplier</label>
      <select class="form-control quote_supplier" name="supplier" data-plugin="select_hrm" data-placeholder="Select Supplier">
        <option value=""><?php echo $this->lang->line('xin_select_one');?></option>
        <?php foreach($all_suppliers as $supplier) {?>
        <option value="<?php echo $supplier->id;?>"> <?php echo $supplier->name;?></option>
        <?php } ?>
      </select>

<script>
$('[data-plugin="select_hrm"]').select2($(this).attr('data-options'));
$('[data-plugin="select_hrm"]').select2({ width:'100%' }); 
</script>