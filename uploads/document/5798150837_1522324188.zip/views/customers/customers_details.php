<?php
/* Employee Details view
*/
$session = $this->session->userdata('username');
$link_url = site_url('customers/details/'.$customer_id.'/');
?>

<script>
    var customer_id = <?php echo $customer_id; ?>
</script>

<div class="row m-b-1">
  <div class="col-md-3">
    <div class="box bg-white">
      <ul class="nav nav-4 nav-tabs-link-cl">
        <li class="nav-item nav-item-link <?php if($tab_link==''){ echo 'active-link'; }?>"> <a class="nav-link nav-tabs-link" href="<?php echo $link_url; ?>"> <i class="fa fa-user"></i> <?php echo $this->lang->line('xin_e_details_basic');?> </a> </li>
        <li class="nav-item nav-item-link <?php if($tab_link=='contact'){ echo 'active-link'; }?>"> <a class="nav-link nav-tabs-link" href="<?php echo $link_url; ?>contact"> <i class="fa fa-phone"></i> Contacts </a> </li>
        <li class="nav-item nav-item-link <?php if($tab_link=='quotations'){ echo 'active-link'; }?>"> <a class="nav-link nav-tabs-link" href="<?php echo $link_url; ?>quotations"> <i class="fa fa-list"></i> Quotations </a> </li>
        <li class="nav-item nav-item-link <?php if($tab_link=='invoices'){ echo 'active-link'; }?>"> <a class="nav-link nav-tabs-link" href="<?php echo $link_url; ?>invoices"> <i class="fa fa-barcode"></i> Invoices </a> </li>
        <li class="nav-item nav-item-link <?php if($tab_link=='proforma_invoices'){ echo 'active-link'; }?>"> <a class="nav-link nav-tabs-link" href="<?php echo $link_url; ?>proforma_invoices"> <i class="fa fa-list"></i> Proforma Invoices </a> </li>
        <li class="nav-item nav-item-link <?php if($tab_link=='delivery_notes'){ echo 'active-link'; }?>"> <a class="nav-link nav-tabs-link" href="<?php echo $link_url; ?>delivery_notes"> <i class="fa fa-truck"></i> Delivery Notes </a> </li>
      </ul>
    </div>
  </div>
  
  <?php
  if($tab_link==''){
  ?>
  
  <div class="col-md-9 current-tab animated fadeInRight" id="customer_basic_info"  aria-expanded="false">
    <form class="m-b-1" action="<?php echo site_url("customers/update").'/'.$customer_id; ?>" method="post" name="edit_customer" id="edit_customer">
      <div class="box box-block bg-white">
      <input type="hidden" name="_method" value="EDIT">
      <input type="hidden" name="_token" value="<?php echo $customer_id;?>">
      <input type="hidden" name="ext_name" value="<?php echo $company_name;?>">
          <div class="row">
            <div class="col-sm-6">
              <div class="form-group">
                <label for="name">Company Name</label>
                <input class="form-control" placeholder="Company Name" name="company_name" value="<?php echo $company_name; ?>" type="text">
              </div>
              
              <div class="form-group">
                <label for="name">Customer Name</label>
                <input class="form-control" placeholder="Customer Name" name="customer_name" value="<?php echo $customer_name; ?>" type="text">
              </div>
              
              <div class="form-group">
                <label for="phone">Phone</label>
               	 <input class="form-control" placeholder="Phone" name="phone" value="<?php echo $phone; ?>" type="text">
              </div>
              
            </div>
            <div class="col-sm-6">
              <div class="form-group">
                <label for="email">Email</label>
                <input class="form-control" placeholder="Email" name="email" value="<?php echo $email; ?>" type="text">
              </div>
              
              <div class="form-group">
                <label for="email">TRN</label>
                <input class="form-control" placeholder="TRN" name="trn" type="text" value="<?php echo $trn; ?>">
              </div>
                
              <div class="form-group">
                <label for="phone">Address</label>
               	 <textarea class="form-control" placeholder="Address" name="address"><?php echo $address; ?></textarea>
              </div>
              
            </div>
          </div>
        <button type="submit" class="btn btn-primary save"><?php echo $this->lang->line('xin_update');?></button>
        </div>
    </form>
  </div>
  
  
  <?php
  }
  if($tab_link=='contact'){
  ?>
  
  
  <div class="col-md-9 current-tab animated fadeInRight">
    <div class="box box-block bg-white">
      <form id="add_contact_info" action="<?php echo site_url("customers/add_customers_contact") ?>" enctype="multipart/form-data" name="add_contact_info" method="post">
        <input type="hidden" name="customer_id" value="<?php echo $customer_id;?>">
        <input type="hidden" name="u_document_info" value="UPDATE">
        <h2><strong><?php echo $this->lang->line('xin_add_new');?></strong> Contact</h2>
        
        <div class="row">
          <div class="col-md-6">
            <div class="form-group">
              <label for="name" class="control-label">Full Name</label>
              <input class="form-control" placeholder="Full Name" name="name" type="text">
            </div>
          </div>
          <div class="col-md-6">
            <div class="form-group">
              <label for="email" class="control-label">Email</label>
              <input class="form-control" placeholder="Email" name="email" type="text">
            </div>
          </div>
        </div>
        
        <div class="row">
          <div class="col-md-6">
            <div class="form-group">
              <label for="position" class="control-label">Position</label>
              <input class="form-control" placeholder="Position" name="position" type="text">
            </div>
          </div>
          <div class="col-md-6">
            <div class="form-group">
              <label for="phone" class="control-label">Phone</label>
              <input class="form-control" placeholder="Phone" name="phone" type="text">
            </div>
          </div>
        </div>
        
        <div class="row">
          <div class="col-md-12">
            <div class="form-group">
              <div class="text-right">
                <button type="submit" class="btn btn-primary save"><?php echo $this->lang->line('xin_save');?> <i class="icon-circle-right2 position-right"></i> <i class="icon-spinner3 spinner position-left"></i></button>
              </div>
            </div>
          </div>
        </div>
      </form>
    </div>
    <div class="box box-block bg-white">
      <h2><strong>All Contacts</strong></h2>
      <div class="table-responsive" data-pattern="priority-columns">
        <table class="table table-striped table-bordered dataTable" id="customers_contact_data" style="width:100%;">
          <thead>
            <tr>
              <th>Name</th>
              <th>Email</th>
              <th>position</th>
              <th>Phone</th>
              <th>Added by</th>
              <th></th>
            </tr>
          </thead>
        </table>
      </div>
    </div>
  </div>
  
  <?php
  }if($tab_link=='quotations'){
  ?>
  
  
  <div class="col-md-9 current-tab animated fadeInRight">
    <div class="box box-block bg-white">
      <h2><strong>All Quotations</strong></h2>
      <div class="table-responsive" data-pattern="priority-columns">
        <table class="table table-striped table-bordered dataTable" id="customers_quotation_data" style="width:100%;">
          <thead>
            <tr>
              <th>Quote #</th>
              <th>Amount</th>
              <th>Date</th>
              <th>Expiry Date</th>
              <th>Reference #</th>
              <th>Added by</th>
              <th>Status</th>
            </tr>
          </thead>
        </table>
      </div>
    </div>
  </div>
  
  <?php
  }if($tab_link=='invoices'){
  ?>
  
  
  <div class="col-md-9 current-tab animated fadeInRight">
    <div class="box box-block bg-white">
      <h2><strong>All Invoices</strong></h2>
      <div class="table-responsive" data-pattern="priority-columns">
        <table class="table table-striped table-bordered dataTable" id="customers_invoices_data" style="width:100%;">
          <thead>
            <tr>
              <th> #</th>
              <th>Amount</th>
              <th>Total Tax</th>
              <th>Date</th>
              <th>Reference #</th>
              <th>Added By</th>
              <th>Status</th>
            </tr>
          </thead>
        </table>
      </div>
    </div>
  </div>
  
  <?php
  }if($tab_link=='proforma_invoices'){
  ?>
  
  
  <div class="col-md-9 current-tab animated fadeInRight">
    <div class="box box-block bg-white">
      <h2><strong>All Proforma Invoices</strong></h2>
      <div class="table-responsive" data-pattern="priority-columns">
        <table class="table table-striped table-bordered dataTable" id="customers_proforma_invoices_data" style="width:100%;">
          <thead>
            <tr>
              <th> #</th>
              <th>Amount</th>
              <th>Total Tax</th>
              <th>Date</th>
              <th>Reference #</th>
              <th>Added By</th>
              <th>Status</th>
            </tr>
          </thead>
        </table>
      </div>
    </div>
  </div>
  
  <?php
  }if($tab_link=='delivery_notes'){
  ?>
  
  
  <div class="col-md-9 current-tab animated fadeInRight">
    <div class="box box-block bg-white">
      <h2><strong>All Delivery Notes</strong></h2>
      <div class="table-responsive" data-pattern="priority-columns">
        <table class="table table-striped table-bordered dataTable" id="customers_delivery_notes_data" style="width:100%;">
          <thead>
            <tr>
              <th>#</th>
              <th>Date</th>
              <th>Reference #</th>
              <th>Added By</th>
              <th>Status</th>
            </tr>
          </thead>
        </table>
      </div>
    </div>
  </div>
  
  <?php
  }
  ?>

</div>
