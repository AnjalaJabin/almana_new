
    <label for="name">Customer</label>
      <select class="form-control quote_customer" name="customer" data-plugin="select_hrm" data-placeholder="Select Customer">
        <option value=""><?php echo $this->lang->line('xin_select_one');?></option>
        <?php foreach($all_customers as $customer) {?>
        <option value="<?php echo $customer->customer_id;?>"> <?php echo $customer->company_name;?></option>
        <?php } ?>
      </select>

<script>
$('[data-plugin="select_hrm"]').select2($(this).attr('data-options'));
$('[data-plugin="select_hrm"]').select2({ width:'100%' }); 
</script>