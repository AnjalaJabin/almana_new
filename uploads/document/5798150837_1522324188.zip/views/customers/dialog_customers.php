<?php
defined('BASEPATH') OR exit('No direct script access allowed');
if(isset($_GET['jd']) && isset($_GET['customer_id']) && $_GET['data']=='customers'){
?>

<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">×</span> </button>
  <h4 class="modal-title" id="edit-modal-data"> Edit Customer</h4>
</div>
<form class="m-b-1" action="<?php echo site_url("customers/update").'/'.$customer_id; ?>" method="post" name="edit_customer" id="edit_customer">
  <input type="hidden" name="_method" value="EDIT">
  <input type="hidden" name="_token" value="<?php echo $customer_id;?>">
  <input type="hidden" name="ext_name" value="<?php echo $company_name;?>">
  <div class="modal-body">
      <div class="row">
        <div class="col-sm-6">
          <div class="form-group">
            <label for="name">Company Name</label>
            <input class="form-control" placeholder="Company Name" name="company_name" value="<?php echo $company_name; ?>" type="text">
          </div>
          
          <div class="form-group">
            <label for="name">Customer Name</label>
            <input class="form-control" placeholder="Customer Name" name="customer_name" value="<?php echo $customer_name; ?>" type="text">
          </div>
          
          <div class="form-group">
            <label for="phone">Phone</label>
           	 <input class="form-control" placeholder="Phone" name="phone" value="<?php echo $phone; ?>" type="text">
          </div>
          
        </div>
        <div class="col-sm-6">
            
          <div class="form-group">
            <label for="phone">Address</label>
           	 <textarea class="form-control" placeholder="Address" name="address"><?php echo $address; ?></textarea>
          </div>
          
          <div class="form-group">
            <label for="email">Email</label>
            <input class="form-control" placeholder="Email" name="email" value="<?php echo $email; ?>" type="text">
          </div>
          
          <div class="form-group">
            <label for="email">TRN</label>
            <input class="form-control" placeholder="TRN" name="trn" type="text" value="<?php echo $trn; ?>">
          </div>
          
          
        </div>
      </div>
  </div>
  <div class="modal-footer">
    <button type="button" class="btn btn-link" data-dismiss="modal"><?php echo $this->lang->line('xin_close');?></button>
    <button type="submit" class="btn btn-primary save"><?php echo $this->lang->line('xin_update');?></button>
  </div>
</form>

<script type="text/javascript">
 $(document).ready(function(){
					
		// On page load: datatable
		var xin_table = $('#xin_table').dataTable({
		    "bDestroy": true,
			"processing": true,
			"serverSide": true,
			"order": [[ 1, "asc" ]],
			"ajax":{
				url :"<?php echo site_url("customers/customers_grid_data") ?>", // json datasource
				type: "post",  // method  , by default get
				error: function(error){  // error handling
					$(".employee-grid-error").html("");
					console.log(error);
					$("#xin_table").append('<tbody class="employee-grid-error"><tr><th colspan="3">No data found in the server</th></tr></tbody>');
					$("#employee-grid_processing").css("display","none");
					
				}
			}
		});
		
		$('[data-plugin="select_hrm"]').select2($(this).attr('data-options'));
		$('[data-plugin="select_hrm"]').select2({ width:'100%' });	 

		/* Edit data */
		$("#edit_customer").submit(function(e){
		e.preventDefault();
			var obj = $(this), action = obj.attr('name');
			$('.save').prop('disabled', true);
			
			$.ajax({
				type: "POST",
				url: e.target.action,
				data: obj.serialize()+"&is_ajax=1&edit_type=customer&form="+action,
				cache: false,
				success: function (JSON) {
					if (JSON.error != '') {
						toastr.error(JSON.error);
						$('.save').prop('disabled', false);
					} else {
						xin_table.api().ajax.reload(function(){ 
							toastr.success(JSON.result);
						}, true);
						$('.edit-modal-data').modal('toggle');
						$('.save').prop('disabled', false);
					}
				}
			});
		});
	});	
  </script>
<?php } else if(isset($_GET['jd']) && isset($_GET['customer_id']) && $_GET['data']=='view_customer'){
?>
<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">×</span> </button>
  <h4 class="modal-title" id="edit-modal-data">View Customer</h4>
</div>
<form class="m-b-1">
  <div class="modal-body">
      <div class="row">
        <div class="col-sm-6">
          <div class="form-group">
            <label for="name">Company Name</label>
            <input class="form-control" placeholder="Company Name" name="company_name" value="<?php echo $company_name; ?>" type="text">
          </div>
          
          <div class="form-group">
            <label for="name">Customer Name</label>
            <input class="form-control" placeholder="Customer Name" name="customer_name" value="<?php echo $customer_name; ?>" type="text">
          </div>
          
          <div class="form-group">
            <label for="phone">Phone</label>
           	 <input class="form-control" placeholder="Phone" name="phone" value="<?php echo $phone; ?>" type="text">
          </div>
          
        </div>
        <div class="col-sm-6">
            
          <div class="form-group">
            <label for="phone">Address</label>
           	 <textarea class="form-control" placeholder="Address" name="address"><?php echo $address; ?></textarea>
          </div>
          
          <div class="form-group">
            <label for="email">Email</label>
            <input class="form-control" placeholder="Email" name="email" value="<?php echo $email; ?>" type="text">
          </div>
          
          <div class="form-group">
            <label for="email">TRN</label>
            <input class="form-control" placeholder="TRN" name="trn" type="text" value="<?php echo $trn; ?>">
          </div>
          
          
        </div>
      </div>
  </div>
  <div class="modal-footer">
    <button type="button" class="btn btn-link" data-dismiss="modal"><?php echo $this->lang->line('xin_close');?></button>
  </div>
</form>
<?php }
?>
