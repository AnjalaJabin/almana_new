<?php
defined('BASEPATH') OR exit('No direct script access allowed');
if(isset($_GET['jd']) && isset($_GET['contact_id']) && $_GET['data']=='customers_contact'){
?>

<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">×</span> </button>
  <h4 class="modal-title" id="edit-modal-data"> Edit Customer Contact</h4>
</div>
<form class="m-b-1" action="<?php echo site_url("customers/update_contact").'/'.$contact_id; ?>" method="post" name="edit_customer_contact" id="edit_customer_contact">
  <input type="hidden" name="_method" value="EDIT">
  <input type="hidden" name="_token" value="<?php echo $contact_id;?>">
  <input type="hidden" name="ext_name" value="<?php echo $name;?>">
  <div class="modal-body">
      
      <div class="row">
          <div class="col-md-6">
            <div class="form-group">
              <label for="name" class="control-label">Full Name</label>
              <input class="form-control" placeholder="Full Name" name="name" type="text" value="<?php echo $name; ?>">
            </div>
          </div>
          <div class="col-md-6">
            <div class="form-group">
              <label for="email" class="control-label">Email</label>
              <input class="form-control" placeholder="Email" name="email" type="text" value="<?php echo $email; ?>">
            </div>
          </div>
        </div>
        
        <div class="row">
          <div class="col-md-6">
            <div class="form-group">
              <label for="position" class="control-label">Position</label>
              <input class="form-control" placeholder="Position" name="position" type="text" value="<?php echo $position; ?>">
            </div>
          </div>
          <div class="col-md-6">
            <div class="form-group">
              <label for="phone" class="control-label">Phone</label>
              <input class="form-control" placeholder="Phone" name="phone" type="text" value="<?php echo $phone; ?>">
            </div>
          </div>
        </div>
        
  </div>
  <div class="modal-footer">
    <button type="button" class="btn btn-link" data-dismiss="modal"><?php echo $this->lang->line('xin_close');?></button>
    <button type="submit" class="btn btn-primary save"><?php echo $this->lang->line('xin_update');?></button>
  </div>
</form>

<script type="text/javascript">
 $(document).ready(function(){
					
		// On page load: datatable
		var customers_contact_data = $('#customers_contact_data').dataTable({
            "bDestroy": true,
        	"processing": true,
        	"serverSide": true,
        	"order": [[ 1, "asc" ]],
        	"ajax":{
        		url :site_url+"customers/customers_contact_data/"+customer_id, // json datasource
        		type: "post",  // method  , by default get
        		error: function(error){  // error handling
        			$(".employee-grid-error").html("");
        			console.log(error);
        			$("#xin_table").append('<tbody class="employee-grid-error"><tr><th colspan="3">No data found in the server</th></tr></tbody>');
        			$("#employee-grid_processing").css("display","none");
        			
        		}
        	}
        });
		
		$('[data-plugin="select_hrm"]').select2($(this).attr('data-options'));
		$('[data-plugin="select_hrm"]').select2({ width:'100%' });	 

		/* Edit data */
		$("#edit_customer_contact").submit(function(e){
		e.preventDefault();
			var obj = $(this), action = obj.attr('name');
			$('.save').prop('disabled', true);
			
			$.ajax({
				type: "POST",
				url: e.target.action,
				data: obj.serialize()+"&is_ajax=1&edit_type=customer_contact&form="+action,
				cache: false,
				success: function (JSON) {
					if (JSON.error != '') {
						toastr.error(JSON.error);
						$('.save').prop('disabled', false);
					} else {
						customers_contact_data.api().ajax.reload(function(){ 
							toastr.success(JSON.result);
						}, true);
						$('.edit-modal-data').modal('toggle');
						$('.save').prop('disabled', false);
					}
				}
			});
		});
	});	
  </script>
<?php }
?>