
<?php $session = $this->session->userdata('username');?>

<div class="box box-block bg-white">
  <h2><strong><?php echo $this->lang->line('xin_list_all');?></strong> All Customers
  </h2>
  <div class="table-responsive" data-pattern="priority-columns">
    <table class="table table-striped table-bordered dataTable" id="xin_table" style="width:100%;">
      <thead>
        <tr>
          <th>Company Name</th>
          <th>Address</th>
          <th>Customer Name</th>
          <th>Email</th>
          <th>Phone</th>
          <th>Added By</th>
        </tr>
      </thead>
    </table>
  </div>
</div>
