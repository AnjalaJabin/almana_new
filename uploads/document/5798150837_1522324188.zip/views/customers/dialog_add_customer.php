<?php
defined('BASEPATH') OR exit('No direct script access allowed');
if(isset($_GET['jd']) && $_GET['data']=='add_customer'){
?>
<form class="m-b-1" action="<?php echo site_url("customers/add_customer"); ?>" method="post" name="add_new_customer_popup" id="add_new_customer_popup">
    
<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">×</span> </button>
  <h4 class="modal-title" id="edit-modal-data">Add New Customer</h4>
</div>
  <div class="modal-body">
    <div class="row">
        <div class="col-sm-12">
          <div class="form-group">
            <label for="name">Company Name</label>
            <input class="form-control" placeholder="Company Name" name="company_name" type="text">
          </div>
          <div class="form-group">
            <label for="email">Contact Name</label>
            <input class="form-control" placeholder="Customer Name" name="customer_name" type="text">
          </div>
          
          <div class="form-group">
            <label for="phone">Phone</label>
           	 <input class="form-control" placeholder="Phone" name="phone" type="text">
          </div>
            
          <div class="form-group">
            <label for="phone">Address</label>
           	 <textarea class="form-control" placeholder="Address" name="address"></textarea>
          </div>
          
          <div class="form-group">
            <label for="email">Email</label>
            <input class="form-control" placeholder="Email" name="email" type="text">
          </div>
          
          <div class="form-group">
            <label for="email">TRN</label>
            <input class="form-control" placeholder="TRN" name="trn" type="text">
          </div>
          
        </div>
    </div>
    
  </div>
  
  <div class="modal-footer">
    <button type="submit" class="form-control btn btn-primary save"><?php echo $this->lang->line('xin_save');?> Customer</button>
  </div>
  
  </form>

<script type="text/javascript">
    $('#description').summernote({
      height: 206,
      minHeight: null,
      maxHeight: null,
      focus: false
    });
 $(document).ready(function(){
     
        $('[data-plugin="select_hrm"]').select2($(this).attr('data-options'));
        $('[data-plugin="select_hrm"]').select2({ width:'100%' }); 
					
		// On page load: datatable
		var xin_table = $('#xin_table').dataTable({
			"bDestroy": true,
			"ajax": {
				url : "<?php echo site_url("price/price_list") ?>",
				type : 'GET'
			},
			"fnDrawCallback": function(settings){
			$('[data-toggle="tooltip"]').tooltip();          
			}
    	});
		
		$('[data-plugin="select_xhrm"]').select2($(this).attr('data-options'));
		$('[data-plugin="select_xhrm"]').select2({ width:'100%' });	 
		
		
		$("#add_new_customer_popup").submit(function(e){
		e.preventDefault();
			var obj = $(this), action = obj.attr('name');
			$('.save').prop('disabled', true);
			
			$.ajax({
				type: "POST",
				url: e.target.action,
				data: obj.serialize()+"&is_ajax=1&add_type=customers&form="+action,
				cache: false,
				success: function (JSON) {
					if (JSON.error != '') {
						toastr.error(JSON.error);
						$('.save').prop('disabled', false);
					} else {
					    $('.add-modal-data').modal('toggle');
						toastr.success(JSON.result);
						$('.save').prop('disabled', false);
						jQuery.get("<?php echo site_url() ?>customers/customers_select_list", function(data, status){
                            jQuery('#group_ajax').html(data);
                        });
						
					}
				}
			});
		});
		
		
		
		
	});
  </script>
<?php }
?>