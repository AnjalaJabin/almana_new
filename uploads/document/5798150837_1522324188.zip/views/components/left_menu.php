<?php
$session = $this->session->userdata('username');
$user_info = $this->Xin_model->read_user_info($session['user_id']);
$role_user = $this->Xin_model->read_user_role_info($user_info[0]->user_role_id);
$designation_info = $this->Xin_model->read_designation_info($user_info[0]->designation_id);
$role_resources_ids = explode(',',$role_user[0]->role_resources);


	    $user_id = $session['user_id'];
	    $root_id   = $_SESSION['root_id'];
	    
	    $condition = "root_id ='" . $root_id . "' and added_by!='".$user_id."' and status= '0' order by id desc limit 200";
        $this->db->select('*');
		$this->db->from('pricing_price_request');
		$this->db->where($condition);
		$query = $this->db->get();
		$all_requests = $query->num_rows();
		
		$condition = "root_id ='" . $root_id . "' and added_by='".$user_id."' and status = '1' and read_status = '0' order by id desc limit 200";
        $this->db->select('*');
		$this->db->from('pricing_price_request');
		$this->db->where($condition);
		$query = $this->db->get();
		$my_requests = $query->num_rows();
		
		$not_data = array(
		    'all_requests' => $all_requests,
		    'my_requests'  => $my_requests
		    );

$my_price_request_count = '';
$price_request_count    = '';
$price_notifications = $not_data;

if($price_notifications['all_requests']>0){
    $price_request_count = '<span style="border-radius: 25px;" class="tag tag-danger pull-right">'.$price_notifications['all_requests'].'</span>';
}

if($price_notifications['my_requests']>0){
    $my_price_request_count = '<span style="border-radius: 25px;" class="tag tag-success pull-right">'.$price_notifications['my_requests'].'</span>';
}

?>
<!-- menu start-->

<div class="site-sidebar">
  <div class="custom-scroll custom-scroll-light">
    <ul class="sidebar-menu">
      <li class="menu-title"><?php echo $this->lang->line('dashboard_main');?></li>
      <li> <a href="<?php echo site_url('dashboard');?>" class="waves-effect waves-light"> <span class="s-icon"><i class="fa fa-home"></i></span> <span class="s-text"><?php echo $this->lang->line('dashboard_title');?></span> </a> </li>
      
      <li> <a href="<?php echo site_url('customers');?>" class="waves-effect waves-light"> <span class="s-icon"><i class="ti-user">   </i></span> <span class="s-text">Customers</span> </a></li>
      
      <?php if(in_array('62',$role_resources_ids) || in_array('63',$role_resources_ids) || in_array('64',$role_resources_ids)) {?>
      <li> <a href="<?php echo site_url('suppliers');?>" class="waves-effect waves-light"> <span class="s-icon"><i class="ti-truck">   </i></span> <span class="s-text">Suppliers</span> </a></li>
      <?php } 
      if(in_array('63',$role_resources_ids) || in_array('64',$role_resources_ids) || in_array('65',$role_resources_ids)) {
      ?>
        <li> <a href="<?php echo site_url('price/price_history');?>" class="waves-effect waves-light"> <span class="s-icon"><i class="ti-book">   </i></span> <span class="s-text">Supplier Price History</span> </a></li>
      <?php
      }
      ?>
      <li> <a href="<?php echo site_url('price/given_price_history');?>" class="waves-effect waves-light"> <span class="s-icon"><i class="ti-list">   </i></span> <span class="s-text">Customer Price History</span> </a></li>
      
      <li class="with-sub"> <a href="javascript:void(0);" class="waves-effect  waves-light"> <span class="s-caret"><i class="fa fa-angle-down"></i></span> <span class="s-icon"><i class="fa fa-book"></i></span> <span class="s-text">Sales </span> </a>
        <ul>
          <li><a href="<?php echo site_url('quote');?>">Quotations</a></li>
          <li><a href="<?php echo site_url('invoices');?>">Invoices</a></li>
          <li><a href="<?php echo site_url('proforma_invoices');?>">Proforma Invoices</a></li>
          <li><a href="<?php echo site_url('purchase_order');?>">Purchase Order</a></li>
          <li><a href="<?php echo site_url('delivery_note');?>">Delivery Note</a></li>
        </ul>
      </li>
      
      <li> <a href="<?php echo site_url('price/all_price_requests');?>" class="waves-effect waves-light"> <span class="s-icon"><i class="ti-check">   </i></span> <span class="s-text">Price Requests <span id="price_request_count"><?php echo $price_request_count; ?></span>  </span> </a></li>
      <li> <a href="<?php echo site_url('price/my_price_requests');?>" class="waves-effect waves-light"> <span class="s-icon"><i class="ti-check">   </i></span> <span class="s-text">My Price Requests <span id="my_price_request_count"><?php echo $my_price_request_count; ?></span> </span> </a></li>
      
      <?php if(in_array('66',$role_resources_ids) || in_array('67',$role_resources_ids) || in_array('68',$role_resources_ids)) {?>
      <li> <a href="<?php echo site_url('products');?>" class="waves-effect waves-light"> <span class="s-icon"><i class="ti-bag">   </i></span> <span class="s-text">Products</span> </a></li>
      <?php } ?>
      
      <li> <a href="<?php echo site_url();?>settings/" class="waves-effect waves-light"> <span class="s-icon"><i class="ti-settings"></i></span> <span class="s-text"><?php echo $this->lang->line('left_settings');?></span> </a> </li>
      
      <?php 
      if(in_array('72',$role_resources_ids) || in_array('73',$role_resources_ids) || in_array('74',$role_resources_ids)){?>
      <li class="with-sub"> <a href="javascript:void(0);" class="waves-effect  waves-light"> <span class="s-caret"><i class="fa fa-angle-down"></i></span> <span class="s-icon"><i class="fa fa-book"></i></span> <span class="s-text">Reports </span> </a>
        <ul>
          <?php if(in_array('72',$role_resources_ids)){?> <li><a href="<?php echo site_url('customers/all_customers');?>">All Customers</a></li> <?php } ?>
          <?php if(in_array('72',$role_resources_ids)){?> <li><a href="<?php echo site_url('price/all_given_price_history');?>">All Customer Price History</a></li> <?php } ?>
          <?php if(in_array('73',$role_resources_ids)){?> <li><a href="<?php echo site_url('quote/all_quotes');?>">All Quotations</a></li> <?php } ?>
          <?php if(in_array('74',$role_resources_ids)){?> <li><a href="<?php echo site_url('invoices/all_invoices');?>">All Invoices</a></li> <?php } ?>
          <?php if(in_array('74',$role_resources_ids)){?> <li><a href="<?php echo site_url('proforma_invoices/all_invoices');?>">All Proforma Invoices</a></li> <?php } ?>
          <?php if(in_array('74',$role_resources_ids)){?> <li><a href="<?php echo site_url('purchase_order/all_purchase_orders');?>">All Purchase Orders</a></li> <?php } ?>
          <?php if(in_array('74',$role_resources_ids)){?> <li><a href="<?php echo site_url('delivery_note/all_delivery_notes');?>">All Delivery Notes</a></li> <?php } ?>
        </ul>
      </li>
      <?php } ?>
      
      <li> <a href="<?php echo site_url();?>logout" class="waves-effect waves-light"> <span class="s-icon"><i class="fa fa-sign-out"></i></span> <span class="s-text"><?php echo $this->lang->line('left_logout');?></span> </a> </li>
      <?php ?>
    </ul>
  </div>
</div>
<!-- menu end--> 
