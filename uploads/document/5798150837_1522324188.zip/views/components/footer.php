<?php $system = $this->Xin_model->read_setting_info(1);?>
<footer class="footer">
    <div class="container-fluid">
        <?php echo date('Y');?> © Corbuz Pricing
        <a style="margin-left:15px;" href="https://www.corbuz.com/privacy_and_security.html" target="blank">Privacy & Security</a>
    </div>
</footer>