<?php
defined('BASEPATH') OR exit('No direct script access allowed');
if(isset($_GET['jd']) && isset($_GET['employee_id']) && $_GET['data']=='employee'){
?>

<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">×</span> </button>
  <h4 class="modal-title" id="edit-modal-data"><i class="icon-pencil7"></i> Edit Employee</h4>
</div>
<form class="m-b-1" action="<?php echo site_url("employees/update").'/'.$employee_id; ?>" enctype="multipart/form-data" method="post" name="edit_employee" id="edit_employee">
  <input type="hidden" name="_method" value="EDIT">
  <input type="hidden" name="_token" value="<?php echo $_GET['employee_id'];?>">
  <input type="hidden" name="user_id" value="<?php echo $_GET['employee_id'];?>">
  <div class="modal-body">
    <div class="row">
        <div class="col-md-12">
          <div class="row">
            <div class="col-md-6">
              <div class="form-group">
                <label for="first_name"><?php echo $this->lang->line('xin_employee_first_name');?></label>
                <input class="form-control" placeholder="<?php echo $this->lang->line('xin_employee_first_name');?>" name="first_name" type="text" tabindex="1" value="<?php echo $first_name; ?>">
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group">
                <label for="last_name" class="control-label"><?php echo $this->lang->line('xin_employee_last_name');?></label>
                <input class="form-control" placeholder="<?php echo $this->lang->line('xin_employee_last_name');?>" name="last_name" type="text" tabindex="2" value="<?php echo $last_name; ?>">
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-6">
              <div class="form-group">
                <label for="designation"><?php echo $this->lang->line('xin_designation');?></label>
                <select class="form-control" name="designation_id" data-placeholder="<?php echo $this->lang->line('xin_designation');?>" tabindex="6">
                  <option value="">Select One</option>
                  <?php foreach($all_designations as $designations) {?>
                  <option <?php if($designation_id==$designations->designation_id){ echo 'selected'; } ?> value="<?php echo $designations->designation_id?>"><?php echo $designations->designation_name?></option>
                  <?php } ?>
                </select>
                
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group">
                <label for="email" class="control-label"><?php echo $this->lang->line('dashboard_email');?></label>
                <input class="form-control" placeholder="<?php echo $this->lang->line('dashboard_email');?>" name="email" type="text" tabindex="10" value="<?php echo $email; ?>">
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-6">
              <div class="form-group">
                <label for="contact_no" class="control-label"><?php echo $this->lang->line('xin_contact_number');?></label>
                <input class="form-control" placeholder="<?php echo $this->lang->line('xin_contact_number');?>" name="contact_no" type="text" tabindex="13" value="<?php echo $contact_no; ?>">
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group">
                <label for="role">Permission</label>
                <select class="form-control" name="role" data-placeholder="Permission" tabindex="7">
                  <option value="">Select One</option>
                  <?php foreach($all_user_roles as $role) {?>
                  <option <?php if($user_role_id==$role->role_id){ echo 'selected'; } ?> value="<?php echo $role->role_id?>"><?php echo $role->role_name?></option>
                  <?php } ?>
                </select>
              </div>
            </div>
        </div>
    </div>
  </div>
  <div class="modal-footer">
    <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo $this->lang->line('xin_close');?></button>
    <button type="submit" class="btn btn-primary save"><?php echo $this->lang->line('xin_update');?></button>
  </div>
</form>
<script type="text/javascript">
 $(document).ready(function(){
					
		// On page load: datatable
		var xin_table = $('#xin_table').dataTable({
        	"bDestroy": true,
        	"ajax": {
        		url : base_url+"/employees_list/",
        		type : 'GET'
        	},
        	"fnDrawCallback": function(settings){
        	$('[data-toggle="tooltip"]').tooltip();          
        	}
        });
		
		$('[data-plugin="select_hrm"]').select2($(this).attr('data-options'));
		$('[data-plugin="select_hrm"]').select2({ width:'100%' });	 

		/* Edit data */
		$("#edit_employee").submit(function(e){
			var fd = new FormData(this);
			var obj = $(this), action = obj.attr('name');
			fd.append("is_ajax", 2);
			fd.append("edit_type", 'basic_info');
			fd.append("form", action);
			e.preventDefault();
			$('.save').prop('disabled', true);
			$.ajax({
				url: e.target.action,
				type: "POST",
				data:  fd,
				contentType: false,
				cache: false,
				processData:false,
				success: function(JSON)
				{
					if (JSON.error != '') {
						toastr.error(JSON.error);
						$('.save').prop('disabled', false);
					} else {
						xin_table.api().ajax.reload(function(){ 
							toastr.success(JSON.result);
						}, true);
						$('.edit-modal-data').modal('toggle');
						$('.save').prop('disabled', false);
					}
				},
				error: function() 
				{
					toastr.error(JSON.error);
					$('.save').prop('disabled', false);
				} 	        
		   });
		});
	});	
  </script>
<?php } ?>