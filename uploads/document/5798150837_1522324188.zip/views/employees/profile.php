<?php
/* Profile view
*/
?>
<?php $session = $this->session->userdata('username');?>
<?php $user = $this->Xin_model->read_user_info($session['user_id']);?>
<?php $system = $this->Xin_model->read_setting_info(1);?>

<div class="profile-header mb-1">
  <div class="profile-header-cover img-cover" style="background-image: url(<?php echo base_url().'uploads/profile/background/'.$user[0]->profile_background;?>);" ></div>
  <div class="profile-header-counters clearfix">
    <div class="container-fluid">
      <div class="float-xs-right"> <a href="#" class="text-black">
        <h5 class="font-weight-bold"><?php echo $this->lang->line('dashboard_last_login');?></h5>
        <span class="text-muted">
        <?php if($system[0]->enable_profile_background=='yes'):?>
        <span class="profile-btn" style="position:absolute; margin-top:-105px;">
        <form name="profile_background" id="profile_background" enctype="multipart/form-data">
          <input type="hidden" name="user_id" value="<?php echo $session['user_id'];?>">
          <span class="btn btn-primary btn-file"> Browse
          <input type="file" name="p_file" id="p_file">
          </span> <span>
          <button type="submit" class="btn btn-primary save"><?php echo $this->lang->line('xin_save');?></button>
          </span>
        </form>
        </span>
        <?php endif;?>
        <?php 
			  $gdate = explode(' ',$last_login_date);
			  $login_date = $this->Xin_model->set_date_format($gdate[0]);
			  echo $login_date.' '.date('h:i A', strtotime($last_login_date));?>
        <?php echo $this->lang->line('xin_e_details_from');?> <?php echo $last_login_ip;?></span> </a> </div>
    </div>
  </div>
</div>
<div class="row">
  <div class="col-sm-4 col-md-3">
    <div class="card profile-card" style="margin-top: -316px;">
      <div class="user-5">
        <div class="u-content">
          <div class="avatar box-96 mb-2">
            <?php if($profile_picture!='' && $profile_picture!='no file') {?>
            <img src="<?php echo base_url().'uploads/profile/'.$profile_picture;?>" alt="" id="user_avatar" class="b-a-radius-circle user_profile_avatar">
            <?php } else {?>
            <?php if($gender=='Male') { ?>
            <?php $de_file = base_url().'uploads/profile/default_male.jpg';?>
            <?php } else { ?>
            <?php $de_file = base_url().'uploads/profile/default_female.jpg';?>
            <?php } ?>
            <img src="<?php echo $de_file;?>" alt="" id="user_avatar" class=" b-a-radius-circle user_profile_avatar">
            <?php } ?>
            <i class="status bg-success bottom right"></i> </div>
          <h5><a class="text-black" href="javascript:void(0);"><?php echo $first_name. ' ' .$last_name;?></a></h5>
          <p class="text-muted mb-1"><?php echo $designation;?></p>
          
          <!--
          <button type="button" class="btn bg-facebook btn-circle" data-toggle="tooltip" data-placement="top" data-title="<?php echo $this->lang->line('xin_e_details_fb');?>" data-original-title="" title="">
          <a href="<?php echo $facebook_link;?>" target="_blank" class="profile-social"> <i class="fa fa-facebook"></i></a>
          </button>
          <button type="button" class="btn bg-twitter btn-circle" data-toggle="tooltip" data-placement="top" data-title="<?php echo $this->lang->line('xin_e_details_twit');?>" data-original-title="" title="">
          <a href="<?php echo $twitter_link;?>" target="_blank" class="profile-social"> <i class="fa fa-twitter"></i></a>
          </button>
          <button type="button" class="btn bg-googleplus btn-circle" data-toggle="tooltip" data-placement="top" data-title="<?php echo $this->lang->line('xin_e_details_gplus');?>" data-original-title="" title="">
          <a href="<?php echo $google_plus_link;?>" target="_blank" class="profile-social"> <i class="fa fa-google-plus"></i></a>
          </button>
          <button type="button" class="btn bg-linkedin btn-circle" data-toggle="tooltip" data-placement="top" data-title="<?php echo $this->lang->line('xin_e_details_lnkdin');?>" data-original-title="" title="">
          <a href="<?php echo $linkdedin_link;?>" target="_blank" class="profile-social"> <i class="fa fa-linkedin"></i></a>
          </button>
          <button type="button" class="btn bg-dropbox btn-circle" data-toggle="tooltip" data-placement="top" data-title="<?php echo $this->lang->line('xin_e_details_blgr');?>" data-original-title="" title="">
          <a href="<?php echo $blogger_link;?>" target="_blank" class="profile-social"> <i class="fa fa-pencil"></i></a>
          </button>
          -->
          
        </div>
      </div>
    </div>
  </div>
</div>
<div class="row m-b-1">
  <div class="col-md-3">
    <div class="box bg-white">
      <ul class="nav nav-4 nav-tabs-link-cl">
        <?php if($system[0]->employee_manage_own_profile=='yes'){?>
        <li class="nav-item nav-item-link active-link" id="user_details_1"> <a class="nav-link nav-tabs-link" href="#user_basic_info" data-profile="1" data-profile-block="user_basic_info" data-toggle="tab" aria-expanded="true"> <i class="fa fa-user"></i> <?php echo $this->lang->line('xin_e_details_basic');?> </a> </li>
        <?php } ?>
        <?php if($system[0]->employee_manage_own_picture=='yes'){?>
        <li class="nav-item nav-item-link" id="user_details_2"> <a class="nav-link nav-tabs-link" href="#profile-picture" data-profile="2" data-profile-block="profile_picture" data-toggle="tab" aria-expanded="true"> <i class="fa fa-camera"></i> <?php echo $this->lang->line('xin_e_details_profile_picture');?> </a> </li>
        <?php } ?>
        <li class="nav-item nav-item-link" id="user_details_3"> <a class="nav-link nav-tabs-link" href="#smtp_settings" data-profile="3" data-profile-block="smtp_settings" data-toggle="tab" aria-expanded="true"> <i class="fa fa-paper-plane"></i> Mail Settings </a> </li>
        <li class="nav-item nav-item-link b-b-0" id="user_details_14"> <a class="nav-link nav-tabs-link" href="#change_password" data-profile="14" data-profile-block="change_password" data-toggle="tab" aria-expanded="true"> <i class="fa fa-key"></i> <?php echo $this->lang->line('xin_e_details_cpassword');?> </a> </li>
      </ul>
    </div>
  </div>
  <div class="col-md-9 current-tab animated fadeInRight" id="user_basic_info"  aria-expanded="false">
    <form id="basic_info" action="<?php echo site_url("profile/user_basic_info") ?>" name="basic_info" method="post">
      <input type="hidden" name="user_id" value="<?php echo $session['user_id'];?>">
      <input type="hidden" name="u_basic_info" value="UPDATE">
      <div class="box box-block bg-white">
        <h2><strong><?php echo $this->lang->line('xin_e_details_basic_info');?></strong></h2>
        <div class="row">
          <div class="col-md-6">
            <div class="form-group">
              <label for="first_name"><?php echo $this->lang->line('xin_employee_first_name');?></label>
              <input class="form-control" placeholder="<?php echo $this->lang->line('xin_employee_first_name');?>" name="first_name" type="text" value="<?php echo $first_name;?>">
            </div>
          </div>
          <div class="col-md-6">
            <div class="form-group">
              <label for="last_name" class="control-label"><?php echo $this->lang->line('xin_employee_last_name');?></label>
              <input class="form-control" placeholder="<?php echo $this->lang->line('xin_employee_last_name');?>" name="last_name" type="text" value="<?php echo $last_name;?>">
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-6">
            <div class="form-group">
              <label for="email" class="control-label"><?php echo $this->lang->line('dashboard_email');?></label>
              <input class="form-control" placeholder="<?php echo $this->lang->line('dashboard_email');?>" name="email" type="text" value="<?php echo $email;?>">
            </div>
          </div>
          <div class="col-md-6">
            <div class="form-group">
              <label for="date_of_birth"><?php echo $this->lang->line('xin_employee_dob');?></label>
              <input class="form-control date" readonly placeholder="<?php echo $this->lang->line('xin_employee_dob');?>" name="date_of_birth" type="text" value="<?php echo $date_of_birth;?>">
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-4">
            <div class="form-group">
              <label for="gender" class="control-label"><?php echo $this->lang->line('xin_employee_gender');?></label>
              <select class="form-control" name="gender" data-plugin="select_hrm" data-placeholder="<?php echo $this->lang->line('xin_employee_gender');?>">
                <option value="Male" <?php if($gender=='Male'):?> selected <?php endif; ?>>Male</option>
                <option value="Female" <?php if($gender=='Female'):?> selected <?php endif; ?>>Female</option>
              </select>
            </div>
          </div>
          
          <div class="col-md-4">
            <div class="form-group">
              <label for="contact_no" class="control-label"><?php echo $this->lang->line('xin_contact_number');?></label>
              <input class="form-control" placeholder="<?php echo $this->lang->line('xin_contact_number');?>" name="contact_no" type="text" value="<?php echo $contact_no;?>">
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12">
            <div class="form-group">
              <label for="address"><?php echo $this->lang->line('xin_employee_address');?></label>
              <textarea class="form-control" placeholder="<?php echo $this->lang->line('xin_employee_address');?>" name="address" cols="30" rows="3" id="address"><?php echo $address;?></textarea>
            </div>
          </div>
        </div>
        <button type="submit" class="btn btn-primary save"><?php echo $this->lang->line('xin_save');?></button>
      </div>
    </form>
  </div>
  <div class="col-md-9 current-tab animated fadeInRight" id="profile_picture" style="display:none;">
    <form id="f_profile_picture" action="<?php echo site_url("employees/profile_picture") ?>" name="profile_picture" method="post">
      <input type="hidden" name="user_id" id="user_id" value="<?php echo $session['user_id'];?>">
      <input type="hidden" name="session_id" id="session_id" value="<?php echo $session['user_id'];?>">
      <input type="hidden" name="u_profile_picture" value="UPDATE">
      <div class="box box-block bg-white">
        <h2><strong><?php echo $this->lang->line('xin_e_details_profile_picture');?></strong></h2>
        <div class="row">
          <div class="col-md-12">
            <div class='form-group'> <span class="btn btn-primary btn-file"> Browse
              <input type="file" name="p_file" id="p_file">
              </span>
              <?php if($profile_picture!='' && $profile_picture!='no file') {?>
              <img src="<?php echo site_url().'uploads/profile/'.$profile_picture;?>" width="50px" style="margin-left:20px;" id="u_file">
              <?php } else {?>
              <?php if($gender=='Male') { ?>
              <?php $de_file = site_url().'uploads/profile/default_male.jpg';?>
              <?php } else { ?>
              <?php $de_file = site_url().'uploads/profile/default_female.jpg';?>
              <?php } ?>
              <img src="<?php echo $de_file;?>" width="50px" style="margin-left:20px;" id="u_file">
              <?php } ?>
              <br>
              <small><?php echo $this->lang->line('xin_e_details_picture_type');?></small>
              <?php if($profile_picture!='' && $profile_picture!='no file') {?>
              <br />
              <label class="custom-control custom-checkbox">
                <input type="checkbox" class="custom-control-input" id="remove_profile_picture" value="1" name="remove_profile_picture">
                <span class="custom-control-indicator"></span> <span class="custom-control-description"><?php echo $this->lang->line('xin_e_details_remove_pic');?></span> </label>
              <?php } else {?>
              <div id="remove_file" style="display:none;">
                <label class="custom-control custom-checkbox">
                  <input type="checkbox" class="custom-control-input" id="remove_profile_picture" value="1" name="remove_profile_picture">
                  <span class="custom-control-indicator"></span> <span class="custom-control-description"><?php echo $this->lang->line('xin_e_details_remove_pic');?></span> </label>
              </div>
              <?php } ?>
            </div>
          </div>
        </div>
        <button type="submit" class="btn btn-primary save"><?php echo $this->lang->line('xin_save');?></button>
      </div>
    </form>
  </div>
  
  
  <div class="col-md-9 current-tab animated fadeInRight" id="smtp_settings" style="display:none;">
    <div class="box box-block bg-white">
      <form id="update_smtp_settings" action="<?php echo site_url("employees/update_smtp_settings");?>" name="e_change_password" method="post">
        <input type="hidden" name="user_id" value="<?php echo $session['user_id'];?>">
        <input type="hidden" name="u_basic_info" value="UPDATE">
        <input type="hidden" name="type" value="smtp_settings">
        
        <h2><strong>SMTP</strong> Configuration</h2>
        <div class="row">
          <div class="col-md-6">
            <div class="form-group">
              <label for="smtp_host">Host</label>
              <input class="form-control" placeholder="SMTP Host" name="smtp_host" type="text" value="<?php echo $smtp_host;?>">
            </div>
          </div>
          <div class="col-md-3">
            <div class="form-group">
              <label for="smtp_host">Port</label>
              <input class="form-control" placeholder="SMTP Port" name="smtp_port" type="text" value="<?php echo $smtp_port;?>">
            </div>
          </div>
          <div class="col-md-3">
            <div class="form-group">
              <label for="smtp_host">Connection Type</label>
              <select class="form-control" name="smtp_connection">
                  <option <?php if($smtp_connection=='tls'){ echo 'selected';  } ?> value="tls">TLS</option>
                  <option <?php if($smtp_connection=='ssl'){ echo 'selected';  } ?> value="ssl">SSL</option>
              </select>
            </div>
          </div>
        </div>
        
        <div class="row">
          <div class="col-md-6">
            <div class="form-group">
              <label for="smtp_host">Username</label>
              <input class="form-control" placeholder="Username" name="smtp_username" type="text" value="<?php echo $smtp_username;?>">
            </div>
          </div>
          <div class="col-md-6">
            <div class="form-group">
              <label for="smtp_host">Password</label>
              <input class="form-control" placeholder="Password" name="smtp_password" type="password" value="<?php echo $smtp_password;?>">
            </div>
          </div>
        </div>
        
        <div class="row">
          <div class="col-md-6">
            <div class="form-group">
              <label for="smtp_host">Global from Mail</label>
              <input class="form-control" placeholder="Global from address" name="smtp_global_from_mail" type="text" value="<?php echo $smtp_global_from_mail;?>">
            </div>
          </div>
          <div class="col-md-6">
            <div class="form-group">
              <label for="smtp_host">Global from name</label>
              <input class="form-control" placeholder="Global from name" name="smtp_global_from_name" type="text" value="<?php echo $smtp_global_from_name;?>">
            </div>
          </div>
          
          <div class="col-md-12">
            <div class="form-group">
                <label for="smtp_host">Email Signature</label>
                <textarea class="form-control textarea" id="email_signature" name="email_signature"><?php echo $email_signature;?></textarea>
            </div>
          </div>
        </div>
        
        <div class="row">
          <div class="col-md-12">
            <div class="form-group">
              <button type="submit" class="btn btn-primary save col-right">Configure and Save</button>
            </div>
          </div>
        </div>
      </form>
    </div>
  </div>
  
  
  <div class="col-md-9 current-tab animated fadeInRight" id="change_password" style="display:none;">
    <div class="box box-block bg-white">
      <form id="e_change_password" action="<?php echo site_url("employees/change_password");?>" name="e_change_password" method="post">
        <input type="hidden" name="user_id" value="<?php echo $session['user_id'];?>">
        <input type="hidden" name="u_basic_info" value="UPDATE">
        <h2><strong><?php echo $this->lang->line('xin_e_details_eforce');?></strong> <?php echo $this->lang->line('header_change_password');?></h2>
        <div class="row">
          <div class="col-md-6">
            <div class="form-group">
              <label for="new_password"><?php echo $this->lang->line('xin_e_details_enpassword');?></label>
              <input class="form-control" placeholder="<?php echo $this->lang->line('xin_e_details_enpassword');?>" name="new_password" type="text">
            </div>
          </div>
          <div class="col-md-6">
            <div class="form-group">
              <label for="new_password_confirm" class="control-label"><?php echo $this->lang->line('xin_e_details_ecnpassword');?></label>
              <input class="form-control" placeholder="<?php echo $this->lang->line('xin_e_details_ecnpassword');?>" name="new_password_confirm" type="text">
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12">
            <div class="form-group">
              <button type="submit" class="btn btn-primary save col-right"><?php echo $this->lang->line('xin_save');?></button>
            </div>
          </div>
        </div>
      </form>
    </div>
  </div>
</div>
