<?php
/* Employees view
*/
?>
<?php $session = $this->session->userdata('username');?>

<div class="add-form" style="display:none;">
  <div class="box box-block bg-white">
    <h2><strong><?php echo $this->lang->line('xin_add_new');?></strong> <?php echo $this->lang->line('xin_employee');?>
      <div class="add-record-btn">
        <button class="btn btn-sm btn-primary add-new-form"><i class="fa fa-minus icon"></i> <?php echo $this->lang->line('xin_hide');?></button>
      </div>
    </h2>
    <div class="row m-b-1">
      <div class="col-md-12">
        <form action="<?php echo site_url("employees/add_employee") ?>" method="post" name="add_employee" id="xin-form">
          <input type="hidden" name="_user" value="<?php echo $session['user_id'];?>">
          <div class="bg-white">
            <div class="box-block">
              <div class="row">
                <div class="col-md-6">
                  <div class="row">
                    <div class="col-md-6">
                      <div class="form-group">
                        <label for="first_name"><?php echo $this->lang->line('xin_employee_first_name');?></label>
                        <input class="form-control" placeholder="<?php echo $this->lang->line('xin_employee_first_name');?>" name="first_name" type="text" tabindex="1">
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label for="last_name" class="control-label"><?php echo $this->lang->line('xin_employee_last_name');?></label>
                        <input class="form-control" placeholder="<?php echo $this->lang->line('xin_employee_last_name');?>" name="last_name" type="text" tabindex="2">
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-6">
                      <div class="form-group">
                        <label for="designation"><?php echo $this->lang->line('xin_designation');?></label>
                        <select class="form-control" name="designation_id" data-placeholder="<?php echo $this->lang->line('xin_designation');?>" tabindex="6">
                          <option value="">Select One</option>
                          <?php foreach($all_designations as $designations) {?>
                          <option value="<?php echo $designations->designation_id?>"><?php echo $designations->designation_name?></option>
                          <?php } ?>
                        </select>
                        
                        <a class="btn btn-sm btn-primary pull-right text-white" id="des_add_btn"><i class="fa fa-plus icon"></i>New</a>
                        <div style="background:#ddd; padding:7px; display:none;" id="des_add_div">
                            <div class="input-group">
                               <input type="text" class="form-control" placeholder="Designation" id="des_add_val">
                               <span class="input-group-btn">
                                    <button class="btn btn-success" type="button" id="des_sub_btn">Add</button>
                               </span>
                               <span class="input-group-btn">
                                    <button class="btn" type="button" id="des_close_btn">X</button>
                               </span>
                            </div>
                        </div>
                        
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label for="email" class="control-label"><?php echo $this->lang->line('dashboard_email');?></label>
                        <input class="form-control" placeholder="<?php echo $this->lang->line('dashboard_email');?>" name="email" type="text" tabindex="10">
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-6">
                      <div class="form-group">
                        <label for="contact_no" class="control-label"><?php echo $this->lang->line('xin_contact_number');?></label>
                        <input class="form-control" placeholder="<?php echo $this->lang->line('xin_contact_number');?>" name="contact_no" type="text" tabindex="13">
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label for="role">Permission</label>
                        <select class="form-control" name="role" data-placeholder="Permission" tabindex="7">
                          <option value="">Select One</option>
                          <?php foreach($all_user_roles as $role) {?>
                          <option value="<?php echo $role->role_id?>"><?php echo $role->role_name?></option>
                          <?php } ?>
                        </select>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              
              <button type="submit" class="btn btn-primary save"><?php echo $this->lang->line('xin_save');?></button>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<div class="box box-block bg-white">
  <h2><strong><?php echo $this->lang->line('xin_list_all');?></strong> <?php echo $this->lang->line('xin_employees');?>
    <div class="add-record-btn">
      <button class="btn btn-sm btn-primary add-new-form"><i class="fa fa-plus icon"></i> <?php echo $this->lang->line('xin_add_new');?></button>
    </div>
  </h2>
  <div class="table-responsive" data-pattern="priority-columns">
    <table class="table table-striped table-bordered dataTable" id="xin_table">
      <thead>
        <tr>
          <th><?php echo $this->lang->line('xin_action');?></th>
          <th><?php echo $this->lang->line('xin_employees_full_name');?></th>
          <th><?php echo $this->lang->line('dashboard_email');?></th>
          <th>Permission</th>
          <th><?php echo $this->lang->line('xin_designation');?></th>
          <th><?php echo $this->lang->line('dashboard_xin_status');?></th>
        </tr>
      </thead>
    </table>
  </div>
</div>