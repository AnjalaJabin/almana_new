<?php
$session = $this->session->userdata('username');
$role_resources_ids = $this->Xin_model->user_role_resource();
if($quote_data[0]->added_by==$session['user_id'] || in_array('99',$role_resources_ids)){
}
else{
    header('location:'.site_url('dashboard'));
    exit();
}
$crm_settings = $this->Xin_model->read_setting_info(1);
?>

<style>
    .item_table_head{background: #323a44; color: #fff;}
    .table-main-estimate-edit .main{background:#fbfdff;}
</style>

<form class="m-b-1 add" method="post" name="add_product" id="xin-form">

<!--
<form class="m-b-1 add" method="post" name="add_product" id="xxin-form" action="<?php echo site_url('purchase_order/save_purchase_order'); ?>">
<input type="hidden" name="add_type" value="add_purchase_order"/>
-->

<input type="hidden" name="quote_id" id="quote_id" value="<?php echo $quote_data[0]->id; ?>"/>

<div class="box box-block bg-white">
    <div class="row">
        
      <div class="col-md-12">
            
              <div class="row">
                  
                <div class="col-sm-6">
                  
                  <div class="col-sm-6">
                      
                    <button class="m-b-0-0 waves-effect waves-light btn btn-sm btn-primary pull-right add_new_supplier_button" type="button" data-toggle="modal" data-target=".add-modal-data"><i class="fa fa-plus icon"></i> Add New</button>
                      
                      <div class="form-group" id="group_ajax">
                        <label for="name">Supplier</label>
                          <select class="form-control quote_supplier" name="supplier" data-plugin="select_hrm" data-placeholder="Select Supplier">
                            <option value=""><?php echo $this->lang->line('xin_select_one');?></option>
                            <?php foreach($all_suppliers as $ctype) {?>
                            <option value="<?php echo $ctype->id;?>" <?php if($quote_data[0]->supplier_id==$ctype->id){ echo 'selected'; } ?> > <?php echo $ctype->name;?></option>
                            <?php } ?>
                          </select>
                      </div>
                  </div>
                  
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label for="name">Email</label>
                            <input class="form-control supplier_email" name="supplier_email" type="text" value="<?php echo $quote_data[0]->email; ?>"/>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="col-sm-6">
                                <label class="checkbox-inline"><input type="checkbox" <?php if(!empty($quote_data[0]->shipping_address)){ echo 'checked'; } ?> class="shipping_address_check" name="add_shipping_address" value="1"> Add Shipping Address</label>
                            </div>
                            
                            <div class="col-sm-6 shipping_address_div" <?php if(empty($quote_data[0]->shipping_address)){ echo 'style="display:none;"'; } ?>>
                                <label for="name">Shipping Address</label>
                                <textarea rows="4" class="form-control" id="shipping_address_input" name="shipping_address" placeholder="Shipping Address"><?php echo $quote_data[0]->shipping_address; ?></textarea>
                            </div>
                        </div>
                    </div>
                  
                    <div class="col-sm-6">
                        <div class="form-group">
                           <label for="number"> <small class="req text-danger">* </small>Order Number</label>
                           <div class="input-group">
                              <input type="text" name="quote_number" class="form-control" value="<?php echo $crm_settings[0]->purchase_order_prefix.'-'.$invoice_number; ?>">
                           </div>
                        </div>
                        
                    </div>
                    <div class="col-sm-6">
                        
                        <div class="form-group">
                            <label for="reference_no" class="control-label">Reference #</label>
                            <input type="text" name="reference_no" class="form-control" value="<?php echo $quote_data[0]->reference; ?>">
                        </div>
                    
                    </div>
                    
                    <div class="col-sm-6">
                        <label class="checkbox-inline"><input type="checkbox" name="add_company_seal" value="1" <?php if($quote_data[0]->add_company_seal=='1'){ echo 'checked'; } ?>> Add Company Seal</label>
                    </div>
                    
                    <div class="col-sm-6">
                        <label class="checkbox-inline"><input type="checkbox" name="add_personal_sign" value="1" <?php if($quote_data[0]->add_personal_sign=='1'){ echo 'checked'; } ?>> Add Personal Sign</label>
                    </div>
                    
                </div>
                
                <div class="col-sm-6">
                    <div class="col-sm-12">
                        
                        <div class="col-sm-6">
                          <div class="form-group">
                            <label for="name">Currency</label>
                              <select class="form-control currency_symbol calculate_function" name="currency" data-placeholder="Discount Type">
                                  <?php foreach($this->Xin_model->get_currencies() as $currency){?>
                                  <?php $_currency = $currency->code.' - '.$currency->symbol;?>
                                  <option value="<?php echo $currency->symbol;?>" <?php if($default_currency_symbol==$currency->symbol):?> selected <?php endif;?>> <?php echo $_currency;?></option>
                                  <?php } ?>
                              </select>
                          </div>
                        </div>
                        
                        <div class="col-sm-6">
                          <div class="form-group">
                            <label for="name">Discount Type</label>
                              <select class="form-control calculate_function tax_calc_type" name="discount_type" data-placeholder="Discount Type">
                                <option <?php if($quote_data[0]->discount_type=='before_tax'){ echo 'selected'; } ?> value="before_tax">Before Tax</option>
                                <option <?php if($quote_data[0]->discount_type=='after_tax'){ echo 'selected'; } ?> value="after_tax">After Tax</option>
                              </select>
                          </div>
                        </div>
                        
                    </div>
                    
                    <div class="col-sm-12">
                        <div class="col-sm-6">
                            <div class="row">
                                <div class="col-sm-6">
                                    <label class="checkbox-inline"><input type="checkbox" name="taxcheck" value="1" class="taxcheck calculate_function" <?php if($quote_data[0]->tax_included=='1'){ echo 'checked'; } ?>> Tax Included</label>
                                </div>
                                <div class="col-sm-6">
                                  <div class="input-group">
                                    <input id="msg" type="number" class="form-control calculate_function taxvalue" name="taxvalue" placeholder="Tax %" value="<?php echo $quote_data[0]->tax_percentage; ?>">
                                    <span class="input-group-addon">%</span>
                                  </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            
                        </div>
                        
                    </div>
                    
                    <div class="col-sm-12">
                        
                        <div class="col-md-6">
                          <div class="form-group" app-field-wrapper="date"><label for="date" class="control-label"> <small class="req text-danger">* </small>Date</label>
                            <div class="input-group xdate">
                                <input type="text" name="quote_date" class="form-control datepicker" value="<?php echo date("d-m-Y"); ?>" aria-invalid="false">
                                <div class="input-group-addon">
                                  <i class="fa fa-calendar calendar-icon"></i>
                                </div>
                            </div>
                          </div>               
                        </div>
                        
                        <!--
                        <div class="col-md-6">
                          <div class="form-group" app-field-wrapper="expirydate"><label for="expirydate" class="control-label">Expiry Date</label>
                            <div class="input-group xdate">
                              <input type="text" name="expirydate" class="form-control datepicker" value="<?php echo date("d-m-Y", strtotime("+1 week", time())); ?>">
                              <div class="input-group-addon">
                                 <i class="fa fa-calendar calendar-icon"></i>
                              </div>
                            </div>
                          </div>    
                        </div>
                        -->
                        
                    </div>
                    
                </div>
                
              </div>
                
      </div>
    </div>
</div>

<div class="box box-block bg-white">
    
    <div class="col-sm-12">
      <div class="form-group">
          <textarea class="form-control summernote" name="quote_before"><?php echo $quote_data[0]->pre_item_contents; ?></textarea>
      </div>
    </div>
    
    <div class="col-sm-4">
        <div class="form-group">
            <label for="name">Select Product</label>
            <button type="button" class="btn btn-sm btn-info pull-right add_new_product_button" data-toggle="modal" data-target=".add-modal-data"><i class="fa fa-plus icon"></i> Add New Product</button>
              <select class="form-control product_list" data-plugin="select_hrm" data-placeholder="Select Product" id="product_select_option">
                  <option>Loading...</option>
              </select>
        </div>
    </div>

    <div class="table-responsive s_table mtop10">
      <table class="table estimate-items-table items table-main-estimate-edit">
       <thead>
       <tr class="item_table_head">
         <th></th>
         <th width="25%" class="text-left"><i class="fa fa-exclamation-circle" aria-hidden="true" data-toggle="tooltip" data-title="New lines are not supported for item description. Use the item long description instead."></i> Item</th>
         <th width="25%" class="text-left">Description</th>
         <th width="10%" class="text-left qty">Qty</th>
         <th width="20%" class="text-left">Rate</th>
         <th width="20%" class="text-left">Amount</th>
         <th><i class="fa fa-cog"></i></th>
       </tr>
       </thead>
       <tbody class="ui-sortable">
        <tr class="main">
           <td></td>
           <td>
            <textarea rows="4" class="form-control" id="item_description" placeholder="Description"></textarea>
          </td>
          <td>
            <textarea rows="4" class="form-control" id="item_long_description" placeholder="Long description"></textarea>
          </td>
          <td>
            <input type="number" min="0" value="1" class="form-control" id="item_qty" placeholder="Quantity">
            <input type="text" placeholder="Unit" id="item_unit" value="Unit" tabindex="-1" class="form-control input-transparent text-right">
          </td>
          <td>
            <input type="number" id="item_rate" class="form-control" placeholder="Rate" step="0.01">
          </td>
          
          <td></td>
          <td>
                <button type="button" onclick="add_item_to_table(); return false;" class="btn pull-right btn-info"><i class="fa fa-check"></i> Add</button>
          </td>
        </tr>
        
        <?php
        foreach($quote_items as $item){
            echo '<tr class="table_tr_items"><td></td><td><textarea name="description[]" rows="4" class="form-control" placeholder="Description">'.$item->item_name.'</textarea></td><td><textarea name="long_description[]" rows="4" class="form-control" placeholder="Long description">'.$item->description.'</textarea></td><td><input type="number" name="quantity[]" min="0" value="'.$item->qty.'" class="form-control item_qty calculate_function" placeholder="Quantity"><input type="text" placeholder="Unit" value="'.$item->unit.'" name="unit[]" class="form-control input-transparent text-right"></td><td><input type="number" name="rate[]" value="'.$item->rate.'" class="form-control item_rate calculate_function" placeholder="Rate" step="0.01"></td><td class="item_total_price"></td><td><button type="button" class="btn pull-right btn-danger remove_item"><i class="fa fa-trash"></i></button></td></tr>';
        }
        ?>
        
      </tbody>
     </table>
    </div>
    
    <div class="row">
        <div class="col-md-8 col-md-offset-4 pull-right">
         <table class="table text-right">
            <tbody>
               <tr id="subtotal">
                  <td><span class="bold">Sub Total :</span>
                  </td>
                  <td class="subtotal">0.00<input type="hidden" name="subtotal" id="subtotal" value="0.00"></td>
               </tr>
               <tr id="discount_percent">
                  <td>
                     <div class="row">
                        <div class="col-md-7">
                           <span class="bold">Discount (%)</span>
                        </div>
                        <div class="col-md-5">
                            <input type="number" value="<?php echo $quote_data[0]->discount_percentage; ?>" class="form-control pull-left calculate_function discount_percent" min="0" max="100" name="discount_percent" aria-invalid="false">
                        </div>
                     </div>
                  </td>
                  <td><span class="discount_percent">-0.00</span><input type="hidden" class="hdd_discount_percent" name="discount_total" value="0"></td>
               </tr>
               <tr id="taxrow">
                  <td><span class="bold">Tax :</span>
                  </td>
                  <td><span class="total_tax">0.00</span><input type="hidden" name="total_tax" id="total_tax" value="0.00"></td>
               </tr>
               <tr>
                  <td>
                     <div class="row">
                        <div class="col-md-7">
                           <span class="bold">Adjustment</span>
                        </div>
                        <div class="col-md-5">
                           <input type="number" data-toggle="tooltip" data-title="The rate in the input field is not formatted while edit/add item and should remain not formatted do not try to format it manually in here." value="<?php echo $quote_data[0]->adjustment; ?>" class="form-control pull-left calculate_function adjustment" name="adjustment" data-original-title="" title="">
                        </div>
                     </div>
                  </td>
                  <td><span class="adjustment_val">0.00</span></td>
               </tr>
               <tr>
                  <td><span class="bold">Total :</span>
                  </td>
                  <td><span class="gtotal">0.00</span><input type="hidden"  class="hdd_total" name="total" value="0.00"></td>
               </tr>
            </tbody>
         </table>
      </div>
      
        <div class="col-sm-12">
          <div class="form-group">
              <label for="name">Additional Contents</label>
              <textarea class="form-control summernote" name="quote_after" id="quote_after"><?php echo $quote_data[0]->after_item_contents; ?></textarea>
          </div>
        </div>
        
        <div class="col-sm-12">
            <a href="<?php echo site_url('purchase_order/view/'.$quote_data[0]->id); ?>" class="btn btn-lg pull-right btn-default"><i class="fa fa-close"></i> Cancel</a>
            <button type="submit" class="btn btn-lg pull-right btn-info"><i class="fa fa-check"></i> Save as Draft</button>
        </div>
      
    </div>
</div>

</form>

