<div class="box box-block bg-white">
  <h2><strong><?php echo $this->lang->line('xin_list_all');?></strong> Purchase Orders</h2>
  <div class="table-responsive" data-pattern="priority-columns">
    <table class="table table-striped table-bordered dataTable" id="xin_table" style="width:100%;">
      <thead>
        <tr>
          <th>Quote #</th>
          <th>Amount</th>
          <th>Total Tax</th>
          <th>Supplier</th>
          <th>Date</th>
          <th>Valid Until</th>
          <th>Reference #</th>
          <th>Added By</th>
          <th>Status</th>
        </tr>
      </thead>
    </table>
  </div>
</div>