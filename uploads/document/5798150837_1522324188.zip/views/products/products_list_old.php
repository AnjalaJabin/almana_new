
<?php $session = $this->session->userdata('username');?>
<div class="add-form" style="display:none;" >
  <div class="box box-block bg-white">
    <h2><strong><?php echo $this->lang->line('xin_add_new');?></strong> Product
      <div class="add-record-btn">
        <button class="btn btn-sm btn-primary add-new-form"><i class="fa fa-minus icon"></i> <?php echo $this->lang->line('xin_hide');?></button>
      </div>
    </h2>
    <div class="row m-b-1">
      <div class="col-md-12">
        <form class="m-b-1 add" method="post" name="add_product" id="xin-form">
          <input type="hidden" name="user_id" value="<?php echo $session['user_id'];?>">
          <div class="bg-white">
            <div class="box-block">
              <div class="row">
                <div class="col-sm-6">
                  <div class="form-group">
                    <label for="name">Product Name</label>
                    <input class="form-control" placeholder="Product Name" name="product_name" type="text">
                  </div>
                  
                  <div class="form-group">
                    <label for="name">Brand Name</label>
                    <input class="form-control" placeholder="Brand Name" name="brand_name" type="text">
                  </div>
                  
                  <div class="form-group">
                    <label for="name">Model Number</label>
                    <input class="form-control" placeholder="Model Number" name="model_number" type="text">
                  </div>
                  
                  <div class="form-group" id="group_ajax">
                    <label for="name">Product Category</label>
                      <select class="form-control" name="product_cat" data-plugin="select_hrm" data-placeholder="Select Product Category">
                        <option value=""><?php echo $this->lang->line('xin_select_one');?></option>
                        <?php foreach($product_cats as $ctype) {?>
                        <option value="<?php echo $ctype->id;?>"> <?php echo $ctype->name;?></option>
                        <?php } ?>
                      </select>
                  </div>
                    <a class="btn btn-sm btn-primary pull-right text-white" id="group_add_btn"><i class="fa fa-plus icon"></i>New Category</a>
                    <div style="background:#ddd; padding:7px; display:none;" id="group_add_div">
                        <div class="input-group">
                           <input type="text" class="form-control" placeholder="Category Name" id="group_add_val">
                           <span class="input-group-btn">
                                <button class="btn btn-success" type="button" id="group_sub_btn">Add</button>
                           </span>
                           <span class="input-group-btn">
                                <button class="btn" type="button" id="group_close_btn">X</button>
                           </span>
                        </div>
                    </div>
                </div>
                
                <div class="col-sm-6">
                  <div class="form-group">
                    <label for="phone">Description</label>
                   	 <textarea class="form-control textarea" id="description" name="description"></textarea>
                  </div>
                  
                  <div class="text-right">
                    <button type="submit" class="btn btn-primary save"><?php echo $this->lang->line('xin_save');?> <i class="icon-circle-right2 position-right"></i> <i class="icon-spinner3 spinner position-left"></i></button>
                  </div>
                  
                </div>
              </div>
              
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<div class="box box-block bg-white">
  <h2><strong><?php echo $this->lang->line('xin_list_all');?></strong> Products
    <div class="add-record-btn">
      <button class="btn btn-sm btn-primary add-new-form"><i class="fa fa-plus icon"></i> <?php echo $this->lang->line('xin_add_new');?></button>
    </div>
  </h2>
  <div class="table-responsive" data-pattern="priority-columns">
    <table class="table table-striped table-bordered dataTable" id="xin_table" style="width:100%;">
      <thead>
        <tr>
          <th><?php echo $this->lang->line('xin_action');?></th>
          <th>Product Name</th>
          <th>Brand</th>
          <th>Model Number</th>
          <th>Category</th>
          <th>Updated By</th>
          <th>Added By</th>
        </tr>
      </thead>
    </table>
    <a href="<?php echo site_url('products/export_products'); ?>" class="btn btn-sm btn-warning"><i class="fa fa-download icon"></i> Export to CSV</a>
  </div>
</div>
