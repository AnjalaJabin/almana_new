<option value="">Select Product</option>
<?php foreach($all_products->result() as $product){?>
<option value="<?php echo $product->id;?>"> <?php echo $product->name;?></option>
<?php } ?>