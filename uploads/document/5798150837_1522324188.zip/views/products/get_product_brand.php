<?php 
$result  = $this->Xin_model->get_all_product_brand();
?>
    <label for="name">Brand</label>
      <select class="form-control" name="brand_name" data-plugin="select_hrm" data-placeholder="Select Brand">
        <option value=""><?php echo $this->lang->line('xin_select_one');?></option>
        <?php foreach($result as $ctype) {?>
        <option value="<?php echo $ctype->id;?>"> <?php echo $ctype->name;?></option>
        <?php } ?>
      </select>

<script>
$('[data-plugin="select_hrm"]').select2($(this).attr('data-options'));
$('[data-plugin="select_hrm"]').select2({ width:'100%' }); 
</script>