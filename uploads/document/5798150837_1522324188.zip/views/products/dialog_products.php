<?php
defined('BASEPATH') OR exit('No direct script access allowed');
if(isset($_GET['jd']) && isset($_GET['product_id']) && $_GET['data']=='products'){
?>

<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">×</span> </button>
  <h4 class="modal-title" id="edit-modal-data"> Edit Product</h4>
</div>
<form class="m-b-1" action="<?php echo site_url("products/update").'/'.$product_id; ?>" method="post" name="edit_bank" id="edit_product">
  <input type="hidden" name="_method" value="EDIT">
  <input type="hidden" name="_token" value="<?php echo $product_id;?>">
  <input type="hidden" name="ext_name" value="<?php echo $name;?>">
  <div class="modal-body">
    <div class="row">
      <div class="col-sm-6">
        <div class="form-group">
          <label for="name">Product Name</label>
          <input class="form-control" placeholder="Product Name" name="product_name" type="text" value="<?php echo $name;?>">
        </div>
        
          <div class="form-group">
            <label for="name">Brand Name</label>
              <select class="form-control" name="brand_name" data-plugin="select_hrm" data-placeholder="Select Brand">
                <option value=""><?php echo $this->lang->line('xin_select_one');?></option>
                <?php foreach($product_brand as $ctype) {?>
                <option <?php if($brand_name==$ctype->id){ echo 'selected'; } ?> value="<?php echo $ctype->id;?>"> <?php echo $ctype->name;?></option>
                <?php } ?>
              </select>
          </div>
          
          <div class="form-group">
            <label for="name">Model Number</label>
            <input class="form-control" placeholder="Model Number" name="model_number" type="text" value="<?php echo $model_number;?>">
          </div>
          
          <div class="form-group" id="group_ajax">
            <label for="name">Product Category</label>
              <select class="form-control" name="product_cat" data-plugin="select_hrm" data-placeholder="Select Product Category">
                <option value=""><?php echo $this->lang->line('xin_select_one');?></option>
                <?php foreach($product_cats as $ctype) {?>
                <option <?php if($category_id==$ctype->id){ echo 'selected'; } ?> value="<?php echo $ctype->id;?>"> <?php echo $ctype->name;?></option>
                <?php } ?>
              </select>
          </div>
        
      </div>
      
      <div class="col-sm-6">
        <div class="form-group">
            <label for="phone">Description</label>
           	<textarea class="form-control textarea" id="description2" name="description"><?php echo $des; ?></textarea>
        </div>
      </div>
      
    </div>
  </div>
  <div class="modal-footer">
    <button type="button" class="btn btn-link" data-dismiss="modal"><?php echo $this->lang->line('xin_close');?></button>
    <button type="submit" class="btn btn-primary save"><?php echo $this->lang->line('xin_update');?></button>
  </div>
</form>

<script type="text/javascript">
    $('#description2').summernote({
      height: 206,
      minHeight: null,
      maxHeight: null,
      focus: false
    });
    
    function load_products_table(){
        
        $('#xin_table').DataTable( {
            "bDestroy": true,
			"processing": true,
			"serverSide": true,
			"ajax":{
				url :"<?php echo site_url("products/products_grid_data") ?>", // json datasource
				type: "post",  // method  , by default get
				error: function(){  // error handling
					$(".employee-grid-error").html("");
					console.log(error);
					$("#pxin_table").append('<tbody class="employee-grid-error"><tr><th colspan="3">No data found in the server</th></tr></tbody>');
					$("#employee-grid_processing").css("display","none");
					
				}
			}
		} );
	
    }
    
 $(document).ready(function(){
					
		// On page load: datatable
		var xxin_table = $('#xxin_table').dataTable({
			"bDestroy": true,
			"ajax": {
				url : "<?php echo site_url("products/products_list") ?>",
				type : 'GET'
			},
			"fnDrawCallback": function(settings){
			$('[data-toggle="tooltip"]').tooltip();          
			}
    	});
    	
    	var xin_table = $('#xin_table').DataTable( {
    	    "bDestroy": true,
			"processing": true,
			"serverSide": true,
			"ajax":{
				url : "<?php echo site_url("products/products_grid_data") ?>",
				type: "post",  // method  , by default get
				error: function(){  // error handling
					$(".employee-grid-error").html("");
					console.log(error);
					$("#xin_table").append('<tbody class="employee-grid-error"><tr><th colspan="3">No data found in the server</th></tr></tbody>');
					$("#employee-grid_processing").css("display","none");
					
				}
			}
		} );
		
		$('[data-plugin="select_hrm"]').select2($(this).attr('data-options'));
		$('[data-plugin="select_hrm"]').select2({ width:'100%' });	 

		/* Edit data */
		$("#edit_product").submit(function(e){
		e.preventDefault();
			var obj = $(this), action = obj.attr('name');
			$('.save').prop('disabled', true);
			
			$.ajax({
				type: "POST",
				url: e.target.action,
				data: obj.serialize()+"&is_ajax=1&edit_type=products&form="+action,
				cache: false,
				success: function (JSON) {
					if (JSON.error != '') {
						toastr.error(JSON.error);
						$('.save').prop('disabled', false);
					} else {
						toastr.success(JSON.result);
						$('.edit-modal-data').modal('toggle');
						$('.save').prop('disabled', false);
						load_products_table();
					}
				}
			});
		});
	});	
  </script>
<?php } else if(isset($_GET['jd']) && isset($_GET['product_id']) && $_GET['data']=='view_product'){
?>
<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">×</span> </button>
  <h4 class="modal-title" id="edit-modal-data">View Product</h4>
</div>
<form class="m-b-1">
  <div class="modal-body">
    <div class="row">
      <div class="col-sm-6">
        <div class="form-group">
          <label for="name">Product Name</label>
          <h5><?php echo $name;?></h5>
        </div>
        
          <div class="form-group">
            <label for="name">Brand Name</label>
            <h5><?php echo $brand_name;?></h5>
          </div>
        
          <div class="form-group">
            <label for="name">Model Number</label>
            <h5><?php echo $model_number;?></h5>
          </div>
          
          <div class="form-group" id="group_ajax">
            <label for="name">Product Category</label>
            <h5><?php echo $this->Xin_model->get_product_cat_by_id($category_id);;?></h5>
          </div>
      </div>
      <div class="col-sm-6">
        <div class="form-group">
          <label for="email"><b>Description</b></label>
          <?php echo $des;?>
        </div>
      </div>
    </div>
  </div>
  <div class="modal-footer">
    <button type="button" class="btn btn-link" data-dismiss="modal"><?php echo $this->lang->line('xin_close');?></button>
  </div>
</form>
<?php }
?>
