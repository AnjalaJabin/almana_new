<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends MY_Controller {
	
	public function __construct()
     {
          parent::__construct();
          $this->load->library('session');
          $this->load->helper('form');
          $this->load->helper('url');
          $this->load->helper('html');
          $this->load->database();
          $this->load->library('form_validation');
          //load the models
          $this->load->model('Login_model');
		  $this->load->model('Designation_model');
		  $this->load->model('Employees_model');
		  $this->load->model('Xin_model');
		  $this->load->model('Package_model');
		  $this->load->model('Dashboard_model');
		  $this->load->model('Customers_model');
     }
	
	/*Function to set JSON output*/
	public function output($Return=array()){
		/*Set response header*/
		header("Access-Control-Allow-Origin: *");
		header("Content-Type: application/json; charset=UTF-8");
		/*Final JSON response*/
		exit(json_encode($Return));
	} 
	
	public function index()
	{
		$session = $this->session->userdata('username');
		if(!empty($session)){ 
			
		} else {
			redirect('');
		}
		// get user > added by
		$user = $this->Xin_model->read_user_info($session['user_id']);
		// get designation
		$_designation = $this->Designation_model->read_designation_information($user[0]->designation_id);
		$data = array(
			'title' => $this->Xin_model->site_title(),
			'breadcrumbs' => $this->lang->line('dashboard_title'),
			'path_url' => 'dashboard',
			'first_name' => $user[0]->first_name,
			'last_name' => $user[0]->last_name,
			'employee_id' => $user[0]->employee_id,
			'username' => $user[0]->username,
			'email' => $user[0]->email,
			'designation_name' => $_designation[0]->designation_name,
			'date_of_birth' => $user[0]->date_of_birth,
			'contact_no' => $user[0]->contact_no,
			'last_four_employees' => $this->Xin_model->last_four_employees()
			);
			$data['subview'] = $this->load->view('dashboard/index', $data, TRUE);
			$this->load->view('layout_main', $data); //page load
	}
	
	public function index2()
	{
		$session = $this->session->userdata('username');
		if(!empty($session)){ 
			
		} else {
			redirect('');
		}
		// get user > added by
		$user = $this->Xin_model->read_user_info($session['user_id']);
		// get designation
		$_designation = $this->Designation_model->read_designation_information($user[0]->designation_id);
		$data = array(
			'title' => $this->Xin_model->site_title(),
			'breadcrumbs' => $this->lang->line('dashboard_title'),
			'path_url' => 'dashboard',
			'first_name' => $user[0]->first_name,
			'last_name' => $user[0]->last_name,
			'employee_id' => $user[0]->employee_id,
			'username' => $user[0]->username,
			'email' => $user[0]->email,
			'designation_name' => $_designation[0]->designation_name,
			'date_of_birth' => $user[0]->date_of_birth,
			'contact_no' => $user[0]->contact_no,
			'last_four_employees' => $this->Xin_model->last_four_employees()
			);
			$data['subview'] = $this->load->view('dashboard/dashboard', $data, TRUE);
			$this->load->view('layout_main', $data); //page load
	}

	
	// get opened and closed tickets for chart
	public function tickets_data()
	{
		/* Define return | here result is used to return user data and error for error message */
		$Return = array('opened'=>'', 'closed'=>'');
		// open
		//$Return['opened'] = $this->Xin_model->all_open_tickets();
		// closed
		//$Return['closed'] = $this->Xin_model->all_closed_tickets();
		$this->output($Return);
		exit;
	}
	
	
	public function add_new_product_popup()
	{
		$data['title'] = $this->Xin_model->site_title();
		$data = array(
				'suppliers' => $this->Xin_model->get_all_suppliers(),
				'product_cats' => $this->Xin_model->get_all_product_cats(),
				'product_brand' => $this->Xin_model->get_all_product_brand()
				);
		$session = $this->session->userdata('username');
		if(!empty($session)){ 
			$this->load->view('dashboard/dialog_products', $data);
		} else {
			redirect('');
		}
	}
	
	
	// set new language
	public function set_language($language = "") {
        
        $language = ($language != "") ? $language : "english";
        $this->session->set_userdata('site_lang', $language);
        redirect($_SERVER['HTTP_REFERER']);
        
    }
    
    public function check_session(){
       $cookie_name = "username";

        if(!isset($_COOKIE[$cookie_name])) {
            echo 0;
        } else {
            $session_data = unserialize($_COOKIE[$cookie_name]);
            $session_data = array(
        	'user_id' => $session_data['user_id'],
        	'username' => $session_data['username'],
        	'email' => $session_data['email'],
        	'root_id' => $session_data['root_id'],
        	);
        	$this->session->set_userdata('username', $session_data);
            $_SESSION['user_id'] = $session_data['user_id'];
            $_SESSION['root_id'] = $session_data['root_id'];
            echo 1;
            $this->db->query("UPDATE `xin_employees` SET `online`=1,`last_online`='".time()."' WHERE `user_id`='".$_SESSION['user_id']."' and `root_id`='".$_SESSION['root_id']."'");
        }
        
        $log_out_time = time()-20;
        $this->db->query("UPDATE `xin_employees` SET `online`=0 WHERE `last_online`<'".$log_out_time."'");
    }
    
    public function update_show_all_data(){
        if($this->input->post('add_type')=='show_all') {
            $session = $this->session->userdata('username');
            $root_id = $_SESSION['root_id'];
            $value = $this->input->post('ins_val');
            $col_name = 'show_all_'.$this->input->post('ins_col');
            $query = $this->db->query("SELECT * FROM employee_settings where emp_id='".$session['user_id']."' and root_id='".$root_id."'");
    		$query->result();
    		if($query->num_rows()==1){
    		    $this->db->query("UPDATE `employee_settings` SET `".$col_name."`='".$value."' WHERE `emp_id`='".$session['user_id']."' and root_id='".$root_id."'");
    		}
    		else
    		{
    		    $this->db->query("INSERT INTO `employee_settings`(`root_id`, `emp_id`, `$col_name`) VALUES ('".$root_id."',".$session['user_id'].",'".$value."')");
    		}
        }
    }
    
    
}
