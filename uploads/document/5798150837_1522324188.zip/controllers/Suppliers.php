<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Suppliers extends MY_Controller {
	
	 public function __construct() {
        Parent::__construct();
		$this->load->library('session');
		$this->load->helper('form');
		$this->load->helper('url');
		$this->load->helper('html');
		$this->load->database();
		$this->load->library('form_validation');
		//load the model
		$this->load->model("Suppliers_model");
		$this->load->model("Xin_model");
	}
	
	/*Function to set JSON output*/
	public function output($Return=array()){
		/*Set response header*/
		header("Access-Control-Allow-Origin: *");
		header("Content-Type: application/json; charset=UTF-8");
		/*Final JSON response*/
		exit(json_encode($Return));
	}
	
	 public function index()
     {
        $session = $this->session->userdata('username');
		if(!empty($session)){ 
			
		} else {
			redirect('');
		}
		
		$data['title'] = $this->Xin_model->site_title();
		$data['all_banks'] = $this->Suppliers_model->get_suppliers();
		$data['breadcrumbs'] = 'Suppliers';
		$data['path_url'] = 'suppliers';
		$session = $this->session->userdata('username');
		$role_resources_ids = $this->Xin_model->user_role_resource();
		if(in_array('62',$role_resources_ids) || in_array('63',$role_resources_ids) || in_array('64',$role_resources_ids)) {
			if(!empty($session)){ 
			$data['subview'] = $this->load->view("suppliers/suppliers_list", $data, TRUE);
			$this->load->view('layout_main', $data); //page load
			} else {
				redirect('');
			}
		} else {
			redirect('dashboard/');
		}		  
     }
 
    public function suppliers_list()
     {

		$data['title'] = $this->Xin_model->site_title();
		$session = $this->session->userdata('username');
		if(!empty($session)){ 
			$this->load->view("suppliers/suppliers_list", $data);
		} else {
			redirect('');
		}
		// Datatables Variables
		$draw = intval($this->input->get("draw"));
		$start = intval($this->input->get("start"));
		$length = intval($this->input->get("length"));
		
		
		$bank = $this->Suppliers_model->get_suppliers();
		$role_resources_ids = $this->Xin_model->user_role_resource();
		
		$data = array();
          $session = $this->session->userdata('username');
          foreach($bank->result() as $r) {
			  // get user
			  $user = $this->Xin_model->read_company_user_info($r->added_by);
			  
			  $full_name = '--';
			  // user full name
			  if(!empty($user)){
			      $full_name = $user[0]->first_name.' '.$user[0]->last_name;
			  }
			  
			    $option_buttons = '<span data-toggle="tooltip" data-placement="top" title="View"><button type="button" class="btn btn-secondary btn-sm m-b-0-0 waves-effect waves-light" data-toggle="modal" data-target=".view-modal-data" data-supplier_id="'. $r->id . '"><i class="fa fa-eye"></i></button></span>';
        		if(in_array('63',$role_resources_ids) || $r->added_by==$session['user_id']) {
        		    $option_buttons .= '<span data-toggle="tooltip" data-placement="top" title="Edit"><button type="button" class="btn btn-secondary btn-sm m-b-0-0 waves-effect waves-light"  data-toggle="modal" data-target="#edit-modal-data"  data-supplier_id="'. $r->id . '"><i class="fa fa-pencil-square-o"></i></button></span></span>';
        		}
        		if(in_array('64',$role_resources_ids) || $r->added_by==$session['user_id']) {
        		    $option_buttons .= '<span data-toggle="tooltip" data-placement="top" title="Delete"><button type="button" class="btn btn-danger btn-sm m-b-0-0 waves-effect waves-light delete" data-toggle="modal" data-target=".delete-modal" data-record-id="'. $r->id . '"><i class="fa fa-trash-o"></i></button></span>';
        		}
			  

               $data[] = array(
			   		$option_buttons,
                    $r->name,
					$r->email,
                    $r->phone,
					$r->address,
					$r->trn,
					$full_name
               );
          }

          $output = array(
               "draw" => $draw,
                 "recordsTotal" => $bank->num_rows(),
                 "recordsFiltered" => $bank->num_rows(),
                 "data" => $data
            );
          echo json_encode($output);
          exit();
     }
	 
	 public function read()
	{
		$data['title'] = $this->Xin_model->site_title();
		$id = $this->input->get('supplier_id');
		$result = $this->Suppliers_model->read_supplier_information($id);
		$data = array(
				'supplier_id' => $result[0]->id,
				'name' => $result[0]->name,
				'email' => $result[0]->email,
				'phone' => $result[0]->phone,
				'address' => $result[0]->address,
				'trn' => $result[0]->trn,
				'des' => $result[0]->des
				);
		$session = $this->session->userdata('username');
		if(!empty($session)){ 
			$this->load->view('suppliers/dialog_suppliers', $data);
		} else {
			redirect('');
		}
	}
	
	// Validate and add info in database
	public function add_supplier() {
	
		if($this->input->post('add_type')=='suppliers') {
		
		/* Define return | here result is used to return user data and error for error message */
		$Return = array('result'=>'', 'error'=>'');
			
		/* Server side PHP input validation */
		if($this->input->post('supplier_name')==='') {
        	$Return['error'] = 'Supplier name field is required.';
		}
				
		if($Return['error']!=''){
       		$this->output($Return);
    	}
	    $session = $this->session->userdata('username');
		$data = array(
		'name' => $this->input->post('supplier_name'),
		'email' => $this->input->post('email'),
		'phone' => $this->input->post('phone'),
		'address' => $this->input->post('address'),
		'des' => $this->input->post('des'),
		'trn' => $this->input->post('trn'),
		'added_by' => $session['user_id'],
		'date' => date('Y-m-d H:i:s'),
		);
		$result = $this->Suppliers_model->add($data);
		if ($result == TRUE) {
			$Return['result'] = 'Supplier successfully added.';
		} else {
			$Return['error'] = $this->lang->line('xin_error_msg');
		}
		$this->output($Return);
		exit;
		}
	}
	
	public function add_supplier_name() {
	
		if($this->input->post('add_type')=='suppliers') {
		
		/* Define return | here result is used to return user data and error for error message */
		$Return = array('result'=>'', 'error'=>'');
		
		$query = $this->db->query("SELECT * FROM `suppliers` WHERE `name`='".$this->input->post('supplier_name')."' and `root_id`='".$_SESSION['root_id']."'");
			
		/* Server side PHP input validation */
		if($this->input->post('supplier_name')==='') {
        	$Return['error'] = 'Supplier name field is required.';
		}
		else if($query->num_rows()>=1)
		{
		    $Return['error'] = 'Supplier name already exists in database.';
		}
				
		if($Return['error']!=''){
       		$this->output($Return);
    	}
	    $session = $this->session->userdata('username');
		$data = array(
		'name' => $this->input->post('supplier_name'),
		'added_by' => $session['user_id'],
		'date' => date('Y-m-d H:i:s'),
		);
		$result = $this->Suppliers_model->add($data);
		if ($result == TRUE) {
			$Return['result'] = 'Supplier successfully added.';
		} else {
			$Return['error'] = $this->lang->line('xin_error_msg');
		}
		$this->output($Return);
		exit;
		}
	}
	
	// Validate and update info in database
	public function update() {
	
		if($this->input->post('edit_type')=='supplier') {
			
		$id = $this->uri->segment(3);
		
		/* Define return | here result is used to return user data and error for error message */
		$Return = array('result'=>'', 'error'=>'');
			
		/* Server side PHP input validation */
		if($this->input->post('supplier_name')==='') {
        	$Return['error'] = 'Supplier name field is required.';
		} else if($this->input->post('phone')==='') {
			$Return['error'] = 'Supplier phone field is required.';
		}
				
		if($Return['error']!=''){
       		$this->output($Return);
    	}
	
		$data = array(
		'name' => $this->input->post('supplier_name'),
		'email' => $this->input->post('email'),
		'phone' => $this->input->post('phone'),
		'address' => $this->input->post('address'),
		'des' => $this->input->post('des'),
		'trn' => $this->input->post('trn'),
		);	
		
		$result = $this->Suppliers_model->update_record($data,$id);		
		
		if ($result == TRUE) {
			$Return['result'] = 'Supplier updated.';
		} else {
			$Return['error'] = $this->lang->line('xin_error_msg');
		}
		$this->output($Return);
		exit;
		}
	}
	
	public function suppliers_select_list() {

		$data['title'] = $this->Xin_model->site_title();
		
		$user_id = $this->session->userdata('user_id');
		
		$data = array(
		    'all_suppliers' => $this->Xin_model->get_all_suppliers()
		    );
		$session = $this->session->userdata('username');
		if(!empty($session)){ 
			$this->load->view("suppliers/get_suppliers_select_list", $data);
		} else {
			redirect('');
		}
		// Datatables Variables
		$draw = intval($this->input->get("draw"));
		$start = intval($this->input->get("start"));
		$length = intval($this->input->get("length"));
	}
	
	public function add_new_supplier_popup(){
	    
		$data['title'] = $this->Xin_model->site_title();
		$data = array();
		$session = $this->session->userdata('username');
		if(!empty($session)){ 
			$this->load->view('suppliers/dialog_add_supplier', $data);
		} else {
			redirect('');
		}
	
	}
	
	public function delete() {
		/* Define return | here result is used to return user data and error for error message */
		$Return = array('result'=>'', 'error'=>'');
		$id = $this->uri->segment(3);
		
    		$result = $this->Suppliers_model->delete_record($id);
    		if(isset($id)) {
    			$Return['result'] = 'Supplier Deleted.';
    		} else {
    			$Return['error'] = $this->lang->line('xin_error_msg');
    		}
		$this->output($Return);
	}
}
