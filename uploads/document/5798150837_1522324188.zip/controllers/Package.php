<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Package extends MY_Controller {
	
	 public function __construct() {
        Parent::__construct();
		$this->load->library('session');
		$this->load->helper('form');
		$this->load->helper('url');
		$this->load->helper('html');
		$this->load->database();
		$this->load->library('form_validation');
		//load the model
		$this->load->model("Package_model");
		$this->load->model("Xin_model");
		$this->load->model("Employees_model");
	}
	
	/*Function to set JSON output*/
	public function output($Return=array()){
		/*Set response header*/
		header("Access-Control-Allow-Origin: *");
		header("Content-Type: application/json; charset=UTF-8");
		/*Final JSON response*/
		exit(json_encode($Return));
	}
	
	 public function index()
     {
        $session = $this->session->userdata('username');
		if(!empty($session)){ 
			
		} else {
			redirect('');
		}
		
		$data['title'] = $this->Xin_model->site_title();
		$data['all_packages'] = $this->Package_model->get_packages();
		$data['root_account'] = $this->Xin_model->get_root_account();
		$session = $this->session->userdata('username');
		$data['breadcrumbs'] = 'Packages';
		$data['path_url'] = 'package';
		$role_resources_ids = $this->Xin_model->user_role_resource();
		if(in_array('59',$role_resources_ids)) {
			if(!empty($session)){ 
			$data['subview'] = $this->load->view("package/package_list", $data, TRUE);
			$this->load->view('layout_main', $data); //page load
			} else {
				redirect('');
			}
		} else {
			redirect('dashboard/');
		}		  
     }
 
    public function package_list()
     {

		$data['title'] = $this->Xin_model->site_title();
		$session = $this->session->userdata('username');
		if(!empty($session)){ 
			$this->load->view("package/package_list", $data);
		} else {
			redirect('');
		}
		// Datatables Variables
		$draw = intval($this->input->get("draw"));
		$start = intval($this->input->get("start"));
		$length = intval($this->input->get("length"));
		
		
		$designation = $this->Package_model->get_packages();
		
		$data = array();

          foreach($designation->result() as $r) {
			  
			  // get user > added by
			  $user = $this->Xin_model->read_user_info($r->added_by);
			  // user full name
			  $full_name = $user[0]->first_name.' '.$user[0]->last_name;

               $data[] = array(
			   		'<span data-toggle="tooltip" data-placement="top" title="Edit"><button type="button" class="btn btn-secondary btn-sm m-b-0-0 waves-effect waves-light"  data-toggle="modal" data-target="#edit-modal-data"  data-designation_id="'. $r->designation_id . '"><i class="fa fa-pencil-square-o"></i></button></span><span data-toggle="tooltip" data-placement="top" title="Delete"><button type="button" class="btn btn-danger btn-sm m-b-0-0 waves-effect waves-light delete" data-toggle="modal" data-target=".delete-modal" data-record-id="'. $r->designation_id . '"><i class="fa fa-trash-o"></i></button></span>',
                    $r->designation_name,
                    $department[0]->department_name,
					$full_name
               );
          }

          $output = array(
               "draw" => $draw,
                 "recordsTotal" => $designation->num_rows(),
                 "recordsFiltered" => $designation->num_rows(),
                 "data" => $data
            );
          echo json_encode($output);
          exit();
     }
	
	// Validate and update info in database
	public function update() {
	
		if($this->input->post('edit_type')=='package') {
		$plan            = $this->input->post('plan');
		$total_employees = $this->Employees_model->get_total_employees();
		$root_account    = $this->Xin_model->get_root_account();
		$package_info    = $this->Package_model->read_package_information($plan);
		
		/* Define return | here result is used to return user data and error for error message */
		$Return = array('result'=>'', 'error'=>'');
		
		if($total_employees>$package_info[0]->employees) {
			$Return['error'] = "You can't downgrade this package because you already have ".$total_employees." employees";
		}
		else if($root_account[0]->package_id==$plan) {
			$Return['error'] = "You are using the same plan";
		}
		else
		{
	
    		$data = array(
    		'package_id' => $this->input->post('plan'),	
    		);
    		
    		$result = $this->Package_model->update_record($data);		
    		
    		if ($result == TRUE) {
    			$Return['result'] = 'Package Successfully Updated';
    		} else {
    			$Return['error'] = $this->lang->line('xin_error_msg');
    		}
		
		}
		
		$this->output($Return);
		exit;
		}
	}
	
}
