<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Delivery_note extends MY_Controller {
	
	 public function __construct() {
        Parent::__construct();
		$this->load->library('session');
		$this->load->helper('form');
		$this->load->helper('url');
		$this->load->helper('html');
		// load email library
		
		$this->load->database();
		$this->load->library('Pdf');
		//$this->load->library('email');
		$this->load->library('form_validation');
		//load the model
		$this->load->model("Xin_model");
		$this->load->model("Products_model");
		$this->load->model("Customers_model");
		$this->load->model("Delivery_note_model");
		
	}
	
	/*Function to set JSON output*/
	public function output($Return=array()){
		/*Set response header*/
		header("Access-Control-Allow-Origin: *");
		header("Content-Type: application/json; charset=UTF-8");
		/*Final JSON response*/
		exit(json_encode($Return));
	}
	
	public function index()
	{
	    $session = $this->session->userdata('username');
		if(!empty($session)){ 
			
		} else {
			redirect('');
		}
		
		$data['show_all_list'] = 0;
		$role_resources_ids = $this->Xin_model->user_role_resource();
        if(in_array('102',$role_resources_ids) || in_array('103',$role_resources_ids)) {
            $data['show_all_list'] = 1;
        }
        
        $data['show_all_check'] = 0;
        $show_all_permission = $this->Xin_model->get_data_list_permission($session['user_id'],'delivery_notes');
		if($show_all_permission>=1){
		    $data['show_all_check'] = 1;
		}
		
		$data['title'] = $this->Xin_model->site_title();
		$data['breadcrumbs'] = 'All Delivery Notes';
		$data['path_url'] = 'delivery_note';
		
		if(!empty($session)){ 
		    
		    $user = $this->Xin_model->read_user_info($session['user_id']);
    		$data['subview'] = $this->load->view("delivery_note/delivery_note_list", $data, TRUE);
    		
		   $this->load->view('layout_main', $data); //page load
		} else {
			redirect('');
		}
	}
	
	public function create_delivery_note()
    {
        $session = $this->session->userdata('username');
		if(!empty($session)){ 
			
		} else {
			redirect('');
		}
		
		$setting = $this->Xin_model->read_setting_info(1);
		$data['title'] = $this->Xin_model->site_title();
		$data['all_customers'] = $this->Xin_model->get_all_customers($session['user_id']);
		$data['invoice_number']  = $this->Delivery_note_model->get_new_invoice_number();
		$data['default_currency_symbol'] = $setting[0]->default_currency_symbol;
		$data['breadcrumbs'] = 'Create Delivery Note';
		$data['path_url'] = 'create_delivery_note';
		$session = $this->session->userdata('username');
		$role_resources_ids = $this->Xin_model->user_role_resource();
		
		if(!empty($session)){ 
		    
		    $user = $this->Xin_model->read_user_info($session['user_id']);
    		$data['subview'] = $this->load->view("delivery_note/create_delivery_note", $data, TRUE);
		
		$this->load->view('layout_main', $data); //page load
		} else {
			redirect('');
		}
    }
    
    public function copy()
    {
        $session = $this->session->userdata('username');
		if(!empty($session)){ 
			
		} else {
			redirect('');
		}
		
		$id = $this->uri->segment(3);
		
		$data['quote_data']  = $this->Delivery_note_model->read_invoice_information($id);
		$data['quote_items'] = $this->Delivery_note_model->get_invoice_items($id);
		$data['invoice_number']  = $this->Delivery_note_model->get_new_invoice_number();
		
		$setting = $this->Xin_model->read_setting_info(1);
		$data['title'] = $this->Xin_model->site_title();
		$data['all_customers'] = $this->Xin_model->get_all_customers($session['user_id']);
		$data['breadcrumbs'] = 'Copy Invoice';
		$data['path_url'] = 'create_delivery_note';
		$session = $this->session->userdata('username');
		$role_resources_ids = $this->Xin_model->user_role_resource();
		
		if(!empty($session)){ 
		$data['subview'] = $this->load->view("delivery_note/copy_delivery_note", $data, TRUE);
		$this->load->view('layout_main', $data); //page load
		} else {
			redirect('');
		}
    }
    
    public function edit()
    {
        $session = $this->session->userdata('username');
		if(!empty($session)){ 
			
		} else {
			redirect('');
		}
		
		$id = $this->uri->segment(3);
		
		$data['quote_data']  = $this->Delivery_note_model->read_invoice_information($id);
		$data['quote_items'] = $this->Delivery_note_model->get_invoice_items($id);
		
		$setting = $this->Xin_model->read_setting_info(1);
		$data['title'] = $this->Xin_model->site_title();
		$data['all_customers'] = $this->Xin_model->get_all_customers($session['user_id']);
		$data['breadcrumbs'] = 'Edit Invoice';
		$data['path_url'] = 'edit_delivery_note';
		$session = $this->session->userdata('username');
		$role_resources_ids = $this->Xin_model->user_role_resource();
		
		if(!empty($session)){ 
		$data['subview'] = $this->load->view("delivery_note/edit_delivery_note", $data, TRUE);
		$this->load->view('layout_main', $data); //page load
		} else {
			redirect('');
		}
    }
    
    public function convert()
    {
        $session = $this->session->userdata('username');
		if(!empty($session)){ 
			
		} else {
			redirect('');
		}
		
		$id = $this->uri->segment(3);
		
		$data['quote_data']  = $this->Xin_model->read_quote_information($id);
		$data['quote_items'] = $this->Xin_model->get_quote_items($id);
		$data['invoice_number']  = $this->Delivery_note_model->get_new_invoice_number();
		
		if(empty($data['quote_data'])){
		    exit();
		}
		
		$setting = $this->Xin_model->read_setting_info(1);
		$data['title'] = $this->Xin_model->site_title();
		$data['all_customers'] = $this->Xin_model->get_all_customers($session['user_id']);
		$data['quote_number']  = $this->Xin_model->get_new_quotation_number();
		$data['default_currency_symbol'] = $data['quote_data'][0]->currency;
		$data['breadcrumbs'] = 'Convert to Delivery Note';
		$data['path_url'] = 'create_delivery_note';
		$session = $this->session->userdata('username');
		$role_resources_ids = $this->Xin_model->user_role_resource();
		
		if(!empty($session)){ 
		$data['subview'] = $this->load->view("delivery_note/convert_to_delivery_note", $data, TRUE);
		$this->load->view('layout_main', $data); //page load
		} else {
			redirect('');
		}
    }
    
    public function view()
    {
        $session = $this->session->userdata('username');
		if(!empty($session)){ 
			
		} else {
			redirect('');
		}
		
		$id = $this->uri->segment(3);
		
		$data['quote_data']  = $this->Delivery_note_model->read_invoice_information($id);
		$data['quote_items'] = $this->Delivery_note_model->get_invoice_items($id);
		
		$setting = $this->Xin_model->read_setting_info(1);
		$data['title'] = $this->Xin_model->site_title();
		$data['all_customers'] = $this->Xin_model->get_all_customers($session['user_id']);
		$data['breadcrumbs'] = 'View Delivery Note';
		$data['path_url'] = 'view_invoice';
		$session = $this->session->userdata('username');
		$role_resources_ids = $this->Xin_model->user_role_resource();
		
		if(!empty($session)){ 
		$data['subview'] = $this->load->view("delivery_note/view_delivery_note", $data, TRUE);
		$this->load->view('layout_main', $data); //page load
		} else {
			redirect('');
		}
    }
     
     public function save_delivery_note(){
         
        $session = $this->session->userdata('username');
        $user = $this->Xin_model->read_user_info($session['user_id']);
		if($user[0]->pricing_company==0){
		    $root_id = $_SESSION['root_id'];
		    $company_query = $this->db->query("SELECT `company_id` FROM `xin_companies` WHERE `root_id`='".$root_id."' limit 1");
		    $company_result = $company_query->result();
		    $user_update = $this->db->query("UPDATE `xin_employees` SET `pricing_company`='".$company_result[0]->company_id."' WHERE `user_id`='".$session['user_id']."' AND `root_id`='".$root_id."'");
		}
         
        /*
            echo '<pre>';
            print_r($_POST);
            foreach($_POST['description'] as $key=>$item){
                echo '<br>'.trim($item);
            }
            
            exit();
        */
         
        if($this->input->post('add_type')=='add_delivery_note') {
            
    		$Return = array('result'=>'', 'error'=>'');
    			
    		
    		if($this->input->post('customer')==='') {
            	$Return['error'] = 'Please select customer.';
    		}
    		else if($this->input->post('customer_email')==='') {
            	$Return['error'] = 'Email field is required.';
    		}
    		else if($this->input->post('quote_number')==='') {
            	$Return['error'] = 'Invoice number field is required.';
    		}
    		else if($this->input->post('quote_date')==='') {
            	$Return['error'] = 'Invoice Date field is required.';
    		}
    		else if(!isset($_POST['description'][0])) {
            	$Return['error'] = 'Invoice item is required.';
    		}
    		else
    		{
        		foreach($_POST['description'] as $key=>$item){
        		    
                    if(empty($_POST['long_description'][$key])) {
                    	$Return['error'] = 'Item description is required.';
            		}
            		else if(empty($_POST['quantity'][$key])) {
                    	$Return['error'] = 'Item quantity is required.';
            		}
        		}
    		}
    				
    		if($Return['error']!=''){
           		$this->output($Return);
        	}
        	
        	$customer_data = $this->Customers_model->read_customer_information($this->input->post('customer'));
        	    if(empty($customer_data[0]->email)){
        	    $data_c = array(
        		'email' => $this->input->post('customer_email'),
        		);	
        		$result_cs = $this->Customers_model->update_record($data_c,$customer_data[0]->customer_id);
        	}
        	
        	$shipping_address = '';
        	if($this->input->post('add_shipping_address')==1){
        	    $shipping_address = $this->input->post('shipping_address');
        	}
            
            $session = $this->session->userdata('username');
    		$data = array(
    		'customer_id' => $this->input->post('customer'),
    		'email' => $this->input->post('customer_email'),
    		'delivery_note_number' => $this->input->post('quote_number'),
    		'reference' => $this->input->post('reference_no'),
    		'delivery_date' => date("Y-m-d", strtotime($this->input->post('quote_date')) ),
    		'after_item_contents' => $this->input->post('quote_after'),
    		'add_company_seal' => $this->input->post('add_company_seal'),
    		'add_personal_sign' => $this->input->post('add_personal_sign'),
    		'shipping_address' => $shipping_address,
    		'added_date' => date('Y-m-d H:i:s'),
    		'added_by' => $session['user_id'],
    		);
    		
    		if(isset($_POST['quote_id'])) {
    		    $data['quote_id'] = $this->input->post('quote_id');   
    		}
    		
    		$result = $this->Delivery_note_model->add_invoice($data);
    		$invoice_id = $insert_id = $this->db->insert_id();
    		
    		$Return['quote_id'] = $invoice_id;
    		
    		if ($result == TRUE) {
    		
        		foreach($_POST['description'] as $key=>$item){
                	
                	$data2 = array(
            		'delivery_note_id' => $invoice_id,
            		'item_name' => trim($item),
            		'description' => trim($_POST['long_description'][$key]),
            		'qty' => $_POST['quantity'][$key],
            		'unit' => $_POST['unit'][$key],
            		'date' => date('Y-m-d H:i:s'),
            		'added_by' => $session['user_id'],
            		);
            		$result2 = $this->Delivery_note_model->add_invoice_items($data2);
            		
                }
            
    		}
    		
    		if ($result == TRUE) {
    			$Return['result'] = 'Delivery Note successfully created.';
    		} else {
    			$Return['error'] = $this->lang->line('xin_error_msg');
    		}
    		
    		$this->output($Return);
    		exit;
        }
     }
     
      public function update_delivery_note(){
        /*
            echo '<pre>';
            print_r($_POST);
            foreach($_POST['description'] as $key=>$item){
                echo '<br>'.trim($item);
            }
            
            exit();
        */
         
        if($this->input->post('add_type')=='update_delivery_note') {
            
    		$Return = array('result'=>'', 'error'=>'');
    			
    		
    		if($this->input->post('customer')==='') {
            	$Return['error'] = 'Please select customer.';
    		}
    		else if($this->input->post('customer_email')==='') {
            	$Return['error'] = 'Email field is required.';
    		}
    		else if($this->input->post('quote_number')==='') {
            	$Return['error'] = 'Invoice number field is required.';
    		}
    		else if($this->input->post('quote_date')==='') {
            	$Return['error'] = 'Invoice Date field is required.';
    		}
    		else if(!isset($_POST['description'][0])) {
            	$Return['error'] = 'Invoice item is required.';
    		}
    		else
    		{
        		foreach($_POST['description'] as $key=>$item){
        		    
                    if(empty($_POST['long_description'][$key])) {
                    	$Return['error'] = 'Item description is required.';
            		}
            		else if(empty($_POST['quantity'][$key])) {
                    	$Return['error'] = 'Item quantity is required.';
            		}
        		}
    		}
    				
    		if($Return['error']!=''){
           		$this->output($Return);
        	}
        	
        	$quote_id = $this->input->post('quote_id');
        	
        	$shipping_address = '';
        	if($this->input->post('add_shipping_address')==1){
        	    $shipping_address = $this->input->post('shipping_address');
        	}
        	
        	$shipping_address = '';
        	if($this->input->post('add_shipping_address')==1){
        	    $shipping_address = $this->input->post('shipping_address');
        	}
            
            $session = $this->session->userdata('username');
    		$data = array(
    		'customer_id' => $this->input->post('customer'),
    		'email' => $this->input->post('customer_email'),
    		'delivery_note_number' => $this->input->post('quote_number'),
    		'reference' => $this->input->post('reference_no'),
    		'delivery_date' => date("Y-m-d", strtotime($this->input->post('quote_date')) ),
    		'after_item_contents' => $this->input->post('quote_after'),
    		'add_company_seal' => $this->input->post('add_company_seal'),
    		'add_personal_sign' => $this->input->post('add_personal_sign'),
    		'shipping_address' => $shipping_address,
    		'updated_date' => date('Y-m-d H:i:s'),
    		);
    		
    		$result = $this->Delivery_note_model->update_invoice($data,$quote_id);
    		//echo $this->db->last_query();
    		
    		$delete_result = $this->Delivery_note_model->delete_invoice_items($quote_id);
    		
    		if ($delete_result == TRUE && $result == TRUE) {
    		
        		foreach($_POST['description'] as $key=>$item){
                	
                	$data2 = array(
            		'delivery_note_id' => $quote_id,
            		'item_name' => trim($item),
            		'description' => trim($_POST['long_description'][$key]),
            		'qty' => $_POST['quantity'][$key],
            		'unit' => $_POST['unit'][$key],
            		'date' => date('Y-m-d H:i:s'),
            		'added_by' => $session['user_id'],
            		);
            		$result2 = $this->Delivery_note_model->add_invoice_items($data2);
            		
                }
            
    		}
    		
    		if ($result == TRUE) {
    			$Return['result'] = 'Invoice successfully Updated.';
    		} else {
    			$Return['error'] = $this->lang->line('xin_error_msg');
    		}
    		
    		$this->output($Return);
    		exit;
        }
     }
     
     public function delivery_note_list()
     {

		$data['title'] = $this->Xin_model->site_title();
		$session = $this->session->userdata('username');
		if(!empty($session)){ 
			$this->load->view("delivery_note/delivery_note_list", $data);
		} else {
			redirect('');
		}
		// Datatables Variables
		$draw = intval($this->input->get("draw"));
		$start = intval($this->input->get("start"));
		$length = intval($this->input->get("length"));
		
		$quotation = $this->Delivery_note_model->get_all_invoices($session['user_id']);
		$crm_settings = $this->Xin_model->read_setting_info(1);
		
		$data = array();

          foreach($quotation->result() as $r) {
               $customer_data = $this->Customers_model->read_customer_information($r->customer_id);
               
               if(!empty($customer_data))
               {
                   $customer_name = $customer_data[0]->company_name;
               }
               else
               {
                   $customer_name = '--';
               }
                    
                    $edit_url = site_url('delivery_note/view/'.$r->id);
                    
                    $status = '<a href="'.$edit_url.'" class="btn btn-sm btn-primary">Draft</a>';
                    
                    if($r->status=='sent')
                    {
                        $status = '<a href="'.$edit_url.'" class="btn btn-sm btn-success">Sent</a>';
                    }
               
               $data[] = array(
			   		'<a href="'.$edit_url.'">'.$r->delivery_note_number.'</a>',
			   		'<a href="'.$edit_url.'">'.$customer_name.'</a>',
                    date("d-m-Y", strtotime($r->delivery_date)),
                    $r->reference,
                    $status
               );
          }

          $output = array(
               "draw" => $draw,
                 "recordsTotal" => $quotation->num_rows(),
                 "recordsFiltered" => $quotation->num_rows(),
                 "data" => $data
            );
          echo json_encode($output);
          exit();
     }
     
     
     
    private function convertNumberToWord($num = false)
    {
        $num = str_replace(array(',', ' '), '' , trim($num));
        if(! $num) {
            return false;
        }
        $num = (int) $num;
        $words = array();
        $list1 = array('', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten', 'eleven',
            'twelve', 'thirteen', 'fourteen', 'fifteen', 'sixteen', 'seventeen', 'eighteen', 'nineteen'
        );
        $list2 = array('', 'ten', 'twenty', 'thirty', 'forty', 'fifty', 'sixty', 'seventy', 'eighty', 'ninety', 'hundred');
        $list3 = array('', 'thousand', 'million', 'billion', 'trillion', 'quadrillion', 'quintillion', 'sextillion', 'septillion',
            'octillion', 'nonillion', 'decillion', 'undecillion', 'duodecillion', 'tredecillion', 'quattuordecillion',
            'quindecillion', 'sexdecillion', 'septendecillion', 'octodecillion', 'novemdecillion', 'vigintillion'
        );
        $num_length = strlen($num);
        $levels = (int) (($num_length + 2) / 3);
        $max_length = $levels * 3;
        $num = substr('00' . $num, -$max_length);
        $num_levels = str_split($num, 3);
        for ($i = 0; $i < count($num_levels); $i++) {
            $levels--;
            $hundreds = (int) ($num_levels[$i] / 100);
            $hundreds = ($hundreds ? ' ' . $list1[$hundreds] . ' hundred' . ' ' : '');
            $tens = (int) ($num_levels[$i] % 100);
            $singles = '';
            if ( $tens < 20 ) {
                $tens = ($tens ? ' ' . $list1[$tens] . ' ' : '' );
            } else {
                $tens = (int)($tens / 10);
                $tens = ' ' . $list2[$tens] . ' ';
                $singles = (int) ($num_levels[$i] % 10);
                $singles = ' ' . $list1[$singles] . ' ';
            }
            $words[] = $hundreds . $tens . $singles . ( ( $levels && ( int ) ( $num_levels[$i] ) ) ? ' ' . $list3[$levels] . ' ' : '' );
        } //end for loop
        $commas = count($words);
        if ($commas > 1) {
            $commas = $commas - 1;
        }
        return implode(' ', $words);
    }
     
     
	 
	 public function print_delivery_note($save_quotation_id=null,$save_quotation=false)
	 {
		$system = $this->Xin_model->read_setting_info(1);
		$crm_settings = $this->Xin_model->read_setting_info(1);
		
		 // create new PDF document
   		$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
   		
   		$pdf->setPrintHeader(false);
        $pdf->setPrintFooter(false);
		
		if(!empty($save_quotation_id)){
		    $id = $save_quotation_id;
		}
		else
		{
		    $id = $this->uri->segment(3);
		}
		
		$quote_data    = $this->Delivery_note_model->read_invoice_information($id);
		
		if(empty($quote_data)){
		    exit();
		}
		
		$quote_items   = $this->Delivery_note_model->get_invoice_items($id);
		$customer_data = $this->Customers_model->read_customer_information($quote_data[0]->customer_id);
		
		$session = $this->session->userdata('username');
		$user = $this->Xin_model->read_user_info($session['user_id']);
		
		$quote_user = $this->Xin_model->read_user_info($quote_data[0]->added_by);
		
		if($quote_data[0]->root_id!=$_SESSION['root_id']){
		    exit();
		}
		
		$company = $this->Xin_model->read_company_info($quote_user[0]->pricing_company);

		//$pdf = new Pdf('P', 'mm', 'A4', true, 'UTF-8', false);
		$company_name = $company[0]->name;
		// set default header data
		$c_info_email = $company[0]->email;
		$c_info_phone = $company[0]->contact_number;
		$country = $this->Xin_model->read_country_info($company[0]->country);
		
		$c_info_address = '';
		
		if(!empty($company[0]->address_1)){
		    $c_info_address.= $company[0]->address_1.'<br>';
		}
		if(!empty($company[0]->address_2)){
		    $c_info_address.= $company[0]->address_2.'<br>';
		}
		if(!empty($company[0]->city)){
		    $c_info_address.= $company[0]->city.',';
		}
		if(!empty($company[0]->zipcode)){
		    $c_info_address.= $company[0]->zipcode.',';
		}
		if(!empty($country[0]->country_name)){
		    $c_info_address.= $country[0]->country_name;
		}
		
		//$c_info_address = $company[0]->address_1.'<br>'.$company[0]->address_2.', '.$company[0]->city.' - '.$company[0]->zipcode.', '.$country[0]->country_name;
		
		$email_phone_address = "<b>".$company_name."</b><br>".$this->lang->line('dashboard_email')." : $c_info_email <br>".$this->lang->line('xin_phone')." : $c_info_phone <br>".$this->lang->line('xin_address').": $c_info_address".'<br>TRN : '.$company[0]->government_tax;
		$header_string = $email_phone_address;
		
		// set document information
		$pdf->SetCreator('Corbuz');
		$pdf->SetAuthor('Corbuz');
		
		$pdf->SetDefaultMonospacedFont('courier');
		
		// set margins
		$pdf->SetMargins(15, 27, 15);
		$pdf->SetFooterMargin(10);
		
		// set auto page breaks
		$pdf->SetAutoPageBreak(TRUE, 25);
		
		// set image scale factor
		$pdf->setImageScale(1.25);
		$pdf->SetAuthor($company_name);
		$pdf->SetTitle($company[0]->name.' - '.$crm_settings[0]->delivery_note_title);
		// set font
		$pdf->SetFont('helvetica', 'B', 10);
				
		// set header and footer fonts
		$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));
		
		// set default monospaced font
		$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);
		
		// set margins
		$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP-15, PDF_MARGIN_RIGHT);
		$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);
		
		// set auto page breaks
		$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);
		
		// set image scale factor
		$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);
		
		// ---------------------------------------------------------
		
		// set default font subsetting mode
		$pdf->setFontSubsetting(true);
		
		// Set font
		// dejavusans is a UTF-8 Unicode font, if you only need to
		// print standard ASCII chars, you can use core fonts like
		// helvetica or times to reduce file size.
		$pdf->SetFont('dejavusans', '', 10, '', true);
		
		// Add a page
		// This method has several options, check the source code documentation for more information.
		$pdf->AddPage();
		
		// set text shadow effect
		//$pdf->setTextShadow(array('enabled'=>true, 'depth_w'=>0.2, 'depth_h'=>0.2, 'color'=>array(196,196,196), 'opacity'=>1, 'blend_mode'=>'Normal'));
		
		$pdf->setPrintHeader(false);
        $pdf->setPrintFooter(false);
		
		// -----------------------------------------------------------------------------
		
		$company_logo = '<img src="https://accounts.corbuz.com/accounts/uploads/company/'.$company[0]->logo.'" width="200"/>';
        if(empty($company[0]->logo) || $company[0]->logo=='no file'){
            $company_logo = '<img src="https://accounts.corbuz.com/accounts/uploads/company/default-logo.png" width="200"/>';
        }
        
        $shipping_address = '';
        if(!empty($quote_data[0]->shipping_address)){
            $shipping_address = '<br><br><h4>Ship To</h4>'.nl2br($quote_data[0]->shipping_address);
        }
        
        $refernce_no = '';
        if(!empty($quote_data[0]->reference)){
            $refernce_no = 'Reference # : '.$quote_data[0]->reference.'<br>';
        }
		
		$tbl = '
		<table cellpadding="1" cellspacing="1" border="0">
			<tr>
				<td align="left">
				'.$company_logo.'
				<br><br>'.$header_string.'
				<b><h4>&nbsp;</h4><h4>To:</h4></b>
				<br><b>'.$customer_data[0]->company_name.'</b>
				<br>Address : '.$customer_data[0]->address.'
				<br>Phone : '.$customer_data[0]->phone.'
				<br>Email : '.$customer_data[0]->email.'
				</td>
				
				<td align="right" valign="top">
				<h1 style="font-size:30px;">'.$crm_settings[0]->delivery_note_title.'</h1>
				<b>#'.$quote_data[0]->delivery_note_number.'</b><br>
				'.$refernce_no.'
				Date : '.date("d-m-Y", strtotime($quote_data[0]->delivery_date)).'
				'.$shipping_address.'
				</td>
			</tr>
		</table>
		';
		
		
		$pdf->writeHTML($tbl, true, false, false, false, '');
		
		// -----------------------------------------------------------------------------
		
		$fname = $user[0]->first_name.' '.$user[0]->last_name;
		$tbl = '
		<table cellpadding="5" cellspacing="0" border="1">
			<tr style="background-color:#444; color:#fff;">
                <th width="70%"><b>Item</b></th>
                <th align="center" width="30%"><b>Qty</b></th>
            </tr>
		';
		
		$subtotal = 0;
		foreach($quote_items as $item){
		    $item_name = '';
		    if(!empty($item->item_name)){
		        $item_name = '<b>'.$item->item_name.'</b><br>';
		    }
		    $tbl.= '
		    <tr>
                <td>'.$item_name.$item->description.'</td>
                <td align="center">'.$item->qty.' '.$item->unit.'</td>
            </tr>';
		}
		    
		
		$tbl.= '</table>';
	
		$pdf->writeHTML($tbl, true, false, true, false, '');
		
		
		if(!empty($quote_data[0]->after_item_contents)){
    		
    		$tbl = '
    		<table cellpadding="1" cellspacing="1" border="0">
    			<tr>
    				<td align="left">'.$quote_data[0]->after_item_contents.'</td>
    			</tr>
    		</table>
    		';
    		
    		$pdf->writeHTML($tbl, true, false, false, false, '');
    		
		}
		
		
		// -----------------------------------------------------------------------------
		
		$my_sign  = '<br><br><br><br><br><br>'.$this->lang->line('xin_payslip_authorised_signatory');
		$rec_sign = "<br><br><br><br><br><br>Receiver's Signature";
		$company_seal = '';
		    
		    if(!empty($quote_user[0]->sign_photo) && $quote_data[0]->add_personal_sign==1){
		        $my_sign = '<img src="https://accounts.corbuz.com/accounts/uploads/profile/sign/'.$quote_user[0]->sign_photo.'" width="180"/><br>'.$this->lang->line('xin_payslip_authorised_signatory');
		    }
		    
		    if(!empty($company[0]->company_seal) && $quote_data[0]->add_personal_sign==1){
		        $company_seal = '<img src="https://accounts.corbuz.com/accounts/uploads/company/seal/'.$company[0]->company_seal.'" width="150"/><br>';
		    }
		    
		    
    		$tbl = '<br><br>
    		<table cellpadding="4" cellspacing="0" border="0" width="100%">
    			<tr>
    			    <td align="left">'.$rec_sign.'</td>
    			    <td align="right">'.$company_seal.'</td>
    				<td align="right">'.$my_sign.'</td>
    			</tr>
    		</table>
    		';
		
		$pdf->writeHTML($tbl, true, false, false, false, '');
				
		// ---------------------------------------------------------
		
		// Close and output PDF document
		// This method has several options, check the source code documentation for more information.
		$fname = strtolower($fname);
		//Close and output PDF document
		
		if(!empty($save_quotation==true)){
		    $pdf->Output(__DIR__ . '/../../tmp_pdf/dln-'.$quote_data[0]->id.'.pdf', 'F');
		}
		else if(isset($_REQUEST['download']))
		{
		    $pdf->Output($quote_data[0]->delivery_note_number.'.pdf', 'D');
		}
		else
		{
		    $pdf->Output();
		}
	 }

	 
	 
	 
	 public function search_products(){
        
        $session = $this->session->userdata('username');
        if(!empty($session)){ 
			
		} else {
			redirect('');
		}
         
            $return_arr = array();
            $query_data = '';
            if(isset($_GET['term']))
            {
               $query_data = $_GET['term'];
               $search_result = $this->Xin_model->search_product_datas($query_data);
            }
         
         if(isset($search_result))
         {
                $slno=1;
                foreach($search_result as $p_vals)
                {
                   $return_arr[] =  $p_vals->name;
                }
         }
         
         echo json_encode($return_arr);
         
     }
     
     public function send_email() {
        $data['title'] = $this->Xin_model->site_title();
		$id = $this->input->get('quote_id');
		
		$session = $this->session->userdata('username');
		$user = $this->Xin_model->read_user_info($session['user_id']);
		$quote_data = $this->Delivery_note_model->read_invoice_information($id);
		$customer_data = $this->Customers_model->read_customer_information($quote_data[0]->customer_id);
		
		$data = array(
				'company_name' => $customer_data[0]->company_name,
				'customer_name' => $customer_data[0]->customer_name,
				'email' => $customer_data[0]->email,
				'quote_number' => $quote_data[0]->delivery_note_number,
				'quote_id' => $quote_data[0]->id,
				'signature' => $user[0]->signature
				);
				
		if(empty($user[0]->smtp_host)){
		    $data['error_view'] = '<br><br><div class="alert alert-danger">
                      <strong>Error!</strong> Please configure your Mail settings on your profile. <a href="https://accounts.corbuz.com/accounts/profile/">Go to Profile</a>
                    </div><br>';
                $this->load->view('delivery_note/send_email', $data);
		}
		else
		{
		    if(!empty($session)){ 
    			$this->load->view('delivery_note/send_email', $data);
    		} else {
    			redirect('');
    		}
		}
				
     }
     
     public function submit_email(){
         
        $Return = array('result'=>'', 'error'=>'');
        
        if($this->input->post('to_email')==='') {
            $Return['error'] = 'Email is required.';
    	}
    	else if($this->input->post('email_subject')==='') {
            $Return['error'] = 'Email subject is required.';
    	}
    				
		if($Return['error']!=''){
       		$this->output($Return);
    	}
        
        $id = $this->input->post('quote_id');
        $quote_data    = $this->Delivery_note_model->read_invoice_information($id);
        
        require 'mail/PHPMailerAutoload.php';
        
        $mail = new PHPMailer;
        $mail->CharSet = 'UTF-8';
        $mail->isSMTP();
        $mail->SMTPDebug = 0;
        $mail->Debugoutput = 'html';
        
        $session = $this->session->userdata('username');
		$user = $this->Xin_model->read_user_info($session['user_id']);
        
        $mail->Host = $user[0]->smtp_host;
        $mail->Port = $user[0]->smtp_port;
        $mail->SMTPSecure = $user[0]->smtp_connection;
        $mail->SMTPAuth = true;
        $mail->Username = $user[0]->smtp_username;
        $mail->Password = $user[0]->smtp_password;
        
        if(!empty($user[0]->smtp_global_from_mail) && !empty($user[0]->smtp_global_from_name)){
            $mail->setFrom($user[0]->smtp_global_from_mail, $user[0]->smtp_global_from_name);
        }
        
        $to_emails = explode(',', $this->input->post('to_email'));
        $cc_emails = explode(',', $this->input->post('cc_email'));
        
        foreach($to_emails as $email)
        {
           $mail->addAddress($email);
        }
        
        foreach($cc_emails as $email)
        {
           $mail->AddCC($email);
        }
        
        $mail->Subject = $this->input->post('email_subject');
        $mail->msgHTML($this->input->post('email_body'));
        
        $pdf_out = $this->print_delivery_note($id,$save=true);
        
        $mail->AddAttachment('./tmp_pdf/dln-'.$id.'.pdf', $quote_data[0]->delivery_note_number.'.pdf');
        
        
        foreach ($_FILES["mail_files"]["error"] as $key => $error){
            if ($error == UPLOAD_ERR_OK) {
                $tmp_name = $_FILES["mail_files"]["tmp_name"][$key];
                $name = $_FILES["mail_files"]["name"][$key];
                $mail->AddAttachment($_FILES['mail_files']['tmp_name'][$key],$_FILES['mail_files']['name'][$key]);
            }
        }
        
        
        if (!$mail->send()) {
            //echo "Mailer Error: " . $mail->ErrorInfo;
            $Return['error'] = $this->lang->line('xin_error_msg');
        } else {
            $Return['result'] = 'Email Successfully sent.';
            
            unlink('./tmp_pdf/dln-'.$id.'.pdf');
            
            $data = array(
    		'status' => 'sent',
    		);
    		$result = $this->Delivery_note_model->update_invoice($data,$id);
        }
        
        
        $this->output($Return);
        
     }
     
     public function delete_invoice() {
		/* Define return | here result is used to return user data and error for error message */
		$Return = array('result'=>'', 'error'=>'');
		$id = $this->uri->segment(3);
		
    		if(isset($id)) {
    		    $result1 = $this->Delivery_note_model->delete_invoice_data($id);
    		    $result2 = $this->Delivery_note_model->delete_invoice_items($id);
    		    if ($result1 == TRUE && $result2 == TRUE) {
    			    $Return['result'] = 'Invoice Deleted.';
    		    }
    		    else
    		    {
    		        $Return['error'] = $this->lang->line('xin_error_msg');
    		    }
    		} else {
    			$Return['error'] = $this->lang->line('xin_error_msg');
    		}
		$this->output($Return);
	}
	
	
	public function all_delivery_notes()
    {
        $session = $this->session->userdata('username');
		if(!empty($session)){ 
			
		} else {
			redirect('');
		}
		
		$data['title'] = $this->Xin_model->site_title();
		$data['breadcrumbs'] = 'All Delivery Notes';
		$data['path_url'] = 'all_delivery_notes';
		$session = $this->session->userdata('username');
		$role_resources_ids = $this->Xin_model->user_role_resource();
		
		if(in_array('74',$role_resources_ids)) {
    		if(!empty($session)){ 
    		$data['subview'] = $this->load->view("delivery_note/all_delivery_note_list", $data, TRUE);
    		$this->load->view('layout_main', $data); //page load
    		} else {
    			redirect('');
    		}
		}
    }
    
    
    public function all_delivery_notes_grid_data(){
        
        $requestData= $_REQUEST;
        
        $columns = array( 
        // datatable column index  => database column name
            0 => 'id', 
        	1 => 'customer',
        	2 => 'date',
        	3 => 'reference',
        	4 => 'added_by',
        	5 => 'status'
        );
        
        // getting total number records without any search
        $root_id = $_SESSION['root_id'];
        
        $sql = "select p.delivery_note_number,p.id,p.delivery_date,p.reference,p.status,c.company_name,e.first_name,e.last_name";
        $sql.=" FROM pricing_delivery_note p, xin_employees e, customers c where p.root_id = '".$root_id."' and p.customer_id = c.customer_id and p.added_by = e.user_id";
        
        $query=$this->db->query($sql);
        $totalData = $query->num_rows();
        $totalFiltered = $totalData;  // when there is no search parameter then total number rows = total number filtered rows.
        
        $sql = "select p.delivery_note_number,p.id,p.delivery_date,p.reference,p.status,c.company_name,e.first_name,e.last_name";
        $sql.=" FROM pricing_delivery_note p, xin_employees e, customers c where p.root_id = '".$root_id."' and p.customer_id = c.customer_id and p.added_by = e.user_id";

        if( !empty($requestData['search']['value']) ) {   // if there is a search parameter, $requestData['search']['value'] contains search parameter
        	$sql.=" AND ( p.invoice_number LIKE '%".$requestData['search']['value']."%' ";    
        	$sql.=" OR p.invoice_date LIKE '%".$requestData['search']['value']."%' ";
        	$sql.=" OR c.company_name LIKE '%".$requestData['search']['value']."%' ";
        	$sql.=" OR e.first_name LIKE '%".$requestData['search']['value']."%' ";
        	$sql.=" OR e.last_name LIKE '%".$requestData['search']['value']."%' ";
        	$sql.=" OR p.reference LIKE '%".$requestData['search']['value']."%' ";
        	$sql.=" OR p.expiry_date LIKE '%".$requestData['search']['value']."%' )";
        }
        
        $query=$this->db->query($sql);
        $totalFiltered = $query->num_rows(); // when there is a search parameter then we have to modify total number filtered rows as per search result. 
        $sql.=" ORDER BY ". $columns[$requestData['order'][0]['column']]."   ".$requestData['order'][0]['dir']."  LIMIT ".$requestData['start']." ,".$requestData['length']."   ";
        /* $requestData['order'][0]['column'] contains colmun index, $requestData['order'][0]['dir'] contains order such as asc/desc  */	
        $query=$this->db->query($sql);
        
        $role_resources_ids = $this->Xin_model->user_role_resource();
        $crm_settings = $this->Xin_model->read_setting_info(1);
        
        $data = array();
        foreach($query->result() as $row ) {  // preparing an array
            $r = $row;
               
               $customer_name = $r->company_name;
                    
                    
                    $edit_url = site_url('delivery_note/print_delivery_note/'.$r->id);
                    
                    $status = '<a target="blank" href="'.$edit_url.'" class="btn btn-sm btn-primary">Draft</a>';
                    
                    if($r->status=='sent')
                    {
                        $status = '<a target="blank" href="'.$edit_url.'" class="btn btn-sm btn-success">Sent</a>';
                    }
            
            $full_name = $r->first_name.' '.$r->last_name;        
            $nestedData=array(); 
            
            $nestedData[] = '<a target="blank" href="'.$edit_url.'">'.$r->delivery_note_number.'</a>';
        	$nestedData[] = '<a target="blank" href="'.$edit_url.'">'.$customer_name.'</a>';
        	$nestedData[] = date("d-m-Y", strtotime($r->delivery_date));
        	$nestedData[] = $r->reference;
        	$nestedData[] = $full_name;
        	$nestedData[] = $status;
        	
        	$data[] = $nestedData;
        }
        
        
        
        $json_data = array(
        			"draw"            => intval( $requestData['draw'] ),   // for every request/draw by clientside , they send a number as a parameter, when they recieve a response/data they first check the draw number, so we are sending same number in draw. 
        			"recordsTotal"    => intval( $totalData ),  // total number of records
        			"recordsFiltered" => intval( $totalFiltered ), // total number of records after searching, if there is no searching then totalFiltered = totalData
        			"data"            => $data   // total data array
        			);
        
        echo json_encode($json_data);  // send data as json format
    }
    
    public function delivery_note_list_by_customer(){
        
        $requestData= $_REQUEST;
        $customer_id = $this->uri->segment(3);
        
        $columns = array( 
        // datatable column index  => database column name
            0 => 'id', 
        	1 => 'customer',
        	2 => 'date',
        	3 => 'reference',
        	4 => 'added_by',
        	5 => 'status'
        );
        
        // getting total number records without any search
        $root_id = $_SESSION['root_id'];
        
        $session = $this->session->userdata('username');
        
        $role_resources_ids = $this->Xin_model->user_role_resource();
        $user_information = $this->Xin_model->read_user_info($session['user_id']);
        $company_employees  = $this->Xin_model->get_company_employees($user_information[0]->pricing_company);
        
        $company_emp_ids = array();
        foreach($company_employees as $emp_ids){
            array_push($company_emp_ids,$emp_ids->user_id);
        }
        $company_emp_ids = implode(', ', $company_emp_ids);
        
        $sql = "select p.delivery_note_number,p.id,p.delivery_date,p.reference,p.status,e.first_name,e.last_name";
        
        if(in_array('103',$role_resources_ids)) {
            $sql2=" FROM pricing_delivery_note p, xin_employees e where p.root_id = '".$root_id."' and p.customer_id = ".$customer_id." and p.added_by = e.user_id";
		}
		else if(in_array('102',$role_resources_ids)) {
            $sql2=" FROM pricing_delivery_note p, xin_employees e where p.root_id = '".$root_id."' and p.customer_id = ".$customer_id." and p.added_by IN (".$company_emp_ids.") and p.added_by = e.user_id";
		}
		else{
		    $sql2=" FROM pricing_delivery_note p, xin_employees e where p.root_id = '".$root_id."' and p.customer_id = ".$customer_id." and p.added_by = '".$session['user_id']."' and p.added_by = e.user_id";
		}
		
		$show_all_permission = $this->Xin_model->get_data_list_permission($session['user_id'],'delivery_notes');
		
		if($show_all_permission==0){
		    $sql2=" FROM pricing_delivery_note p, xin_employees e where p.root_id = '".$root_id."' and p.customer_id = ".$customer_id." and p.added_by = '".$session['user_id']."' and p.added_by = e.user_id";
		}
		
		$sql=$sql.$sql2;
        
        $query=$this->db->query($sql);
        $totalData = $query->num_rows();
        $totalFiltered = $totalData;  // when there is no search parameter then total number rows = total number filtered rows.

        if( !empty($requestData['search']['value']) ) {   // if there is a search parameter, $requestData['search']['value'] contains search parameter
        	$sql.=" AND ( p.invoice_number LIKE '%".$requestData['search']['value']."%' ";    
        	$sql.=" OR p.invoice_date LIKE '%".$requestData['search']['value']."%' ";
        	$sql.=" OR e.first_name LIKE '%".$requestData['search']['value']."%' ";
        	$sql.=" OR e.last_name LIKE '%".$requestData['search']['value']."%' ";
        	$sql.=" OR p.reference LIKE '%".$requestData['search']['value']."%' ";
        	$sql.=" OR p.expiry_date LIKE '%".$requestData['search']['value']."%' )";
        }
        
        $query=$this->db->query($sql);
        $totalFiltered = $query->num_rows(); // when there is a search parameter then we have to modify total number filtered rows as per search result. 
        $sql.=" ORDER BY ". $columns[$requestData['order'][0]['column']]."   ".$requestData['order'][0]['dir']."  LIMIT ".$requestData['start']." ,".$requestData['length']."   ";
        /* $requestData['order'][0]['column'] contains colmun index, $requestData['order'][0]['dir'] contains order such as asc/desc  */	
        $query=$this->db->query($sql);
        
        $role_resources_ids = $this->Xin_model->user_role_resource();
        $crm_settings = $this->Xin_model->read_setting_info(1);
        
        $data = array();
        foreach($query->result() as $row ) {  // preparing an array
            $r = $row;
                    
                    
                    $edit_url = site_url('delivery_note/view/'.$r->id);
                    
                    $status = '<a target="blank" href="'.$edit_url.'" class="btn btn-sm btn-primary">Draft</a>';
                    
                    if($r->status=='sent')
                    {
                        $status = '<a target="blank" href="'.$edit_url.'" class="btn btn-sm btn-success">Sent</a>';
                    }
            
            $full_name = $r->first_name.' '.$r->last_name;        
            $nestedData=array(); 
            
            $nestedData[] = '<a target="blank" href="'.$edit_url.'">'.$r->delivery_note_number.'</a>';
        	$nestedData[] = date("d-m-Y", strtotime($r->delivery_date));
        	$nestedData[] = $r->reference;
        	$nestedData[] = $full_name;
        	$nestedData[] = $status;
        	
        	$data[] = $nestedData;
        }
        
        
        
        $json_data = array(
        			"draw"            => intval( $requestData['draw'] ),   // for every request/draw by clientside , they send a number as a parameter, when they recieve a response/data they first check the draw number, so we are sending same number in draw. 
        			"recordsTotal"    => intval( $totalData ),  // total number of records
        			"recordsFiltered" => intval( $totalFiltered ), // total number of records after searching, if there is no searching then totalFiltered = totalData
        			"data"            => $data   // total data array
        			);
        
        echo json_encode($json_data);  // send data as json format
    }
    
    public function delivery_notes_grid_data(){
        
        $requestData= $_REQUEST;
        
        $columns = array( 
        // datatable column index  => database column name
            0 => 'id', 
        	1 => 'customer',
        	2 => 'date',
        	3 => 'reference',
        	4 => 'added_by',
        	5 => 'status'
        );
        
        // getting total number records without any search
        $root_id = $_SESSION['root_id'];
        
        $session = $this->session->userdata('username');
        
        $role_resources_ids = $this->Xin_model->user_role_resource();
        $user_information = $this->Xin_model->read_user_info($session['user_id']);
        $company_employees  = $this->Xin_model->get_company_employees($user_information[0]->pricing_company);
        
        $company_emp_ids = array();
        foreach($company_employees as $emp_ids){
            array_push($company_emp_ids,$emp_ids->user_id);
        }
        $company_emp_ids = implode(', ', $company_emp_ids);
        
        $sql = "select p.delivery_note_number,p.id,p.delivery_date,p.reference,p.status,c.company_name,e.first_name,e.last_name";
        
        if(in_array('103',$role_resources_ids)) {
            $sql2=" FROM pricing_delivery_note p, xin_employees e, customers c where p.root_id = '".$root_id."' and p.customer_id = c.customer_id and p.added_by = e.user_id";
		}
		else if(in_array('102',$role_resources_ids)) {
            $sql2=" FROM pricing_delivery_note p, xin_employees e, customers c where p.root_id = '".$root_id."' and p.customer_id = c.customer_id and p.added_by IN (".$company_emp_ids.") and p.added_by = e.user_id";
		}
		else{
		    $sql2=" FROM pricing_delivery_note p, xin_employees e, customers c where p.root_id = '".$root_id."' and p.customer_id = c.customer_id and p.added_by = '".$session['user_id']."' and p.added_by = e.user_id";
		}
		
		$show_all_permission = $this->Xin_model->get_data_list_permission($session['user_id'],'delivery_notes');
		
		if($show_all_permission==0){
		    $sql2=" FROM pricing_delivery_note p, xin_employees e, customers c where p.root_id = '".$root_id."' and p.customer_id = c.customer_id and p.added_by = '".$session['user_id']."' and p.added_by = e.user_id";
		}
		
		$sql=$sql.$sql2;
        
        $query=$this->db->query($sql);
        $totalData = $query->num_rows();
        $totalFiltered = $totalData;  // when there is no search parameter then total number rows = total number filtered rows.

        if( !empty($requestData['search']['value']) ) {   // if there is a search parameter, $requestData['search']['value'] contains search parameter
        	$sql.=" AND ( p.delivery_note_number LIKE '%".$requestData['search']['value']."%' ";    
        	$sql.=" OR p.delivery_date LIKE '%".$requestData['search']['value']."%' ";
        	$sql.=" OR c.company_name LIKE '%".$requestData['search']['value']."%' ";
        	$sql.=" OR e.first_name LIKE '%".$requestData['search']['value']."%' ";
        	$sql.=" OR e.last_name LIKE '%".$requestData['search']['value']."%' ";
        	$sql.=" OR p.reference LIKE '%".$requestData['search']['value']."%' )";
        }
        
        $query=$this->db->query($sql);
        $totalFiltered = $query->num_rows(); // when there is a search parameter then we have to modify total number filtered rows as per search result. 
        $sql.=" ORDER BY ". $columns[$requestData['order'][0]['column']]."   ".$requestData['order'][0]['dir']."  LIMIT ".$requestData['start']." ,".$requestData['length']."   ";
        /* $requestData['order'][0]['column'] contains colmun index, $requestData['order'][0]['dir'] contains order such as asc/desc  */	
        $query=$this->db->query($sql);
        
        $role_resources_ids = $this->Xin_model->user_role_resource();
        $crm_settings = $this->Xin_model->read_setting_info(1);
        
        $data = array();
        foreach($query->result() as $row ) {  // preparing an array
            $r = $row;
               
               $customer_name = $r->company_name;
                    
                    
                    $edit_url = site_url('delivery_note/view/'.$r->id);
                    
                    $status = '<a target="blank" href="'.$edit_url.'" class="btn btn-sm btn-primary">Draft</a>';
                    
                    if($r->status=='sent')
                    {
                        $status = '<a target="blank" href="'.$edit_url.'" class="btn btn-sm btn-success">Sent</a>';
                    }
            
            $full_name = $r->first_name.' '.$r->last_name;        
            $nestedData=array(); 
            
            $nestedData[] = '<a href="'.$edit_url.'">'.$r->delivery_note_number.'</a>';
        	$nestedData[] = '<a href="'.$edit_url.'">'.$customer_name.'</a>';
        	$nestedData[] = date("d-m-Y", strtotime($r->delivery_date));
        	$nestedData[] = $r->reference;
        	$nestedData[] = $full_name;
        	$nestedData[] = $status;
        	
        	$data[] = $nestedData;
        }
        
        
        
        $json_data = array(
        			"draw"            => intval( $requestData['draw'] ),   // for every request/draw by clientside , they send a number as a parameter, when they recieve a response/data they first check the draw number, so we are sending same number in draw. 
        			"recordsTotal"    => intval( $totalData ),  // total number of records
        			"recordsFiltered" => intval( $totalFiltered ), // total number of records after searching, if there is no searching then totalFiltered = totalData
        			"data"            => $data   // total data array
        			);
        
        echo json_encode($json_data);  // send data as json format
    }
	 
	 
}
