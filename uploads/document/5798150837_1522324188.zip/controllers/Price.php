<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Price extends MY_Controller {
	
	 public function __construct() {
        Parent::__construct();
		$this->load->library('session');
		$this->load->helper('form');
		$this->load->helper('url');
		$this->load->helper('html');
		$this->load->database();
		$this->load->library('form_validation');
		//load the model
		$this->load->model('Designation_model');
		$this->load->model("Products_model");
		$this->load->model("Price_model");
		$this->load->model("Xin_model");
	}
	
	/*Function to set JSON output*/
	public function output($Return=array()){
		/*Set response header*/
		header("Access-Control-Allow-Origin: *");
		header("Content-Type: application/json; charset=UTF-8");
		/*Final JSON response*/
		exit(json_encode($Return));
	}
	
	 public function index()
     {
         $session = $this->session->userdata('username');
		if(!empty($session)){ 
			
		} else {
			redirect('');
		}
		// get user > added by
		$user = $this->Xin_model->read_user_info($session['user_id']);
		// get designation
		$_designation = $this->Designation_model->read_designation_information($user[0]->designation_id);
		$data = array(
			'title' => $this->Xin_model->site_title(),
			'breadcrumbs' => $this->lang->line('dashboard_title'),
			'path_url' => 'price',
			'first_name' => $user[0]->first_name,
			'last_name' => $user[0]->last_name,
			'employee_id' => $user[0]->employee_id,
			'username' => $user[0]->username,
			'email' => $user[0]->email,
			'date_of_birth' => $user[0]->date_of_birth,
			'contact_no' => $user[0]->contact_no,
			'last_four_employees' => $this->Xin_model->last_four_employees()
			);
			$data['subview'] = $this->load->view('price/index', $data, TRUE);
			$this->load->view('layout_main', $data); //page load
     }
     
    public function price_history(){
        
        $session = $this->session->userdata('username');
		if(!empty($session)){ 
			
		} else {
			redirect('');
		}
		
		$session = $this->session->userdata('username');
		$data['title'] = $this->Xin_model->site_title();
		$data['my_price_history_data'] = $this->Xin_model->get_my_price_history();
		$data['breadcrumbs'] = 'Price History';
		$data['path_url'] = 'price_history';
		$role_resources_ids = $this->Xin_model->user_role_resource();
		if(in_array('63',$role_resources_ids) || in_array('64',$role_resources_ids) || in_array('65',$role_resources_ids)) {
			if(!empty($session)){ 
			$data['subview'] = $this->load->view("price/price_history", $data, TRUE);
			$this->load->view('layout_main', $data); //page load
			} else {
				redirect('');
			}
		} else {
			redirect('dashboard/');
		}
		
    }
    
    public function given_price_history(){
        
        $session = $this->session->userdata('username');
		if(!empty($session)){ 
			
		} else {
			redirect('');
		}
		
		$session = $this->session->userdata('username');
		$data['title'] = $this->Xin_model->site_title();
		$data['my_price_history_data'] = $this->Xin_model->get_my_given_price_history($session['user_id']);
		$data['breadcrumbs'] = 'My Given Price History';
		$data['path_url'] = 'price_history';
		$role_resources_ids = $this->Xin_model->user_role_resource();
		    
		    if(!empty($session)){ 
			$data['subview'] = $this->load->view("price/given_price_history", $data, TRUE);
			$this->load->view('layout_main', $data); //page load
			} else {
				redirect('');
			}
		
		
    }
    
    public function all_given_price_history(){
        
        $session = $this->session->userdata('username');
		if(!empty($session)){ 
			
		} else {
			redirect('');
		}
		
		$session = $this->session->userdata('username');
		$data['title'] = $this->Xin_model->site_title();
		$data['all_price_history_data'] = $this->Xin_model->get_all_given_price_history();
		$data['breadcrumbs'] = 'All Given Price History';
		$data['path_url'] = 'price_history';
		$role_resources_ids = $this->Xin_model->user_role_resource();
		 
		if(in_array('72',$role_resources_ids)) {   
		    if(!empty($session)){ 
			$data['subview'] = $this->load->view("price/all_given_price_history", $data, TRUE);
			$this->load->view('layout_main', $data); //page load
			} else {
				redirect('');
			}
		}
		
		
    }
 
    public function price_list()
     {
        $product_id = $this->uri->segment(3);
		$data['title'] = $this->Xin_model->site_title();
		$session = $this->session->userdata('username');
		if(!empty($session)){ 
			$this->load->view("price/price_list", $data);
		} else {
			redirect('');
		}
		// Datatables Variables
		$draw = intval($this->input->get("draw"));
		$start = intval($this->input->get("start"));
		$length = intval($this->input->get("length"));
		$role_resources_ids = $this->Xin_model->user_role_resource();
		
		$data = array();
          ?>
          <table class="table table-striped table-bordered dataTable" style="width:100%;">
              <thead>
                <tr>
                  <th></th>
                  <th>Supplier</th>
                  <th>Price</th>
                  <th>Date</th>
                  <th>Added By</th>
                  <?php if(in_array('68',$role_resources_ids)) { ?><th></th> <?php } ?>
                </tr>
              </thead>
              <tbody>
                <?php
                $slno=1;
                $product_price = $this->Xin_model->get_all_product_price($product_id);
                foreach($product_price as $p_vals)
                {
                $supplier_name = $this->Xin_model->get_supplier_name_by_id($p_vals->supplier_id);
                $user = $this->Xin_model->read_user_info($p_vals->added_by);
    			// user full name
    			$full_name = $user[0]->first_name.' '.$user[0]->last_name;
                ?>
                <tr>
                  <th><?php echo $slno; ?></th>
                  <th><?php if(isset($supplier_name[0]->name)){ echo $supplier_name[0]->name; } ?></th>
                  <th><?php echo $this->Xin_model->currency_sign($p_vals->price); ?></th>
                  <th><?php echo date('d M Y D h:i A' , strtotime($p_vals->date)); ?></th>
                  <th><?php echo $full_name; ?></th>
                  <?php if(in_array('68',$role_resources_ids)) { ?><th><button type="button" class="btn btn-danger btn-sm m-b-0-0 waves-effect waves-light delete" data-toggle="modal" data-target=".delete-modal" data-record-id="<?php echo $p_vals->id; ?>"><i class="fa fa-trash-o"></i></button></th> <?php } ?>
                </tr>
                <?php
                $slno++;
                }
                ?>
              </tbody>
            </table>
          <?php
          exit();
     }
     
     
     public function customer_price_list()
     {
        $product_id = $this->uri->segment(3);
		$data['title'] = $this->Xin_model->site_title();
		$session = $this->session->userdata('username');
		if(!empty($session)){ 
			$this->load->view("price/price_list", $data);
		} else {
			redirect('');
		}
		// Datatables Variables
		$draw = intval($this->input->get("draw"));
		$start = intval($this->input->get("start"));
		$length = intval($this->input->get("length"));
		$role_resources_ids = $this->Xin_model->user_role_resource();
		
		$data = array();
          ?>
          <table class="table table-striped table-bordered dataTable" style="width:100%;">
              <thead>
                <tr>
                  <th></th>
                  <th>Customer</th>
                  <th>Price</th>
                  <th>Date</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                <?php
                $slno=1;
                $product_price = $this->Xin_model->get_all_customer_price($product_id,$session['user_id']);
                foreach($product_price as $p_vals)
                {
                $customer_name = $this->Xin_model->get_customer_name_by_id($p_vals->customer_id);
                ?>
                <tr>
                  <th><?php echo $slno; ?></th>
                  <th><?php if(isset($customer_name[0]->company_name)){ echo $customer_name[0]->company_name; } ?></th>
                  <th><?php echo $this->Xin_model->currency_sign($p_vals->price); ?></th>
                  <th><?php echo date('d M Y D h:i A' , strtotime($p_vals->date)); ?></th>
                  <th><button type="button" class="btn btn-danger btn-sm m-b-0-0 waves-effect waves-light delete_customer_price" data-toggle="modal" data-target=".delete-modal" data-record-id="<?php echo $p_vals->id; ?>"><i class="fa fa-trash-o"></i></button></th>
                </tr>
                <?php
                $slno++;
                }
                ?>
              </tbody>
            </table>
          <?php
          exit();
     }
     
     
     public function search_results_data(){
        
        $session = $this->session->userdata('username');
        if(!empty($session)){ 
			
		} else {
			?>
			<script>
			    window.location = './';
			</script>
			<?php
			exit();
		}
         
            $query_data = '';
            if(isset($_REQUEST['q']))
            {
               $query_data = $_REQUEST['q'];
               $search_result = $this->Xin_model->search_product_datas($query_data);
            }
            
         $role_resources_ids = $this->Xin_model->user_role_resource();
         
         if(isset($search_result))
         {
         ?>
         <table class="table table-striped table-bordered dataTable" style="width:100%;" id="pxin_table">
              <thead>
                <tr>
                  <th></th>
                  <th>Name</th>
                  <th>Price 1</th>
                  <th>Price 2</th>
                  <th>Price 3</th>
                  <th>C Price 1</th>
                  <th>C Price 2</th>
                  <th>C Price 3</th>
                </tr>
              </thead>
              <tbody>
                <?php
                $slno=1;
                foreach($search_result as $p_vals)
                {
                $product_cat   = $this->Xin_model->get_product_cat_by_id($p_vals->category_id);
                $product_price = $this->Xin_model->get_product_price($p_vals->id);
                $price_array   = json_decode(json_encode($product_price), True);
                
                $price_1 = '--'; $supplier_1 = '';
                $price_2 = '--'; $supplier_2 = '';
                $price_3 = '--'; $supplier_3 = '';
                
                $customer_price = $this->Xin_model->get_customer_price($p_vals->id,$session['user_id']);
                $customer_price_array   = json_decode(json_encode($customer_price), True);
                
                $price_4 = '--'; $customer_1 = '';
                $price_5 = '--'; $customer_2 = '';
                $price_6 = '--'; $customer_3 = '';
                
                if(isset($price_array[0]['price'])){ $price_1 = $this->Xin_model->currency_sign($price_array[0]['price']); $suppliers_1 = $this->Xin_model->get_supplier_name_by_id($price_array[0]['supplier_id']); if(isset($suppliers_1[0]->name)){ $supplier_1 = ' <br>('.$suppliers_1[0]->name.')'; } }
                if(isset($price_array[1]['price'])){ $price_2 = $this->Xin_model->currency_sign($price_array[1]['price']); $suppliers_2 = $this->Xin_model->get_supplier_name_by_id($price_array[1]['supplier_id']); if(isset($suppliers_2[0]->name)){ $supplier_2 = ' <br>('.$suppliers_2[0]->name.')'; } }
                if(isset($price_array[2]['price'])){ $price_3 = $this->Xin_model->currency_sign($price_array[2]['price']); $suppliers_3 = $this->Xin_model->get_supplier_name_by_id($price_array[2]['supplier_id']); if(isset($suppliers_3[0]->name)){ $supplier_3 = ' <br>('.$suppliers_3[0]->name.')'; } }
                
                if(isset($customer_price_array[0]['price'])){ $price_4 = $this->Xin_model->currency_sign($customer_price_array[0]['price']); $customers_1 = $this->Xin_model->get_customer_name_by_id($customer_price_array[0]['customer_id']); if(isset($customers_1[0]->company_name)){ $customer_1 = ' <br>('.$customers_1[0]->company_name.')'; } }
                if(isset($customer_price_array[1]['price'])){ $price_5 = $this->Xin_model->currency_sign($customer_price_array[1]['price']); $customers_2 = $this->Xin_model->get_customer_name_by_id($customer_price_array[1]['customer_id']); if(isset($customers_2[0]->company_name)){ $customer_2 = ' <br>('.$customers_2[0]->company_name.')'; } }
                if(isset($customer_price_array[2]['price'])){ $price_6 = $this->Xin_model->currency_sign($customer_price_array[2]['price']); $customers_3 = $this->Xin_model->get_customer_name_by_id($customer_price_array[2]['customer_id']); if(isset($customers_3[0]->company_name)){ $customer_3 = ' <br>('.$customers_3[0]->company_name.')'; } }
                ?>
                <tr>
                  <td><?php //echo $slno; ?> <button class="m-b-0-0 waves-effect waves-light btn btn-sm btn-success ask_price" data-product_id="<?php echo $p_vals->id; ?>"><i class="fa fa-check icon"></i> Ask Price</button> </td>
                  <td style="width:40%;"><a href="javascript:void(0)" data-toggle="modal" data-target=".edit-modal-data" data-product_id="<?php echo $p_vals->id; ?>"><?php echo $p_vals->name; ?></a></td>
                  <td <?php if(!empty($price_array[0]['price'])){ echo 'style="color:#f44336; width:9%;"'; }else { echo 'style="width:9%;"'; } ?> ><b><?php echo $price_1.$supplier_1; ?></b></td>
                  <td <?php if(!empty($price_array[1]['price'])){ echo 'style="color:#673AB7; width:9%;"'; }else { echo 'style="width:9%;"'; } ?> ><b><?php echo $price_2.$supplier_2; ?></b></td>
                  <td <?php if(!empty($price_array[2]['price'])){ echo 'style="color:#2196F3; width:9%;"'; }else { echo 'style="width:9%;"'; } ?> ><?php echo $price_3.$supplier_3; ?></td>
                  
                  <td <?php if(!empty($customer_price_array[0]['price'])){ echo 'style="color:#f44336; width:9%; background-color: #dff0d8;"'; }else { echo 'style="width:9%; background-color: #dff0d8;"'; } ?> ><b><?php echo $price_4.$customer_1; ?></b></td>
                  <td <?php if(!empty($customer_price_array[1]['price'])){ echo 'style="color:#673AB7; width:9%; background-color: #dff0d8;"'; }else { echo 'style="width:9%; background-color: #dff0d8;"'; } ?> ><b><?php echo $price_5.$customer_2; ?></b></td>
                  <td <?php if(!empty($customer_price_array[2]['price'])){ echo 'style="color:#2196F3; width:9%; background-color: #dff0d8;"'; }else { echo 'style="width:9%; background-color: #dff0d8;"'; } ?> ><?php echo $price_6.$customer_3; ?></td>
                </tr>
                <?php
                $slno++;
                }
                ?>
              </tbody>
            </table>
         <?php
         }
     }
     
     public function product_cat_list() {

		$data['title'] = $this->Xin_model->site_title();
		
		$user_id = $this->session->userdata('user_id');
		
		$data = array();
		$session = $this->session->userdata('username');
		if(!empty($session)){ 
			$this->load->view("products/get_product_cat", $data);
		} else {
			redirect('');
		}
		// Datatables Variables
		$draw = intval($this->input->get("draw"));
		$start = intval($this->input->get("start"));
		$length = intval($this->input->get("length"));
	 }
	 
	 public function read()
	{
	    $session = $this->session->userdata('username');
		$data['title'] = $this->Xin_model->site_title();
		$id = $this->input->get('product_id');
		$result = $this->Products_model->read_product_information($id);
		$data = array(
				'product_id' => $result[0]->id,
				'name' => $result[0]->name,
				'model_number' => $result[0]->model_number,
				'category_id' => $result[0]->category_id,
				'suppliers' => $this->Xin_model->get_all_suppliers(),
				'customers' => $this->Xin_model->get_all_customers($session['user_id']),
				'des' => $result[0]->des
				);
		$session = $this->session->userdata('username');
		if(!empty($session)){ 
			$this->load->view('price/dialog_price', $data);
		} else {
			redirect('');
		}
	}
	
	// Validate and add info in database
	public function add_price() {
	    date_default_timezone_set('Asia/Dubai');
		if($this->input->post('add_type')=='price') {
		
		/* Define return | here result is used to return user data and error for error message */
		$Return = array('result'=>'', 'error'=>'');
			
		/* Server side PHP input validation */
		if($this->input->post('supplier')==='') {
        	$Return['error'] = 'Supplier field is required.';
		} else if($this->input->post('price')==='') {
			$Return['error'] = 'Price field is required.';
		}
				
		if($Return['error']!=''){
       		$this->output($Return);
    	}
	    $session = $this->session->userdata('username');
		$data = array(
		'product_id' => $this->input->post('product_id'),
		'supplier_id' => $this->input->post('supplier'),
		'price' => $this->input->post('price'),
		'added_by' => $session['user_id'],
		'date' => date('Y-m-d H:i:s'),
		);
		$result = $this->Price_model->add($data);
		if ($result == TRUE) {
			$Return['result'] = 'Price successfully updated.';
		} else {
			$Return['error'] = $this->lang->line('xin_error_msg');
		}
		$this->output($Return);
		exit;
		}
	}
	
	public function add_customer_price() {
	    date_default_timezone_set('Asia/Dubai');
		if($this->input->post('add_type')=='customer_price') {
		
		/* Define return | here result is used to return user data and error for error message */
		$Return = array('result'=>'', 'error'=>'');
			
		/* Server side PHP input validation */
		if($this->input->post('customer')==='') {
        	$Return['error'] = 'Customer field is required.';
		} else if($this->input->post('price')==='') {
			$Return['error'] = 'Price field is required.';
		}
				
		if($Return['error']!=''){
       		$this->output($Return);
    	}
	    $session = $this->session->userdata('username');
		$data = array(
		'product_id' => $this->input->post('product_id'),
		'customer_id' => $this->input->post('customer'),
		'price' => $this->input->post('price'),
		'added_by' => $session['user_id'],
		'date' => date('Y-m-d H:i:s'),
		);
		$result = $this->Price_model->add_customer_price($data);
		if ($result == TRUE) {
			$Return['result'] = 'Customer Price successfully updated.';
		} else {
			$Return['error'] = $this->lang->line('xin_error_msg');
		}
		$this->output($Return);
		exit;
		}
	}
	
	public function delete() {
		/* Define return | here result is used to return user data and error for error message */
		$Return = array('result'=>'', 'error'=>'');
		$id = $this->uri->segment(3);
		
    		$result = $this->Price_model->delete_record($id);
    		if(isset($id)) {
    			$Return['result'] = 'Product Price Deleted.';
    		} else {
    			$Return['error'] = $this->lang->line('xin_error_msg');
    		}
		$this->output($Return);
	}
	
	public function delete_my_price_request() {
		/* Define return | here result is used to return user data and error for error message */
		$Return = array('result'=>'', 'error'=>'');
		$id = $this->uri->segment(3);
		
    		$result = $this->Price_model->delete_my_price_request_record($id);
    		if(isset($id)) {
    			$Return['result'] = 'Price Request Deleted.';
    		} else {
    			$Return['error'] = $this->lang->line('xin_error_msg');
    		}
		$this->output($Return);
	}
	
	public function delete_customer_price() {
		/* Define return | here result is used to return user data and error for error message */
		$Return = array('result'=>'', 'error'=>'');
		$id = $this->uri->segment(3);
		
    		$result = $this->Price_model->delete_customer_price($id);
    		if(isset($id)) {
    			$Return['result'] = 'Customer Price Deleted.';
    		} else {
    			$Return['error'] = $this->lang->line('xin_error_msg');
    		}
		$this->output($Return);
	}
	
	public function all_price_requests(){
	    
        
        $session = $this->session->userdata('username');
		if(!empty($session)){ 
			
		} else {
			redirect('');
		}
		
		$session = $this->session->userdata('username');
		$data['title'] = $this->Xin_model->site_title();
		$data['all_price_requests_data'] = $this->Xin_model->get_all_price_requests($session['user_id']);
		$data['breadcrumbs'] = 'All Price Requests';
		$data['path_url'] = 'all_price_requests';
		$role_resources_ids = $this->Xin_model->user_role_resource();
		    
		    if(!empty($session)){ 
			$data['subview'] = $this->load->view("price/all_price_requests", $data, TRUE);
			$this->load->view('layout_main', $data); //page load
			} else {
				redirect('');
			}
		
		
    
	}
	
	public function my_price_requests(){
        
        $session = $this->session->userdata('username');
		if(!empty($session)){ 
			
		} else {
			redirect('');
		}
		
		$session = $this->session->userdata('username');
		$data['title'] = $this->Xin_model->site_title();
		$data['my_all_price_requests_data'] = $this->Xin_model->get_my_all_price_requests($session['user_id']);
		$data['breadcrumbs'] = 'My all Price Requests';
		$data['path_url'] = 'my_all_price_requests';
		$role_resources_ids = $this->Xin_model->user_role_resource();
		    
		    if(!empty($session)){ 
			$data['subview'] = $this->load->view("price/my_all_price_requests", $data, TRUE);
			$this->load->view('layout_main', $data); //page load
			} else {
				redirect('');
			}
    
	}
	
	public function ask_price(){
	    
	    if($this->input->post('add_type')=='ask_price') {
	        
	        $Return = array('result'=>'', 'error'=>'');
			
    		/* Server side PHP input validation */
    		if($this->input->post('product_id')==='') {
            	$Return['error'] = $this->lang->line('xin_error_msg');
    		} 
    				
    		if($Return['error']!=''){
           		$this->output($Return);
        	}
        	
        	$root_id = $_SESSION['root_id'];
        	$session = $this->session->userdata('username');
        	
        	$condition = "product_id =" . "'" . $this->input->post('product_id') . "' and added_by = '".$session['user_id']."' and root_id = '".$root_id."'";
    		$this->db->select('*');
    		$this->db->from('pricing_price_request');
    		$this->db->where($condition);
    		$query = $this->db->get();
    		
    		if ($query->num_rows() == 1) {
    		    $result = true;
    		}
    		else
    		{
        	
        		$data = array(
        		'product_id' => $this->input->post('product_id'),
        		'added_by' => $session['user_id'],
        		'root_id' => $_SESSION['root_id'],
        		'date' => date('Y-m-d H:i:s'),
        		);
        		
        		$this->db->insert('pricing_price_request', $data);
        		if ($this->db->affected_rows() > 0) {
        			$result = true;
        		} else {
        			$result = false;
        		}
    		
    		}
    		
    		if ($result == TRUE) {
    			$Return['result'] = 'Price request successfully submited.';
    		} else {
    			$Return['error'] = $this->lang->line('xin_error_msg');
    		}
    		
    		$this->output($Return);
    		exit;
	        
	    }
	}
	
	public function ignore_price_request(){
	    
	    $session = $this->session->userdata('username');
		$data['title'] = $this->Xin_model->site_title();
		$id = $this->input->get('product_id');
		$result = $this->Products_model->read_product_information($id);
		$data = array(
				'product_id' => $result[0]->id,
				'name' => $result[0]->name,
				'model_number' => $result[0]->model_number,
				'category_id' => $result[0]->category_id,
				'des' => $result[0]->des
				);
		$session = $this->session->userdata('username');
		if(!empty($session)){ 
			$this->load->view('price/ignore_price_request', $data);
		} else {
			redirect('');
		}
	
	}
	
	public function get_all_price_requests_count(){
	    $session = $this->session->userdata('username');
	    $user_id = $session['user_id'];
	    $root_id   = $_SESSION['root_id'];
	    $condition = "root_id ='" . $root_id . "' and added_by!='".$user_id."' and status= '0' order by id desc limit 200";
        $this->db->select('*');
		$this->db->from('pricing_price_request');
		$this->db->where($condition);
		$query = $this->db->get();
		echo $query->num_rows();
	}
	
	public function get_my_all_price_requests_count(){
	    $session = $this->session->userdata('username');
	    $user_id = $session['user_id'];
	    $root_id   = $_SESSION['root_id'];
	    $condition = "root_id ='" . $root_id . "' and added_by='".$user_id."' and status = '1' and read_status = '0' order by id desc limit 200";
        $this->db->select('*');
		$this->db->from('pricing_price_request');
		$this->db->where($condition);
		$query = $this->db->get();
		echo $query->num_rows();
	}
	
	
	public function get_all_price_notifications(){
	    
	    $session = $this->session->userdata('username');
	    $user_id = $session['user_id'];
	    $root_id   = $_SESSION['root_id'];
	    
	    $condition = "root_id ='" . $root_id . "' and added_by!='".$user_id."' and status= '0' order by id desc limit 200";
        $this->db->select('*');
		$this->db->from('pricing_price_request');
		$this->db->where($condition);
		$query = $this->db->get();
		$all_requests = $query->num_rows();
		
		$condition = "root_id ='" . $root_id . "' and added_by='".$user_id."' and status = '1' and read_status = '0' order by id desc limit 200";
        $this->db->select('*');
		$this->db->from('pricing_price_request');
		$this->db->where($condition);
		$query = $this->db->get();
		$my_requests = $query->num_rows();
		
		$not_data = array(
		    'all_requests' => $all_requests,
		    'my_requests'  => $my_requests
		    );
		    
		$this->output($not_data);
    	exit;
	}
	
	public function update_ignore_request(){
	    
	    if($this->input->post('add_type')=='ignore_request') {
		
    		/* Define return | here result is used to return user data and error for error message */
    		$Return = array('result'=>'', 'error'=>'');
    			
    		/* Server side PHP input validation */
    		if($this->input->post('ignore_reason')==='') {
            	$Return['error'] = 'Ignore reason is required.';
    		} 
    				
    		if($Return['error']!=''){
           		$this->output($Return);
        	}
    	    
    	    $session = $this->session->userdata('username');
    	    $user_id = $session['user_id'];
    	    $root_id   = $_SESSION['root_id'];
    	    
    	    $request_id = $this->input->post('request_id');
    	    $product_id = $this->input->post('product_id');
    	    
    	    $data = array(
    	        'status' => 1,
    	        'ignore_status' => 1,
    	        'ignore_reason' => $this->input->post('ignore_reason'),
    	        'updated_by' => $user_id,
        		'updated_date' => date('Y-m-d H:i:s')
    	    );
    		$condition = "product_id =" . "'" . $product_id . "' and root_id =" . "'" . $root_id . "' and id = '".$request_id."'";
    		$this->db->where($condition);
    		
    		if ($this->db->update('pricing_price_request',$data)) {
    			$Return['result'] = 'Data successfully updated.';
    		} else {
    			$Return['error'] = $this->lang->line('xin_error_msg');
    		}
    		$this->output($Return);
    		exit;
		
	    }
	    
	}
	
}
