<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Customers extends MY_Controller {
	
	 public function __construct() {
        Parent::__construct();
		$this->load->library('session');
		$this->load->helper('form');
		$this->load->helper('url');
		$this->load->helper('html');
		$this->load->database();
		$this->load->library('form_validation');
		//load the model
		$this->load->model("Customers_model");
		$this->load->model("Xin_model");
	}
	
	/*Function to set JSON output*/
	public function output($Return=array()){
		/*Set response header*/
		header("Access-Control-Allow-Origin: *");
		header("Content-Type: application/json; charset=UTF-8");
		/*Final JSON response*/
		exit(json_encode($Return));
	}
	
	public function test(){
	    $query=$this->db->query("select * from xin_employees");
        foreach($query->result() as $row)
        {
        
            $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
            $charactersLength = strlen($characters);
            $randomString = '';
            for ($i = 0; $i < 10; $i++) {
                $randomString .= $characters[rand(0, $charactersLength - 1)];
            }
            echo "<br>".$salt= $randomString;
        
        $pw_hash = sha1($salt.$row->password);
        $sql = $this->db->query("UPDATE xin_employees SET sec_pass='".$pw_hash."',`pslt`='".$salt."' WHERE user_id='".$row->user_id."'");
        }
	}
	
	 public function index()
     {
        $session = $this->session->userdata('username');
		if(!empty($session)){ 
			
		} else {
			redirect('');
		}
		
		$data['show_all_list'] = 0;
		$role_resources_ids = $this->Xin_model->user_role_resource();
        if(in_array('77',$role_resources_ids) || in_array('78',$role_resources_ids)) {
            $data['show_all_list'] = 1;
        }
        
        $data['show_all_check'] = 0;
        $show_all_permission = $this->Xin_model->get_data_list_permission($session['user_id'],'customers');
		if($show_all_permission>=1){
		    $data['show_all_check'] = 1;
		}
		
		$data['title'] = $this->Xin_model->site_title();
		$data['breadcrumbs'] = 'Customers';
		$data['path_url'] = 'customers';
		$session = $this->session->userdata('username');
		$role_resources_ids = $this->Xin_model->user_role_resource();
		
			if(!empty($session)){ 
			$data['subview'] = $this->load->view("customers/customers_list", $data, TRUE);
			$this->load->view('layout_main', $data); //page load
			} else {
				redirect('');
			}
     }
     
    public function all_customers()
    {
        $session = $this->session->userdata('username');
		if(!empty($session)){ 
			
		} else {
			redirect('');
		}
		
		$data['title'] = $this->Xin_model->site_title();
		$data['breadcrumbs'] = 'All Customers';
		$data['path_url'] = 'all_customers';
		$session = $this->session->userdata('username');
		$role_resources_ids = $this->Xin_model->user_role_resource();
		
		if(in_array('72',$role_resources_ids)) {
    		if(!empty($session)){ 
    		$data['subview'] = $this->load->view("customers/all_customers_list", $data, TRUE);
    		$this->load->view('layout_main', $data); //page load
    		} else {
    			redirect('');
    		}
		}
    }
    
    public function all_customers_list()
    {
        $data['title'] = $this->Xin_model->site_title();
		$session = $this->session->userdata('username');
		if(!empty($session)){ 
			$this->load->view("customers/all_customers_list", $data);
		} else {
			redirect('');
		}
		// Datatables Variables
		$draw = intval($this->input->get("draw"));
		$start = intval($this->input->get("start"));
		$length = intval($this->input->get("length"));
		
		
		$bank = $this->Customers_model->get_all_customers();
		
		$data = array();

          foreach($bank->result() as $r) {
			  // get user
			  $user = $this->Xin_model->read_user_info($r->added_by);
			  // user full name
			  $full_name = $user[0]->first_name.' '.$user[0]->last_name;

               $data[] = array(
                    $r->company_name,
					$r->address,
					$r->customer_name,
					$r->email,
                    $r->phone,
                    $full_name
               );
          }

          $output = array(
               "draw" => $draw,
                 "recordsTotal" => $bank->num_rows(),
                 "recordsFiltered" => $bank->num_rows(),
                 "data" => $data
            );
          echo json_encode($output);
          exit();
    }
 
    public function customers_list()
     {

		$data['title'] = $this->Xin_model->site_title();
		$session = $this->session->userdata('username');
		if(!empty($session)){ 
			$this->load->view("customers/customers_list", $data);
		} else {
			redirect('');
		}
		// Datatables Variables
		$draw = intval($this->input->get("draw"));
		$start = intval($this->input->get("start"));
		$length = intval($this->input->get("length"));
		
		
		$bank = $this->Customers_model->get_customers($session['user_id']);
		
		$data = array();

          foreach($bank->result() as $r) {
			  // get user
			  $user = $this->Xin_model->read_user_info($r->added_by);
			  // user full name
			  $full_name = $user[0]->first_name.' '.$user[0]->last_name;
			  
			    $option_buttons  = '<span data-toggle="tooltip" data-placement="top" title="View"><button type="button" class="btn btn-secondary btn-sm m-b-0-0 waves-effect waves-light" data-toggle="modal" data-target=".view-modal-data" data-customer_id="'. $r->customer_id . '"><i class="fa fa-eye"></i></button></span>';
        		$option_buttons .= '<span data-toggle="tooltip" data-placement="top" title="Edit"><button type="button" class="btn btn-secondary btn-sm m-b-0-0 waves-effect waves-light"  data-toggle="modal" data-target="#edit-modal-data"  data-customer_id="'. $r->customer_id . '"><i class="fa fa-pencil-square-o"></i></button></span></span>';
        		$option_buttons .= '<span data-toggle="tooltip" data-placement="top" title="Delete"><button type="button" class="btn btn-danger btn-sm m-b-0-0 waves-effect waves-light delete" data-toggle="modal" data-target=".delete-modal" data-record-id="'. $r->customer_id . '"><i class="fa fa-trash-o"></i></button></span>';
        		
			  

               $data[] = array(
			   		$option_buttons,
                    $r->company_name,
					$r->address,
					$r->customer_name,
					$r->email,
                    $r->phone,
                    $r->trn
               );
          }

          $output = array(
               "draw" => $draw,
                 "recordsTotal" => $bank->num_rows(),
                 "recordsFiltered" => $bank->num_rows(),
                 "data" => $data
            );
          echo json_encode($output);
          exit();
     }
     
    public function customers_contact_data()
    {
        $customer_id  = $this->uri->segment(3);
        $data['title'] = $this->Xin_model->site_title();
		$session = $this->session->userdata('username');
		if(!empty($session)){ 
			$this->load->view("customers/customers_list", $data);
		} else {
			redirect('');
		}
		// Datatables Variables
		$draw = intval($this->input->get("draw"));
		$start = intval($this->input->get("start"));
		$length = intval($this->input->get("length"));
		
		
		$bank = $this->Customers_model->get_customers_contacts($customer_id);
		
		$data = array();

          foreach($bank->result() as $r) {
    		  // get user
    		  $user = $this->Xin_model->read_user_info($r->added_by);
    		  // user full name
    		  $full_name = $user[0]->first_name.' '.$user[0]->last_name;
    		  
    		    //$option_buttons  = '<span data-toggle="tooltip" data-placement="top" title="View"><button type="button" class="btn btn-secondary btn-sm m-b-0-0 waves-effect waves-light" data-toggle="modal" data-target=".view-modal-data" data-customer_id="'. $r->customer_id . '"><i class="fa fa-eye"></i></button></span>';
        		$option_buttons  = '<span data-toggle="tooltip" data-placement="top" title="Edit"><button type="button" class="btn btn-secondary btn-sm m-b-0-0 waves-effect waves-light"  data-toggle="modal" data-target="#edit-modal-data"  data-contact_id="'. $r->id . '"><i class="fa fa-pencil-square-o"></i></button></span></span>';
        		$option_buttons .= '<span data-toggle="tooltip" data-placement="top" title="Delete"><button type="button" class="btn btn-danger btn-sm m-b-0-0 waves-effect waves-light delete" data-toggle="modal" data-target=".delete-modal" data-record-id="'. $r->id . '"><i class="fa fa-trash-o"></i></button></span>';
        		
    		  
    
               $data[] = array(
                    $r->name,
    				$r->email,
    				$r->position,
                    $r->phone,
                    $full_name,
    		   		$option_buttons,
               );
          }
    
          $output = array(
               "draw" => $draw,
                 "recordsTotal" => $bank->num_rows(),
                 "recordsFiltered" => $bank->num_rows(),
                 "data" => $data
            );
          echo json_encode($output);
          exit();
    }
	 
	public function read()
	{
		$data['title'] = $this->Xin_model->site_title();
		$id = $this->input->get('customer_id');
		$result = $this->Customers_model->read_customer_information($id);
		$data = array(
				'customer_id' => $result[0]->customer_id,
				'company_name' => $result[0]->company_name,
				'customer_name' => $result[0]->customer_name,
				'email' => $result[0]->email,
				'trn' => $result[0]->trn,
				'phone' => $result[0]->phone,
				'address' => $result[0]->address
				);
		$session = $this->session->userdata('username');
		if(!empty($session)){ 
			$this->load->view('customers/dialog_customers', $data);
		} else {
			redirect('');
		}
	}
	
	public function read_contact()
	{
		$data['title'] = $this->Xin_model->site_title();
		$id = $this->input->get('contact_id');
		$result = $this->Customers_model->read_customer_contact_information($id);
		$data = array(
				'customer_id' => $result[0]->customer_id,
				'contact_id' => $result[0]->id,
				'name' => $result[0]->name,
				'email' => $result[0]->email,
				'position' => $result[0]->position,
				'phone' => $result[0]->phone
				);
		$session = $this->session->userdata('username');
		if(!empty($session)){ 
			$this->load->view('customers/dialog_customers_contact', $data);
		} else {
			redirect('');
		}
	}
	
	public function details(){
	    
	    $id  = $this->uri->segment(3);
	    $url = $this->uri->segment(4);
	    $tab_link = '';
	    if(isset($url)){
	        $tab_link = $url;
	    }
	    
	    $result = $this->Customers_model->read_customer_information($id);
	    if(isset($result[0]->root_id)){ if($result[0]->root_id!=$_SESSION['root_id']){ redirect(''); } }
	    else{ redirect(''); }
	    
		$data = array(
		    'title' => $this->Xin_model->site_title(),
		    'breadcrumbs' => 'Customer Details ('.$result[0]->company_name.')',
		    'path_url' => 'customers_details',
		    'tab_link' => $tab_link,
			'customer_id' => $result[0]->customer_id,
			'company_name' => $result[0]->company_name,
			'customer_name' => $result[0]->customer_name,
			'email' => $result[0]->email,
			'trn' => $result[0]->trn,
			'phone' => $result[0]->phone,
			'address' => $result[0]->address
			);
	    
        $session = $this->session->userdata('username');
		if(!empty($session)){ 
			
		} else {
			redirect('');
		}
		
		$role_resources_ids = $this->Xin_model->user_role_resource();
		
		$session = $this->session->userdata('username');
		$role_resources_ids = $this->Xin_model->user_role_resource();
		
			if(!empty($session)){ 
			$data['subview'] = $this->load->view("customers/customers_details", $data, TRUE);
			$this->load->view('layout_main', $data); //page load
			} else {
				redirect('');
			}
     
	}
	
	// Validate and add info in database
	public function add_customer() {
	
		if($this->input->post('add_type')=='customers') {
		
		/* Define return | here result is used to return user data and error for error message */
		$Return = array('result'=>'', 'error'=>'');
			
		/* Server side PHP input validation */
		if($this->input->post('company_name')==='') {
        	$Return['error'] = 'Company name field is required.';
		}
				
		if($Return['error']!=''){
       		$this->output($Return);
    	}
	    $session = $this->session->userdata('username');
		$data = array(
		'company_name' => $this->input->post('company_name'),
		'customer_name' => $this->input->post('customer_name'),
		'email' => $this->input->post('email'),
		'trn' => $this->input->post('trn'),
		'phone' => $this->input->post('phone'),
		'address' => $this->input->post('address'),
		'added_by' => $session['user_id'],
		'date' => date('Y-m-d H:i:s'),
		);
		$result = $this->Customers_model->add($data);
		if ($result == TRUE) {
			$Return['result'] = 'Customer successfully added.';
		} else {
			$Return['error'] = $this->lang->line('xin_error_msg');
		}
		$this->output($Return);
		exit;
		}
	}
	
	public function add_customers_contact(){
	    
	    if($this->input->post('add_type')=='customer_contact') {
		
		/* Define return | here result is used to return user data and error for error message */
		$Return = array('result'=>'', 'error'=>'');
			
		/* Server side PHP input validation */
		if($this->input->post('name')==='') {
        	$Return['error'] = 'Name field is required.';
		}
				
		if($Return['error']!=''){
       		$this->output($Return);
    	}
	    $session = $this->session->userdata('username');
		$data = array(
		'customer_id' => $this->input->post('customer_id'),
		'name' => $this->input->post('name'),
		'email' => $this->input->post('email'),
		'position' => $this->input->post('position'),
		'phone' => $this->input->post('phone'),
		'added_by' => $session['user_id'],
		'date' => date('Y-m-d H:i:s'),
		);
		$result = $this->Customers_model->add_contact($data);
		if ($result == TRUE) {
			$Return['result'] = 'Contact successfully added.';
		} else {
			$Return['error'] = $this->lang->line('xin_error_msg');
		}
		$this->output($Return);
		exit;
		}
	    
	}
	
	public function add_customer_name() {
	
		if($this->input->post('add_type')=='customers') {
		
		/* Define return | here result is used to return user data and error for error message */
		$Return = array('result'=>'', 'error'=>'');
		$session = $this->session->userdata('username');
		
		$query = $this->db->query("SELECT * FROM `customers` WHERE `company_name`='".$this->input->post('company_name')."' and added_by='".$session['user_id']."' and `root_id`='".$_SESSION['root_id']."'");
			
		/* Server side PHP input validation */
		if($this->input->post('company_name')==='') {
        	$Return['error'] = 'Company name field is required.';
		}
		else if($query->num_rows()>=1)
		{
		    $Return['error'] = 'Company name already exists in database.';
		}
				
		if($Return['error']!=''){
       		$this->output($Return);
    	}
    	
		$data = array(
		'company_name' => $this->input->post('company_name'),
		'added_by' => $session['user_id'],
		'date' => date('Y-m-d H:i:s'),
		);
		$result = $this->Customers_model->add($data);
		if ($result == TRUE) {
			$Return['result'] = 'Customer successfully added.';
		} else {
			$Return['error'] = $this->lang->line('xin_error_msg');
		}
		$this->output($Return);
		exit;
		}
	}
	
	public function add_new_customer_popup(){
	    
		$data['title'] = $this->Xin_model->site_title();
		$data = array();
		$session = $this->session->userdata('username');
		if(!empty($session)){ 
			$this->load->view('customers/dialog_add_customer', $data);
		} else {
			redirect('');
		}
	
	}
	
	// Validate and update info in database
	public function update() {
	
		if($this->input->post('edit_type')=='customer') {
			
		$id = $this->uri->segment(3);
		
		/* Define return | here result is used to return user data and error for error message */
		$Return = array('result'=>'', 'error'=>'');
			
		/* Server side PHP input validation */
		if($this->input->post('company_name')==='') {
        	$Return['error'] = 'Company name field is required.';
		}
				
		if($Return['error']!=''){
       		$this->output($Return);
    	}
	
		$data = array(
		'company_name' => $this->input->post('company_name'),
		'customer_name' => $this->input->post('customer_name'),
		'email' => $this->input->post('email'),
		'trn' => $this->input->post('trn'),
		'phone' => $this->input->post('phone'),
		'address' => $this->input->post('address'),
		);	
		
		$result = $this->Customers_model->update_record($data,$id);		
		
		if ($result == TRUE) {
			$Return['result'] = 'Customer updated.';
		} else {
			$Return['error'] = $this->lang->line('xin_error_msg');
		}
		$this->output($Return);
		exit;
		}
	}
	
	// Validate and update info in database
	public function update_contact() {
	
		if($this->input->post('edit_type')=='customer_contact') {
			
		$id = $this->uri->segment(3);
		
		/* Define return | here result is used to return user data and error for error message */
		$Return = array('result'=>'', 'error'=>'');
			
		/* Server side PHP input validation */
		if($this->input->post('name')==='') {
        	$Return['error'] = 'Name field is required.';
		}
				
		if($Return['error']!=''){
       		$this->output($Return);
    	}
	
		$data = array(
		'name' => $this->input->post('name'),
		'email' => $this->input->post('email'),
		'position' => $this->input->post('position'),
		'phone' => $this->input->post('phone')
		);	
		
		$result = $this->Customers_model->update_contact_record($data,$id);		
		
		if ($result == TRUE) {
			$Return['result'] = 'Contact updated.';
		} else {
			$Return['error'] = $this->lang->line('xin_error_msg');
		}
		$this->output($Return);
		exit;
		}
	}
	
	
	public function customers_select_list() {

		$data['title'] = $this->Xin_model->site_title();
		
		$user_id = $this->session->userdata('user_id');
		
		$data = array(
		    'all_customers' => $this->Xin_model->get_all_customers($user_id)
		    );
		$session = $this->session->userdata('username');
		if(!empty($session)){ 
			$this->load->view("customers/get_customers_select_list", $data);
		} else {
			redirect('');
		}
		// Datatables Variables
		$draw = intval($this->input->get("draw"));
		$start = intval($this->input->get("start"));
		$length = intval($this->input->get("length"));
	}
	
	public function delete() {
		/* Define return | here result is used to return user data and error for error message */
		$Return = array('result'=>'', 'error'=>'');
		$id = $this->uri->segment(3);
		
		$cquery = $this->db->query("select id from pricing_quotes where customer_id='".$id."'");
		$cnum1  = $cquery->num_rows();
		
		$cquery = $this->db->query("select id from pricing_invoices where customer_id='".$id."'");
		$cnum2  = $cquery->num_rows();
		
		$cquery = $this->db->query("select id from pricing_proforma_invoices where customer_id='".$id."'");
		$cnum3  = $cquery->num_rows();
		
		$cquery = $this->db->query("select id from pricing_delivery_note where customer_id='".$id."'");
		$cnum4  = $cquery->num_rows();
		
		$cnum=$cnum1+$cnum2+$cnum3+$cnum4;
		
		if($cnum>0)
		{
		    $Return['error'] = "You can't delete this customer. This customer is connected with one or more datas.";
		}
		else
		{
		    
    		$result = $this->Customers_model->delete_record($id);
    		if(isset($id)) {
    			$Return['result'] = 'Customer Deleted.';
    		} else {
    			$Return['error'] = $this->lang->line('xin_error_msg');
    		}
	    }
	    
		$this->output($Return);
	}
	
	public function delete_contact() {
		/* Define return | here result is used to return user data and error for error message */
		$Return = array('result'=>'', 'error'=>'');
		$id = $this->uri->segment(3);
		    
		$result = $this->Customers_model->delete_contact_record($id);
		if(isset($id)) {
			$Return['result'] = 'Contact Deleted.';
		} else {
			$Return['error'] = $this->lang->line('xin_error_msg');
		}
	    
		$this->output($Return);
	}
	
	public function get_customer_details_by_id(){
        $id = $this->input->get('customer_id');
        $result = $this->Customers_model->read_customer_information($id);
		$shipping_data = $result[0]->company_name.PHP_EOL.'Address : '.$result[0]->address.PHP_EOL.'Phone : '.$result[0]->phone.PHP_EOL.'Email : '.$result[0]->email;
		echo $shipping_data;
     }
     
    public function customers_grid_data(){
        
        $requestData= $_REQUEST;
        
        $columns = array( 
        // datatable column index  => database column name
            0 => 'id', 
        	1 => 'company_name', 
        	2 => 'address',
        	3 => 'customer_name',
        	4 => 'email',
        	5 => 'phone',
        	5 => 'trn',
        	6 => 'added_by',
        	7 => 'status'
        );
        
        // getting total number records without any search
        $root_id = $_SESSION['root_id'];
        
        $session = $this->session->userdata('username');
        
        $role_resources_ids = $this->Xin_model->user_role_resource();
        $user_information = $this->Xin_model->read_user_info($session['user_id']);
        $company_employees  = $this->Xin_model->get_company_employees($user_information[0]->pricing_company);
        
        $company_emp_ids = array();
        foreach($company_employees as $emp_ids){
            array_push($company_emp_ids,$emp_ids->user_id);
        }
        $company_emp_ids = implode(', ', $company_emp_ids);
        
        $sql = "select c.company_name, c.added_by, c.customer_id, c.address, c.customer_name, c.email, c.phone, c.trn, e.first_name, e.last_name";
        
		if(in_array('78',$role_resources_ids)) {
            $sql2=" FROM xin_employees e, customers c where c.root_id = '".$root_id."' and c.added_by = e.user_id";
		}
		else if(in_array('77',$role_resources_ids)) {
            $sql2=" FROM xin_employees e, customers c where c.root_id = '".$root_id."' and c.added_by IN (".$company_emp_ids.") and c.added_by = e.user_id";
		}
		else{
		    $sql2=" FROM xin_employees e, customers c where c.root_id = '".$root_id."' and c.added_by = '".$session['user_id']."' and c.added_by = e.user_id";
		}
		
		$show_all_permission = $this->Xin_model->get_data_list_permission($session['user_id'],'customers');
		
		if($show_all_permission==0){
		    $sql2=" FROM xin_employees e, customers c where c.root_id = '".$root_id."' and c.added_by = '".$session['user_id']."' and c.added_by = e.user_id";
		}
		
		$sql=$sql.$sql2;
		
        $query=$this->db->query($sql);
        $totalData = $query->num_rows();
        $totalFiltered = $totalData;  // when there is no search parameter then total number rows = total number filtered rows.
        
        if( !empty($requestData['search']['value']) ) {   // if there is a search parameter, $requestData['search']['value'] contains search parameter
        	$sql.=" AND ( c.company_name LIKE '%".$requestData['search']['value']."%' ";
        	$sql.=" OR c.address LIKE '%".$requestData['search']['value']."%' ";
        	$sql.=" OR c.customer_name LIKE '%".$requestData['search']['value']."%' ";
        	$sql.=" OR c.email LIKE '%".$requestData['search']['value']."%' ";
        	$sql.=" OR c.phone LIKE '%".$requestData['search']['value']."%' ";
        	$sql.=" OR c.trn LIKE '%".$requestData['search']['value']."%' ";
        	$sql.=" OR e.first_name LIKE '%".$requestData['search']['value']."%' ";
        	$sql.=" OR e.last_name LIKE '%".$requestData['search']['value']."%' ) ";
        }
        
        $query=$this->db->query($sql);
        $totalFiltered = $query->num_rows(); // when there is a search parameter then we have to modify total number filtered rows as per search result. 
        $sql.=" ORDER BY ". $columns[$requestData['order'][0]['column']]."   ".$requestData['order'][0]['dir']."  LIMIT ".$requestData['start']." ,".$requestData['length']."   ";
        /* $requestData['order'][0]['column'] contains colmun index, $requestData['order'][0]['dir'] contains order such as asc/desc  */	
        $query=$this->db->query($sql);
        
        $role_resources_ids = $this->Xin_model->user_role_resource();
        $crm_settings = $this->Xin_model->read_setting_info(1);
        
        $data = array();
        foreach($query->result() as $row ) {  // preparing an array
            $r = $row;
               
            //$option_buttons  = '<span data-toggle="tooltip" data-placement="top" title="View"><button type="button" class="btn btn-secondary btn-sm m-b-0-0 waves-effect waves-light" data-toggle="modal" data-target=".view-modal-data" data-customer_id="'. $r->customer_id . '"><i class="fa fa-eye"></i></button></span>';
        	if(in_array('79',$role_resources_ids) || $r->added_by==$session['user_id']) {
        	    //$option_buttons .= '<span data-toggle="tooltip" data-placement="top" title="Edit"><button type="button" class="btn btn-secondary btn-sm m-b-0-0 waves-effect waves-light"  data-toggle="modal" data-target="#edit-modal-data"  data-customer_id="'. $r->customer_id . '"><i class="fa fa-pencil-square-o"></i></button></span></span>';
        	}
        	
        	if(in_array('80',$role_resources_ids) || $r->added_by==$session['user_id']) {
        	    $option_buttons = '<span data-toggle="tooltip" data-placement="top" title="Delete"><button type="button" class="btn btn-danger btn-sm m-b-0-0 waves-effect waves-light delete" data-toggle="modal" data-target=".delete-modal" data-record-id="'. $r->customer_id . '"><i class="fa fa-trash-o"></i></button></span>';
        	}
            
            $full_name = $r->first_name.' '.$r->last_name;        
            $nestedData=array(); 
            
            $nestedData[] = $r->customer_id;
        	$nestedData[] = '<a href="'.site_url('customers/details/'.$r->customer_id).'">'.$r->company_name.'</a>';
        	$nestedData[] = $r->address;
        	$nestedData[] = $r->customer_name;
        	$nestedData[] = $r->email;
        	$nestedData[] = $r->phone;
        	$nestedData[] = $r->trn;
        	$nestedData[] = $full_name;
        	$nestedData[] = $option_buttons;
        	
        	$data[] = $nestedData;
        }
        
        
        
        $json_data = array(
        			"draw"            => intval( $requestData['draw'] ),   // for every request/draw by clientside , they send a number as a parameter, when they recieve a response/data they first check the draw number, so we are sending same number in draw. 
        			"recordsTotal"    => intval( $totalData ),  // total number of records
        			"recordsFiltered" => intval( $totalFiltered ), // total number of records after searching, if there is no searching then totalFiltered = totalData
        			"data"            => $data   // total data array
        			);
        
        echo json_encode($json_data);  // send data as json format
    }
	
}
