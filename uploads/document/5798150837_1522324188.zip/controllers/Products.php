<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Products extends MY_Controller {
	
	 public function __construct() {
        Parent::__construct();
		$this->load->library('session');
		$this->load->helper('form');
		$this->load->helper('url');
		$this->load->helper('html');
		$this->load->database();
		$this->load->library('form_validation');
		//load the model
		$this->load->model("Products_model");
		$this->load->model("Price_model");
		$this->load->model("Xin_model");
	}
	
	/*Function to set JSON output*/
	public function output($Return=array()){
		/*Set response header*/
		header("Access-Control-Allow-Origin: *");
		header("Content-Type: application/json; charset=UTF-8");
		/*Final JSON response*/
		exit(json_encode($Return));
	}
	
	 public function index_old()
     {
        $session = $this->session->userdata('username');
		if(!empty($session)){ 
			
		} else {
			redirect('');
		}
		
		$data['title'] = $this->Xin_model->site_title();
		$data['product_cats'] = $this->Xin_model->get_all_product_cats();
		$data['breadcrumbs'] = 'Products';
		$data['path_url'] = 'products';
		$session = $this->session->userdata('username');
		$role_resources_ids = $this->Xin_model->user_role_resource();
		if(in_array('63',$role_resources_ids) || in_array('64',$role_resources_ids) || in_array('65',$role_resources_ids)) {
			if(!empty($session)){ 
			$data['subview'] = $this->load->view("products/products_list", $data, TRUE);
			$this->load->view('layout_main', $data); //page load
			} else {
				redirect('');
			}
		} else {
			redirect('dashboard/');
		}		  
     }
     
     public function index()
     {
        $session = $this->session->userdata('username');
		if(!empty($session)){ 
			
		} else {
			redirect('');
		}
		
		$data['title'] = $this->Xin_model->site_title();
		$data['product_cats'] = $this->Xin_model->get_all_product_cats();
		$data['product_brand'] = $this->Xin_model->get_all_product_brand();
		$data['breadcrumbs'] = 'Products';
		$data['path_url'] = 'products';
		$session = $this->session->userdata('username');
		$role_resources_ids = $this->Xin_model->user_role_resource();
		if(in_array('66',$role_resources_ids) || in_array('67',$role_resources_ids) || in_array('68',$role_resources_ids)) {
			if(!empty($session)){ 
			$data['subview'] = $this->load->view("products/products_list", $data, TRUE);
			$this->load->view('layout_main', $data); //page load
			} else {
				redirect('');
			}
		} else {
			redirect('dashboard/');
		}		  
     }
     
    public function products_grid_data(){
        
        $requestData= $_REQUEST;
        
        $columns = array( 
        // datatable column index  => database column name
            0 => 'id', 
        	1 => 'name', 
        	2 => 'brand',
        	3 => 'model_number',
        	4 => 'category_id',
        	5 => 'updated_by',
        	6 => 'added_by'
        );
        
        // getting total number records without any search
        $root_id = $_SESSION['root_id'];
        $sql = "SELECT * ";
        $sql.=" FROM products where root_id = '".$root_id."'";
        $query=$this->db->query($sql);
        $totalData = $query->num_rows();
        $totalFiltered = $totalData;  // when there is no search parameter then total number rows = total number filtered rows.
        
        
        $sql = "SELECT *";
        $sql.=" FROM products WHERE root_id = '".$root_id."'";
        if( !empty($requestData['search']['value']) ) {   // if there is a search parameter, $requestData['search']['value'] contains search parameter
        	$sql.=" AND ( name LIKE '%".$requestData['search']['value']."%' ";    
        	$sql.=" OR brand LIKE '%".$requestData['search']['value']."%' ";
        	$sql.=" OR model_number LIKE '%".$requestData['search']['value']."%' )";
        }
        $query=$this->db->query($sql);
        $totalFiltered = $query->num_rows(); // when there is a search parameter then we have to modify total number filtered rows as per search result. 
        $sql.=" ORDER BY ". $columns[$requestData['order'][0]['column']]."   ".$requestData['order'][0]['dir']."  LIMIT ".$requestData['start']." ,".$requestData['length']."   ";
        /* $requestData['order'][0]['column'] contains colmun index, $requestData['order'][0]['dir'] contains order such as asc/desc  */	
        $query=$this->db->query($sql);
        
        $role_resources_ids = $this->Xin_model->user_role_resource();
        
        $data = array();
        $session = $this->session->userdata('username');
        foreach($query->result() as $row ) {  // preparing an array
            $r = $row;
            $option_buttons = '<span data-toggle="tooltip" data-placement="top" title="View"><button type="button" class="btn btn-secondary btn-sm m-b-0-0 waves-effect waves-light" data-toggle="modal" data-target=".view-modal-data" data-product_id="'. $r->id . '"><i class="fa fa-eye"></i></button></span>';
    		if(in_array('67',$role_resources_ids) || $r->added_by==$session['user_id']) {
    		    $option_buttons .= '<span data-toggle="tooltip" data-placement="top" title="Edit"><button type="button" class="btn btn-secondary btn-sm m-b-0-0 waves-effect waves-light"  data-toggle="modal" data-target="#edit-modal-data"  data-product_id="'. $r->id . '"><i class="fa fa-pencil-square-o"></i></button></span></span>';
    		}
    		if(in_array('68',$role_resources_ids) || $r->added_by==$session['user_id']) {
    		    $option_buttons .= '<span data-toggle="tooltip" data-placement="top" title="Delete"><button type="button" class="btn btn-danger btn-sm m-b-0-0 waves-effect waves-light delete" data-toggle="modal" data-target=".delete-modal" data-record-id="'. $r->id . '"><i class="fa fa-trash-o"></i></button></span>';
    		}
    		
    		  $user = $this->Xin_model->read_user_info($r->added_by);
			  $full_name = $user[0]->first_name.' '.$user[0]->last_name;
			  
			  $updated_name = '--';
			  if($r->updated_by!=0)
			  {
			    $user2 = $this->Xin_model->read_user_info($r->updated_by);
			    $updated_name = $user2[0]->first_name.' '.$user2[0]->last_name;
			  }
        
        	$nestedData=array(); 
            $product_cat = $this->Xin_model->get_product_cat_by_id($row->category_id);
            $product_brand = $this->Xin_model->get_product_brand_by_id($row->brand);
            
            $nestedData[] = $option_buttons;
        	$nestedData[] = $row->name;
        	$nestedData[] = $product_brand;
        	$nestedData[] = $row->model_number;
        	$nestedData[] = $product_cat;
        	$nestedData[] = $updated_name;
        	$nestedData[] = $full_name;
        	
        	$data[] = $nestedData;
        }
        
        
        
        $json_data = array(
        			"draw"            => intval( $requestData['draw'] ),   // for every request/draw by clientside , they send a number as a parameter, when they recieve a response/data they first check the draw number, so we are sending same number in draw. 
        			"recordsTotal"    => intval( $totalData ),  // total number of records
        			"recordsFiltered" => intval( $totalFiltered ), // total number of records after searching, if there is no searching then totalFiltered = totalData
        			"data"            => $data   // total data array
        			);
        
        echo json_encode($json_data);  // send data as json format
    }
 
    public function products_list()
     {

		$data['title'] = $this->Xin_model->site_title();
		$session = $this->session->userdata('username');
		if(!empty($session)){ 
			$this->load->view("products/products_list", $data);
		} else {
			redirect('');
		}
		// Datatables Variables
		$draw = intval($this->input->get("draw"));
		$start = intval($this->input->get("start"));
		$length = intval($this->input->get("length"));
		
		
		$bank = $this->Products_model->get_products();
		$role_resources_ids = $this->Xin_model->user_role_resource();
		
		$data = array();

          foreach($bank->result() as $r) {
			  // get user
			  $user = $this->Xin_model->read_user_info($r->added_by);
			  // user full name
			  $full_name = $user[0]->first_name.' '.$user[0]->last_name;
			  
			  $updated_name = '--';
			  if($r->updated_by!=0)
			  {
			    $user2 = $this->Xin_model->read_user_info($r->updated_by);
			    $updated_name = $user2[0]->first_name.' '.$user2[0]->last_name;
			  }
			  
			    $option_buttons = '<span data-toggle="tooltip" data-placement="top" title="View"><button type="button" class="btn btn-secondary btn-sm m-b-0-0 waves-effect waves-light" data-toggle="modal" data-target=".view-modal-data" data-product_id="'. $r->id . '"><i class="fa fa-eye"></i></button></span>';
        		if(in_array('64',$role_resources_ids)) {
        		    $option_buttons .= '<span data-toggle="tooltip" data-placement="top" title="Edit"><button type="button" class="btn btn-secondary btn-sm m-b-0-0 waves-effect waves-light"  data-toggle="modal" data-target="#edit-modal-data"  data-product_id="'. $r->id . '"><i class="fa fa-pencil-square-o"></i></button></span></span>';
        		}
        		if(in_array('65',$role_resources_ids)) {
        		    $option_buttons .= '<span data-toggle="tooltip" data-placement="top" title="Delete"><button type="button" class="btn btn-danger btn-sm m-b-0-0 waves-effect waves-light delete" data-toggle="modal" data-target=".delete-modal" data-record-id="'. $r->id . '"><i class="fa fa-trash-o"></i></button></span>';
        		}
               $product_cat = $this->Xin_model->get_product_cat_by_id($r->category_id);
               $data[] = array(
			   		$option_buttons,
                    $r->name,
                    $r->brand,
                    $r->model_number,
                    $product_cat,
                    $updated_name,
					$full_name
               );
          }

          $output = array(
               "draw" => $draw,
                 "recordsTotal" => $bank->num_rows(),
                 "recordsFiltered" => $bank->num_rows(),
                 "data" => $data
            );
          echo json_encode($output);
          exit();
     }
     
     public function product_cat_list() {

		$data['title'] = $this->Xin_model->site_title();
		
		$user_id = $this->session->userdata('user_id');
		
		$data = array();
		$session = $this->session->userdata('username');
		if(!empty($session)){ 
			$this->load->view("products/get_product_cat", $data);
		} else {
			redirect('');
		}
		// Datatables Variables
		$draw = intval($this->input->get("draw"));
		$start = intval($this->input->get("start"));
		$length = intval($this->input->get("length"));
	 }
	 
	 public function product_brand_list() {
		$data['title'] = $this->Xin_model->site_title();
		$user_id = $this->session->userdata('user_id');
		$data = array();
		$session = $this->session->userdata('username');
		if(!empty($session)){ 
			$this->load->view("products/get_product_brand", $data);
		} else {
			redirect('');
		}
		// Datatables Variables
		$draw = intval($this->input->get("draw"));
		$start = intval($this->input->get("start"));
		$length = intval($this->input->get("length"));
	 }
	 
	 public function read()
	{
		$data['title'] = $this->Xin_model->site_title();
		$id = $this->input->get('product_id');
		$result = $this->Products_model->read_product_information($id);
		$data = array(
				'product_id' => $result[0]->id,
				'name' => $result[0]->name,
				'brand_name' => $result[0]->brand,
				'model_number' => $result[0]->model_number,
				'category_id' => $result[0]->category_id,
				'product_cats' => $this->Xin_model->get_all_product_cats(),
				'product_brand' => $this->Xin_model->get_all_product_brand(),
				'des' => $result[0]->des
				);
		$session = $this->session->userdata('username');
		if(!empty($session)){ 
			$this->load->view('products/dialog_products', $data);
		} else {
			redirect('');
		}
	}
	
	// Validate and add info in database
	public function add_product() {
	
		if($this->input->post('add_type')=='products') {
		
		/* Define return | here result is used to return user data and error for error message */
		$Return = array('result'=>'', 'error'=>'');
			
		/* Server side PHP input validation */
		if($this->input->post('product_name')==='') {
        	$Return['error'] = 'Product name field is required.';
		} else if($this->input->post('product_cat')==='') {
			$Return['error'] = 'Product category field is required.';
		} else if($this->input->post('brand_name')==='') {
			$Return['error'] = 'Brand Name field is required.';
		}
				
		if($Return['error']!=''){
       		$this->output($Return);
    	}
	    $session = $this->session->userdata('username');
		$data = array(
		'name' => $this->input->post('product_name'),
		'brand' => $this->input->post('brand_name'),
		'category_id' => $this->input->post('product_cat'),
		'model_number' => $this->input->post('model_number'),
		'des' => $this->input->post('description'),
		'added_by' => $session['user_id'],
		'date' => date('Y-m-d H:i:s'),
		);
		$result = $this->Products_model->add($data);
		if ($result == TRUE) {
			$Return['result'] = 'Product successfully added.';
		} else {
			$Return['error'] = $this->lang->line('xin_error_msg');
		}
		$this->output($Return);
		exit;
		}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	// Validate and add info in database
	public function add_product_with_price() {
	    date_default_timezone_set('Asia/Dubai');
		if($this->input->post('add_type')=='products_with_price') {
		
		/* Define return | here result is used to return user data and error for error message */
		$Return = array('result'=>'', 'error'=>'');
			
		/* Server side PHP input validation */
		if($this->input->post('product_name')==='') {
        	$Return['error'] = 'Product name field is required.';
		} else if($this->input->post('product_cat')==='') {
			$Return['error'] = 'Product category field is required.';
		} else if($this->input->post('brand_name')==='') {
			$Return['error'] = 'Brand Name field is required.';
		} else if($this->input->post('supplier')==='') {
			$Return['error'] = 'Supplier Name field is required.';
		} else if($this->input->post('price')==='') {
			$Return['error'] = 'Price field is required.';
		}
				
		if($Return['error']!=''){
       		$this->output($Return);
    	}
	    $session = $this->session->userdata('username');
		$data = array(
		'name' => $this->input->post('product_name'),
		'brand' => $this->input->post('brand_name'),
		'category_id' => $this->input->post('product_cat'),
		'model_number' => $this->input->post('model_number'),
		'des' => $this->input->post('description'),
		'added_by' => $session['user_id'],
		'date' => date('Y-m-d H:i:s'),
		);
		$result = $this->Products_model->add($data);
		if ($result == TRUE) {
		    
		    $product_id = $this->db->insert_id();
		    $data2 = array(
    		'product_id' => $product_id,
    		'supplier_id' => $this->input->post('supplier'),
    		'price' => $this->input->post('price'),
    		'added_by' => $session['user_id'],
    		'date' => date('Y-m-d H:i:s'),
    		);
    		$result = $this->Price_model->add($data2);
		    
			$Return['result'] = 'Product successfully added.';
		} else {
			$Return['error'] = $this->lang->line('xin_error_msg');
		}
		$this->output($Return);
		exit;
		}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	// Validate and update info in database
	public function update() {
	
		if($this->input->post('edit_type')=='products') {
			
		$id = $this->uri->segment(3);
		
		/* Define return | here result is used to return user data and error for error message */
		$Return = array('result'=>'', 'error'=>'');
			
		/* Server side PHP input validation */
		if($this->input->post('product_name')==='') {
        	$Return['error'] = 'Product name field is required.';
		} else if($this->input->post('description')==='') {
			$Return['error'] = 'Product description field is required.';
		} else if($this->input->post('brand_name')==='') {
			$Return['error'] = 'Brand Name field is required.';
		}
				
		if($Return['error']!=''){
       		$this->output($Return);
    	}
	    
		$session = $this->session->userdata('username');
		$data = array(
		'name' => $this->input->post('product_name'),
		'brand' => $this->input->post('brand_name'),
		'des' => $this->input->post('description'),
		'category_id' => $this->input->post('product_cat'),
		'model_number' => $this->input->post('model_number'),
		'updated_by' => $session['user_id'],
		);	
		
		$result = $this->Products_model->update_record($data,$id);		
		
		if ($result == TRUE) {
			$Return['result'] = 'Product updated.';
		} else {
			$Return['error'] = $this->lang->line('xin_error_msg');
		}
		$this->output($Return);
		exit;
		}
	}
	
	public function products_select_list() {

		$data['title'] = $this->Xin_model->site_title();
		
		$user_id = $this->session->userdata('user_id');
		
		$data = array(
		    'all_products' => $products = $this->Products_model->get_products()
		    );
		$session = $this->session->userdata('username');
		if(!empty($session)){ 
			$this->load->view("products/get_products_select_list", $data);
		} else {
			redirect('');
		}
		// Datatables Variables
		$draw = intval($this->input->get("draw"));
		$start = intval($this->input->get("start"));
		$length = intval($this->input->get("length"));
	}
	
	public function delete() {
		/* Define return | here result is used to return user data and error for error message */
		$Return = array('result'=>'', 'error'=>'');
		$id = $this->uri->segment(3);
		
    		$result = $this->Products_model->delete_record($id);
    		if(isset($id)) {
    			$Return['result'] = 'Product Deleted.';
    		} else {
    			$Return['error'] = $this->lang->line('xin_error_msg');
    		}
		$this->output($Return);
	}
	
	public function view_import_product_data(){
	    
	    $session = $this->session->userdata('username');
		if(!empty($session)){ 
			
		} else {
			redirect('');
		}
		
	    $query = $this->db->query("SELECT * FROM `temp_products` where added_by='".$session['user_id']."'");
        $num_rows = $query->num_rows();
        $result_pro = $query->result();
        ?>
        <!DOCTYPE html>
        <html lang="en">
        <head>
          <title>Import Product Data</title>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1">
          <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
          <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
          <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        </head>
        <body>
    
        <div class="box box-block">
        <table class="table table-striped table-bordered dataTable" style="width:100%;" id="pxin_table">
          <thead>
            <tr>
              <th></th>
              <th>Name</th>
              <th>Brand</th>
              <th>Model Number</th>
              <th>Category</th>
            </tr>
          </thead>
          <tbody>
            <?php
            $slno=1;
            foreach($result_pro as $data){
                $query = $this->db->query("SELECT * FROM `temp_product_category` where id='".$data->category_id."'");
                $result_pro = $query->result();
            ?>
            <tr>
              <td><?php echo $slno; ?></td>
              <td><?php echo $data->name; ?></td>
              <td><?php echo $data->brand; ?></td>
              <td><?php echo $data->model_number; ?></td>
              <td><?php echo $result_pro[0]->name; ?></td>
            </tr>
            <?php
            $slno++;
            }
            ?>
          </tbody>
          </table>
          
          <div class="pull-right">
            <a href="<?php echo site_url('products/confirm_sync'); ?>" class="btn btn-success btn-lg" onclick="return confirm('Are you sure?')" >
              <span class="glyphicon glyphicon-refresh"></span> Confirm and Sync 
            </a>
            
            <a href="<?php echo site_url('products/cancel_sync'); ?>" onclick="return confirm('Are you sure?')" class="btn btn-danger btn-lg">
              <span class="glyphicon glyphicon-remove"></span> Cancel 
            </a>
          <br/><br/>
          </div>
          
          </div>
          
          </body>
        </html>
          
    
          <?php
	}
	
	public function confirm_sync(){
	    
	    $session = $this->session->userdata('username');
		if(!empty($session)){ 
		    
		    $root_id = $_SESSION['root_id'];
		    
		    $query = $this->db->query("SELECT * FROM `temp_product_category` where added_by='".$session['user_id']."'");
            $num_rows = $query->num_rows();
            foreach($query->result() as $result_pro){
		    
			    $query = $this->db->query("SELECT * FROM `product_category` where LOWER(name)='".strtolower($result_pro->name)."'");
                $num_rows = $query->num_rows();
                if($num_rows==1)
                {
                    
                }
                else
                {
                    $data = array(
                    		'root_id' => $root_id,
                    		'name' => $result_pro->name,
                    		'added_by' => $session['user_id'],
                    		'date' => date('Y-m-d H:i:s')
                    		);
                    $insert_cat_q= $this->db->insert('product_category',$data);
                }
                
            }    
            
            
            $query = $this->db->query("SELECT * FROM `temp_products` where added_by='".$session['user_id']."'");
            $num_rows = $query->num_rows();
            foreach($query->result() as $result_pro){
		    
			    $query = $this->db->query("SELECT * FROM `products` where LOWER(name)='".strtolower($result_pro->name)."' and LOWER(brand)='".strtolower($result_pro->brand)."' and LOWER(model_number)='".strtolower($result_pro->model_number)."'");
                $num_rows = $query->num_rows();
                if($num_rows>=1)
                {
                }
                else
                {
                    $this->db->query("INSERT INTO `products`(`root_id`, `name`, `brand`, `model_number`, `category_id`, `des`, `added_by`, `date`) VALUES ($root_id,'".$result_pro->name."','".$result_pro->brand."','".$result_pro->model_number."','".$result_pro->category_id."','',".$result_pro->added_by.",'".date('Y-m-d H:i:s')."')");
                }
                
            } 
            
            $session = $this->session->userdata('username');
	        $query = $this->db->query("DELETE FROM `temp_products` WHERE `added_by`='".$session['user_id']."'");
	        $query = $this->db->query("DELETE FROM `temp_product_category` WHERE `added_by`='".$session['user_id']."'");
                
    	    redirect('dashboard');
		} else {
			redirect('');
		}
	}
	
	public function cancel_sync(){
	    
	    $session = $this->session->userdata('username');
		if(!empty($session)){ 
			$query = $this->db->query("DELETE FROM `temp_products` WHERE `added_by`='".$session['user_id']."'");
    	    $query = $this->db->query("DELETE FROM `temp_product_category` WHERE `added_by`='".$session['user_id']."'");
    	    redirect('dashboard');
		} else {
			redirect('');
		}
	}
	
	public function export_products_csv(){
	    
	    $session = $this->session->userdata('username');
		if(!empty($session)){ 
			
		} else {
			redirect('');
		}
		
	    $all_products = $this->Products_model->get_products();
	    $csv_hdr = "Sl No, Product Name, Brand, Model Number, Category";
        $csv_output="";
        
        $slno=1;
        foreach($all_products->result() as $r) {
          $product_cat = $this->Xin_model->get_product_cat_by_id($r->category_id);
          $name=str_replace(",",";",$r->name);
          $csv_output .= $slno . ", ";
          $csv_output .= $name . ", ";
          $csv_output .= $r->brand . ",";
          $csv_output .= $r->model_number . ",";
          $csv_output .= $product_cat. "\n";
        $slno++;
        }
        $out = '';
        
        $filename_prefix = 'all_products_csv';
        
        if (isset($csv_hdr)) {
        $out .= $csv_hdr;
        $out .= "\n";
        }
        
        if (isset($csv_output)) {
        $out .= $csv_output;
        }
        
        $filename = $filename_prefix."_".date("Y-m-d_H-i",time());
        
        header("Content-type: application/vnd.ms-excel");
        header("Content-Encoding: UTF-8");
        header("Content-type: text/csv; charset=UTF-8");
        header("Content-disposition: csv" . date("Y-m-d") . ".csv");
        header("Content-disposition: filename=".$filename.".csv");
        echo "\xEF\xBB\xBF"; // UTF-8 BOM
        //Print the contents of out to the generated file.
        print $out;
        
        //Exit the script
        exit;
	}
	
	
	
	public function export_products(){
	    
	    $session = $this->session->userdata('username');
		if(!empty($session)){ 
			
		} else {
			redirect('');
		}
		
	    $all_products = $this->Products_model->get_products();
	    $csv_hdr = "Sl No\t Product Name\t Brand\t Model Number\t Category";
	    
        $csv_output="";
        
        $slno=1;
        foreach($all_products->result() as $r) {
              
          $product_cat = $this->Xin_model->get_product_cat_by_id($r->category_id);
          $name =preg_replace("/\r\n|\n\r|\n|\r/", " ",$r->name);
          $csv_output .= $slno . "\t ";
          $csv_output .= $name . "\t ";
          $csv_output .= $r->brand . "\t";
          $csv_output .= $r->model_number . "\t ";
          $csv_output .= $product_cat. "\n";
          $slno++;
        }
        $out = '';
        
        $filename_prefix = 'all_products_csv';
        
        if (isset($csv_hdr)) {
        $out .= $csv_hdr;
        $out .= "\n";
        }
        
        if (isset($csv_output)) {
        $out .= $csv_output;
        }
        
        $filename = $filename_prefix."_".date("Y-m-d_H-i",time());
        
        /*
        header("Content-type: application/vnd.ms-excel");
        header("Content-Encoding: UTF-8");
        header("Content-type: text/csv; charset=UTF-8");
        header("Content-disposition: csv" . date("Y-m-d") . ".csv");
        header("Content-disposition: filename=".$filename.".csv");
        echo "\xEF\xBB\xBF"; // UTF-8 BOM
        */
        
        
        header("Content-Type: application/xls");    
        header("Content-Encoding: UTF-8");
        header("Content-type: application/xls; charset=UTF-8");
        header("Content-Disposition: attachment; filename=$filename.xls");  
        header("Pragma: no-cache"); 
        header("Expires: 0");
        echo "\xEF\xBB\xBF"; // UTF-8 BOM
        mb_convert_encoding($out, 'UTF-16LE', 'UTF-8');
        
        //Print the contents of out to the generated file.
        print $out;
        
        //Exit the script
        exit;
	}
	
	
}
